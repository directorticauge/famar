<!DOCTYPE html>
<html>
  <head>
    <title>Comunicación con Puerto Serie</title>
  </head>
  <body>
    <button id="connectButton">Conectar al Puerto Serie</button>
    <button id="disconnectButton" disabled>Desconectar</button>
    <button id="sendDataButton" disabled>Enviar Dato Importante</button>
    <textarea id="dataDisplay" rows="10" cols="50" readonly></textarea>

    <script>
      const connectButton = document.getElementById("connectButton");
      const disconnectButton = document.getElementById("disconnectButton");
      const sendDataButton = document.getElementById("sendDataButton");
      const dataDisplay = document.getElementById("dataDisplay");
      let port;
      let importantData = '';  // Variable global para almacenar el dato importante
      //const regex = /Result      (\d+\.\d+)/; // Expresión regular para buscar un número decimal
      const regex = /End Result (\d+\.\d+ %MC)/;

      async function startReadingData() {
        while (port.readable) {
          const textDecoder = new TextDecoder();
          const reader = port.readable.getReader();

          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) {
                break;
              }
              const decodedData = textDecoder.decode(value);
              console.log(decodedData);
              dataDisplay.value += decodedData;
              
              if (regex.test(decodedData)) {
                const match = decodedData.match(regex);
                if (match) {
                  const importantValue = match[1];
                  importantData = importantValue;
                  sendDataButton.removeAttribute("disabled");
                  alert("Se ha recibido un dato importante: " + importantValue);
                }
              }
            }
          } finally {
            reader.releaseLock();
          }
        }
      }

      connectButton.addEventListener("click", async () => {
        try {
          port = await navigator.serial.requestPort();
          await port.open({ baudRate: 9600 });

          dataDisplay.textContent = "Conexión al puerto serie establecida";
          disconnectButton.removeAttribute("disabled");

          startReadingData();
        } catch (error) {
          console.error("Error al conectar al puerto serie:", error);
        }
      });

      disconnectButton.addEventListener("click", () => {
        if (port) {
          port.close();
          dataDisplay.textContent = "Conexión al puerto serie cerrada";
          disconnectButton.setAttribute("disabled", "disabled");
        }
      });

      sendDataButton.addEventListener("click", async () => {
        if (importantData) {
          const formData = new FormData();
          formData.append("importantData", importantData);

          try {
            const response = await fetch("dato_importante.php", {
              method: "POST",
              body: formData,
            });

            if (response.ok) {
              alert("Dato importante enviado con éxito al servidor PHP.");
              importantData = '';
              sendDataButton.setAttribute("disabled", "disabled");
            } else {
              console.error("Error al enviar el dato importante al servidor.");
            }
          } catch (error) {
            console.error("Error al enviar el dato importante:", error);
          }
        }
      });
    </script>
  </body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  if (isset($_POST["importantData"])) {
    $importantData = $_POST["importantData"];
    
    // Haz lo que necesites con $importantData, como almacenarlo en una base de datos o realizar alguna otra acción.
  }
}
?>
