<html lang="es"><head>
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet"> 
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link rel="icon" href="logos/logo-nav_trs.ico" type="image/x-icon">
    <link rel="shortcut icon" href="logos/logo-nav_trs.ico" type="image/x-icon">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<!--<link href='https://fonts.googleapis.com/css?family=Racing Sans One' rel='stylesheet'>-->

<title>SACPO BY AUGE SOLUCIONES S.A.S.</title>

<?php
include("config.php");
$sql = "SELECT * FROM campañas";
				$result = $db->query($sql);

				if ($result) {
					$row = $result->fetch_assoc();
					$fondo = $row['fondo_login'];
				}
				else{ 
				echo ("RECUERDA CONFIGURAR CAMPAÑA");
				}
?>
<style>
	body{
			background: url(<?php echo $fondo;?>);
			background-repeat: no-repeat;
			background-position: center center;
			background-attachment: fixed;
			-webkit-background-size: cover;
			-moz-background-size: cover;
			-o-background-size: cover;
			background-size: cover;
		}
	#todo{
			width: 100%;
			height: 100%;
			position: absolute;
			background-color: black;
			opacity: 0.4;    		
		}
	#foot{
		  position: fixed;
		  bottom: 0;
		  right: 0;
		  width: 100%;
		}
#loginbox {
    position: absolute;
    top: 45%;
    left: 50%;
    width: 300px;
    height: auto;
    margin-top: -245px;
    margin-left: -154px;
    background-color: #E7E7E7;
    border-radius: 4%;
    alignment-adjust: central;
    -webkit-box-shadow: 0px 0px 2em 0.3em #999999;
    box-shadow: 0px 0px 2em 0.3em #999999;
    -moz-box-shadow: 0px 0px 2em 0.3em #999999;
    padding: 10px 20px 10px 20px;
}
.login100-form-title {
    display: block;
    /*font-family: 'Racing Sans One'*/;
    font-family: 'Poppins';
    font-weight: bold ;
    font-size: 39px;
    color: #333333;
    line-height: 1.2;
    text-align: center;
}

.p-b-70 {
    padding-bottom: 50px;
}
.login100-form-avatar {
    display: block;
    width: 186px;
    height: 181px;
    /*border-radius: 19%;*/
    overflow: hidden;
    margin: 0 auto;
}
</style>
<script>
PNotify.prototype.options.styling = "jqueryui";
function Mensaje(){
	PNotify.desktop.permission();
	(new PNotify({
		title: 'Prueba de Mensaje',
		text: 'Prueba de mensaje por parte de InvenObras. Ameth Ordoñez Erazo.',
		type: 'info',
		desktop: {
			desktop: true,
			icon: 'css/logotipo_ac.png'
		}
	}));
}
</script>
</head>
<body>
<!--<div id="todo"></div>-->

<div class="container">
    <div id="loginbox">
    <form id="form" name="form" method="post" action="login.php" class="form-horizontal">
    	<div class="form-group text-center">
    		<div class="col-lg-12"><br>
    		<span class="login100-form-title p-b-70" style="padding-bottom: 0px;">
						Bienvenido
					</span>
					<span class="login100-form-avatar"style="width: 260px;height: 260px;display: inline-flex;">
						<img src="logos/Vector_SACPO.png" width="300" alt="AUGE Soluciones">
					</span>
    		

    	<div class="form-group">
    		<div class="col-lg-12" style="padding-top:50px"><input name="user" type="text" placeholder="Usuario" autofocus="" class="form-control" id="user" size="20" maxlength="30"></div>
		</div>
        <div class="form-group text-center">
    		<div class="col-lg-12"><input name="password" type="password" class="form-control" id="password" placeholder="Contraseña" autocomplete="off" size="20" maxlength="30"></div>
    		<a href="#" onclick="Mensaje();">Recordar mi clave</a>
		</div>
      	<div class="form-group text-center">
			<div class="col-lg-12"><button type="submit" name="submit" id="submit" class="btn btn-lg btn-success btn-block">Acceder <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span></button><br></div>
			<span class="Contenido2">Versión: 1.0</span><br>
   			<span class="Contenido2">Todos los derechos reservados © AUGE SOLUCIONES S.A.S.</span>
   		</div>
	
	</div>
</div></form>

		<script type="text/javascript">
$('#Empresa').on('change', function() {
  //alert( this.value );
	if(this.value =="ACONSTRUIR"){
		window.location.href="http://190.242.110.178/invenobras/login.php";
	}
	if(this.value =="AST"){
		window.location.href="http://190.242.110.178/ast/login.php";
	}
});
	</script>
</div></div></body></html>

