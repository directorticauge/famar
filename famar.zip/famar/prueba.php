<?php

// Datos de autenticación
$appToken = 'Wb02DaD5RziwxEKoMgs8mqeMLkYzDUmvu2iBzPDn';
$userToken = 'VIwzGh4pUaKi7DdBywBIA8segq5pza9GcLSGZKx0';
$username = 'glpi';
$password = 'soporte2017';

// URL de la API de GLPI para iniciar sesión
$apiUrl = 'http://190.144.0.226:84/helpdesk/glpiAct/glpi/apirest.php/initSession/';

// Datos de la solicitud
$data = [
    'app_token' => $appToken,
    'user_token' => $userToken,
    'username' => $username,
    'password' => $password,
];

// Inicializar cURL
$ch = curl_init($apiUrl);

// Configurar opciones de cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

// Ejecutar la solicitud y obtener la respuesta
$response = curl_exec($ch);

// Verificar si hay errores
if (curl_errno($ch)) {
    echo 'Error al realizar la solicitud: ' . curl_error($ch);
} else {
    // Procesar la respuesta
    $responseData = json_decode($response, true);
    
    // Verificar si se obtuvo el token de sesión
    if (isset($responseData['session_token'])) {
        $sessionToken = $responseData['session_token'];
        var_dump( $sessionToken);
        // URL de la acción que deseas realizar (puede variar según tus necesidades)
        $actionUrl = 'http://190.144.0.226:84/helpdesk/glpiAct/glpi/';

        // Inicializar cURL para la acción específica con el token de sesión
        $chr = curl_init($actionUrl);
        curl_setopt($chr, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($chr, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $sessionToken,
        ]);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $actionResponse = curl_exec($chr);

        // Verificar la respuesta o realizar otras operaciones según tus necesidades
        var_dump($actionResponse);

        // Cerrar la sesión cURL para la acción específica
        curl_close($chr);
    } else {
        echo 'Error al obtener el token de sesión.';
    }
}

// Cerrar la sesión cURL
curl_close($ch);

?>
