<?php



  session_start();
      if($_SESSION['login_user']<>""){
        
 
      include("../main/session.php");

      }else{

        ?>
        <script type="text/javascript">
        window.location="../main/logout.php";
        </script>
        <?php
          }

/*consulta de datatables*/
$sql = "SELECT * FROM socios_de_negocio";
               
                $result = $db->query($sql);
                $arr_lideres = [];
                if ($result->num_rows > 0) {
                    $arr_lideres = $result->fetch_all(MYSQLI_ASSOC);
                }
/*consulta de datatables*/

          
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {


                           
                            $sql = "UPDATE socios_de_negocio SET 
							nombre = ?,
							apellido = ?,
							email = ?,
							telefono = ?,
							direccion = ?,
							tipo = ?
							
						WHERE id = ?";
						$stmt = $db->prepare($sql);
						$stmt->bind_param("ssssssi",
							
							$_POST['nombre'],
							$_POST['apellido'],
							$_POST['email'],
							$_POST['telefono'],
							$_POST['direccion'],
							$_POST['tipo'],
							$_POST["id"]
						);
						if ($stmt->execute()) {
							
							
							echo '<script type="text/javascript">
								alert("REGISTRO ACTUALIZADO CON EXITO");
								window.location.href="sn_consultas.php";
								</script>';
						} else {
							echo "Error: " . $stmt->error;
						}
						$stmt->close();
						$db->close();

                        }
                       
                        // Cierra la conexión a la base de datos
                       
                         
                          
                    
                        


                                   
                        




?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <?php
          include ("head.php");

          ?>
</head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Cargando...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      <!-- Swiper-->
      
      <!-- Section Box Categories-->
      <section style="min-height: 35px;" class="section section-lg section-top-1 bg-gray-4">
        <div class="container offset-negative-1" style="margin-top: 0px;">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center" style="display: block;">


                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s" style="max-width: 100%;">

                    <?php
                if (isset($_GET["ID"])) {

                                $id = $_GET["ID"];

                                $sql = "SELECT * FROM socios_de_negocio WHERE id = $id";
                                $resultado = mysqli_query($db, $sql);

                                if (mysqli_num_rows($resultado) > 0) {
                                    // Obtén los datos del socio de negocio
                                    $socio = mysqli_fetch_assoc($resultado);
                                    $id = $socio["id"];
                                    
                                    $nombre = $socio["nombre"];
                                    $apellido = $socio["apellido"];
                                    $email = $socio["email"];
                                    $telefono = $socio["telefono"];
                                    $direccion = $socio["direccion"];
                                    $tipo = $socio["tipo"];

                                    // Ajusta el resto de los campos según tu base de datos
                                }
                                ?>
                                <link href="../css/style.css" rel="stylesheet">
                                <div class="container">
                                <h2 style="font-size: 31px;">Formulario de edicion de Socio de Negocio</h2>
                                <form action="sn_consultas.php" method="post">
                                <table class="table">
                                <tr>
                                <td>
                                <label>Nombre:</label>
                                <input type="text" name="nombre" value="<?php echo $nombre; ?>" class="form-control" required>
                                </td>
                                <td>
                                <label>Apellido:</label>
                                <input type="text" name="apellido" value="<?php echo $apellido; ?>" class="form-control" required>
                                </td>
                                </tr>
                                <tr>
                                <td>
                                <label>Correo Electrónico:</label>
                                <input type="email" name="email" value="<?php echo $email; ?>" class="form-control" required>
                                </td>
                                <td>
                                <label>Teléfono:</label>
                                <input type="tel" name="telefono" value="<?php echo $telefono; ?>"  class="form-control">
                                </td>
                                </tr>
                                <tr>
                                <td>
                                <label>Dirección:</label>
                                <input type="address" name="direccion" value="<?php echo $direccion; ?>"  class="form-control">
                                </td>
                                <td>
                                <label>Tipo de Socio:</label>
                                <select name="tipo" class="form-control">
                                <option value="<?php echo $tipo; ?>"><?php echo $tipo; ?></option>
                                <option value="cliente">Cliente</option>
                                <option value="proveedor">Proveedor</option>
                                <option value="maquilador">Maquilador</option>
                                </select>
                                </td>
                                </tr>
                                </table>
                                <input type="hidden" name="id" value="<?php echo $id; ?>" >
                                <input type="submit" value="Actualizar Socio de Negocio" class="btn btn-primary">
                                
                                </form>
                                </div>
<?php

}
?>

                <?php 
                
                include("../controller/sn_datatables.php"); 
                mysqli_close($db);
                        
                ?>


                </div>
              </div>
            </div>
         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>

      <?php
          include ("footer.php");

          

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
    <script type="text/javascript" src="datatables/datatables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#theTable').DataTable( {
        "language": {
            "lengthMenu": "Mostrando _MENU_ registros por pagina",
            "zeroRecords": "Nothing found - sorry",
            "info": "Mostrando pagina _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)",
			"search": "Buscar"
			
        }
    } );
} );
    </script>
  </body>
</html>