<?php



  session_start();
      if($_SESSION['login_user']<>""){
        
 
      include("../main/session.php");

      }else{

        ?>
        <script type="text/javascript">
        window.location="../main/logout.php";
        </script>
        <?php
      }

      
//include("db.php"); // Asegúrate de incluir db.php




if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conecta a la base de datos (debes configurar las credenciales de conexión)
    //$mysqli = new mysqli('localhost', 'usuario', 'contraseña', 'nombre_base_de_datos');
    
    // Verifica la conexión
    /*if ($mysqli->connect_error) {
        die('Error de conexión: ' . $mysqli->connect_error);
    */

    // Obtiene los datos del formulario
    $title = $_POST['title'];
    $start = $_POST['start'];
    $end = isset($_POST['end']) ? $_POST['end'] : null;


// Verifica si ya existen eventos en las fechas seleccionadas
$sql1 = "SELECT COUNT(*) as count FROM eventos WHERE start >= ? AND end <= ?";
$stmt1 = $db->prepare($sql1);

if ($stmt1 === false) {
    die("Error en la preparación de la consulta: " . $db->error);
}

$stmt1->bind_param("ss", $start, $end);
$stmt1->execute();
$result1 = $stmt1->get_result();
$row1 = $result1->fetch_assoc();

if ($row1['count'] > 0) {
  echo '<script type="text/javascript">
  alert("Ya existen eventos en las fechas seleccionadas. No se pueden insertar eventos duplicados");
  window.location.href="calendario.php";
  </script>';
  
} else {

  $sql = "INSERT INTO eventos (title, start, end) VALUES (?, ?, ?)";
$stmt = $db->prepare($sql);

// Calcula las fechas intermedias y horas
$start_datetime = new DateTime($start);
$end_datetime = new DateTime($end);

// Establece la hora de inicio a las 6:30 de la mañana
$start_datetime->setTime(6, 30, 0);

// Establece la hora de finalización a las 18:30 de la noche (6:30 + 2 horas * 9)
$end_datetime->setTime(18, 30, 0);

// Obtiene el rango de días seleccionados por el usuario
$selected_days = new DatePeriod($start_datetime, new DateInterval('P1D'), $end_datetime);

foreach ($selected_days as $selected_day) {
    // Establece la hora de inicio para cada día
    $current_datetime = clone $selected_day;
    $current_datetime->setTime(6, 30, 0);

    // Inserta 8 eventos para cada día con un intervalo de 2 horas
    for ($i = 0; $i < 8; $i++) {
        $insert_start = $current_datetime->format('Y-m-d H:i:s');

        // Calcula la fecha de finalización como la fecha de inicio más 2 horas
        $insert_end_datetime = clone $current_datetime;
        $insert_end_datetime->modify('+2 hours');
        $insert_end = $insert_end_datetime->format('Y-m-d H:i:s');

        $stmt->bind_param("sss", $title, $insert_start, $insert_end);

        // Ejecuta la consulta
        if ($stmt->execute()) {
            echo '<script type="text/javascript">
            alert("CALENDARIO APERTURADO EN LAS FECHAS SELECCIONADAS.");
            window.location.href="calendario.php";
            </script>';
        } else {
            echo "Error al guardar el evento: " . $stmt->error;
        }

        $current_datetime->modify('+2 hours'); // Añade 2 horas para la siguiente repetición
    }

    // El último evento del día tiene la misma fecha de inicio y fin
    $insert_start = $current_datetime->format('Y-m-d H:i:s');
    $insert_end = $current_datetime->format('Y-m-d H:i:s');

    $stmt->bind_param("sss", $title, $insert_start, $insert_end);

    // Ejecuta la consulta para el último evento del día
    if ($stmt->execute()) {
        echo '<script type="text/javascript">
        alert("CALENDARIO APERTURADO EN LAS FECHAS SELECCIONADAS.");
        window.location.href="calendario.php";
        </script>';
    } else {
        echo "Error al guardar el último evento del día: " . $stmt->error;
    }
}

// Cierra la conexión a la base de datos
$stmt->close();
$db->close();

  

}

}
?>





<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
<head>
<?php
        include ("head.php");

          ?>
          <link href="../css/style.css" rel="stylesheet">

           <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js">
             <link href="/fullcalendar-6.1.9/dist/main.min.css" rel="stylesheet">
              <script src="/fullcalendar-6.1.9/dist/main.min.js"></script>
    
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var calendarEl = document.getElementById('calendario');
                    var calendar = new FullCalendar.Calendar(calendarEl, {
                        initialView: 'dayGridMonth',
                        events: {
                            url: 'eventos.php', // Script para cargar eventos desde la base de datos
                            method: 'GET'
                        }
                    });
                    calendar.render();
                });
          </script>

         



          </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Cargando...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      <!-- Swiper-->
      
      <!-- Section Box Categories-->
      <section style="min-height: 35px;" class="section section-lg section-top-1 bg-gray-4">
        <div class="container offset-negative-1" style="margin-top: 0px;max-width: 100%;">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center" style="display: block;">


                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s" style="max-width: 100%;">
               
                <?php
                if($login_id_nivel== 1 ||  $login_id_nivel== 5){
                    ?> <h2>Apertura De Periodo de Nominación</h2>
                  <form action="calendario.php" method="post" style=" max-width: 400px;">
                    <table>
                    
                      <td><input type="hidden" id="title" name="title" value="DISPONIBLE"readonly="readonly" required ></td>
                      </tr>
                        <td><label for="start">Fecha y hora de inicio:</label></td>
                        <td><input type="date" id="start" name="start" required></td>
                      </tr>
                      <tr>
                        <td><label for="end">Fecha y hora de finalización:</label></td>
                        <td><input type="date" id="end" name="end"></td>
                      </tr>
                    </table>
                    <br>
                    <input type="submit" value="Guardar nominación">
                  </form>
                  <?php
               }
                    ?>

                  </br></br>

                
                        <?php
                  include ("../controller/calendario_controller.php");

                  ?>


                </div>
              </div>
            </div>
         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>

      <?php
          include ("footer.php");

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
    
  </body>
</html>