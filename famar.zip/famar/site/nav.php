<div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-corporate" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-xxl-layout="rd-navbar-static" data-xxl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="106px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
            <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
            <div class="rd-navbar-aside-outer">
              <div class="rd-navbar-aside">
                <!-- RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!-- RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                  <!-- RD Navbar Brand-->
                  <div class="rd-navbar-brand">
                    <!--Brand--><a class="brand" href="index.php"><img style="max-width: 100px;" src="images/nexus-logo.png" alt="" width="225" height="18"/></a>
                    <a class="brand" href="index.php"><img style="max-width: 125px;" src="images/logo-Famar-completo.png" alt="" width="225" height="18"/></a>
                 
                  </div>
                </div>
                <div class="rd-navbar-aside-right rd-navbar-collapse">
                  <ul class="rd-navbar-corporate-contacts">
                    <li>
                      <div class="unit unit-spacing-xs">
                        <div class="unit-left"><!--<span class="icon fa fa-clock-o"></span>--></div>
                        <div class="unit-body">
                         <!-- <p>09:00<span>am</span> — 05:00<span>pm</span></p>-->
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="unit unit-spacing-xs">
                        <div class="unit-left"><!--<span class="icon fa fa-phone"></span>--></div>
                        <div class="unit-body"><!--<a class="link-phone" href="tel:#">+1 323-913-4688</a>--></div>
                      </div>
                    </li>
                    <div id="fechaActual"> </div>
          
                  </ul>
                
                  <a class="button button-md button-default-outline-2 button-ujarak" href="#"><div id="reloj"></div></a>
                  <?php
                if($_SESSION['login_user']<>"" and  $login_id_nivel<> 2 ){
                    ?>
                  <a class="button button-md button-default-outline-2 button-ujarak" href="#"><div id="proximoEvento"></div></a>
                  <?php
                }
                    ?>
                  <style>
                          #reloj {
                              font-size: 24px;
                          }
                      </style>

    
    <!-- El resto de tu contenido -->
    
    <script>
        // Función para actualizar el reloj en tiempo real en formato de 12 horas (AM/PM)
        function actualizarReloj() {
            const reloj = document.getElementById("reloj");
            const ahora = new Date();
            const hora = ahora.getHours();
            const minutos = ahora.getMinutes();
            const segundos = ahora.getSeconds();
            const ampm = (hora >= 12) ? "PM" : "AM";
            const hora12 = (hora % 12) || 12; // Ajuste para mostrar "12" en lugar de "0" a las 12 PM

            const horaLocal = hora12 + ":" + (minutos < 10 ? "0" : "") + minutos + ":" + (segundos < 10 ? "0" : "") + segundos + " " + ampm;
            reloj.innerHTML = horaLocal;
        }

        // Actualiza el reloj cada segundo
        setInterval(actualizarReloj, 1000);

        // Llama a la función para mostrar el reloj en tiempo real en formato de 12 horas
        actualizarReloj();
    </script>






<script>
        // Función para mostrar el próximo evento
        function mostrarProximoEvento(eventos) {
            const ahora = new Date();
            const eventosFuturos = eventos.filter(evento => new Date(evento.start) > ahora);

            if (eventosFuturos.length > 0) {
                eventosFuturos.sort((a, b) => new Date(a.start) - new Date(b.start));
                const proximoEvento = eventosFuturos[0];
                const proximoEventoDiv = document.getElementById("proximoEvento");

                // Comparar con la hora actual y cambiar el color si está a 30 minutos o menos
                const inicioEvento = new Date(proximoEvento.start);
                const tiempoRestante = inicioEvento - ahora;
                const minutosRestantes = tiempoRestante / 60000; // 60000 milisegundos en un minuto

                if (minutosRestantes <= 30) {
                    proximoEventoDiv.style.color = "red"; // Cambiar el color a rojo
                }

                proximoEventoDiv.innerHTML = `Próximo evento: ${proximoEvento.title} a las ${proximoEvento.start}`;
            } else {
                const proximoEventoDiv = document.getElementById("proximoEvento");
                proximoEventoDiv.innerHTML = "No hay eventos futuros.";
            }
        }

        // Recuperar eventos desde PHP (debes ajustar la ruta al archivo PHP)
        fetch('../controller/obtenerEventosDesdeBD.php') // Asegúrate de que esta ruta sea la correcta
            .then(response => response.json())
            .then(eventos => mostrarProximoEvento(eventos))
            .catch(error => console.error(error));
    </script>









                </div>
              </div>
            </div>
            
            <div class="rd-navbar-main-outer" STYLE="background: #002877;">
              <div class="rd-navbar-main">
                <div class="rd-navbar-nav-wrap">
                
                  <ul class="list-inline list-inline-md rd-navbar-corporate-list-social">
                  
                    <!--<li><a class="icon fa fa-facebook" href="#"></a></li>
                    <li><a class="icon fa fa-twitter" href="#"></a></li>
                    <li><a class="icon fa fa-google-plus" href="#"></a></li>
                    <li><a class="icon fa fa-instagram" href="#"></a></li>-->
                    
                  <!--  <li><a class="icon a fa-users" href="#"></a></li>-->
                    <?php if(!isset($_SESSION['login_user'])){ ?>

                    <li><a class="icon a fa-users" href="#" onclick="openPopup()"> Iniciar Sesión</a></li>
                    <?php }  else{  ?>

                    
                    <li><a class="icon a fa-check-square-o"> <?php echo $login_session; ?> - <?php echo $login_nivel; ?></a></li>
                    <li><a class="icon a fa-window-close-o" href="../main/logout.php"></a>Cerrar Sesión</li>
                    <?php
                if($_SESSION['login_user']<>"" and  $login_id_nivel<> 2 ){
                    ?>
                    <li><a class="icon a fa fa-play" href="status.php"></a></li>
                    <?php
                }
                    ?>
                  
                  <?php }?>

               
                  </ul>
                  <!-- RD Navbar Nav-->
                <ul class="rd-navbar-nav">
                  
                    <li class="rd-nav-item active"><a class="rd-nav-link" href="index.php">INICIO</a></li>
                    <?php
                if($_SESSION['login_user']<>"" and  $login_id_nivel<> 2 ){
                    ?>
                    <li class="rd-nav-item rd-nav-item-with-submenu">
                      <a class="rd-nav-link" href="#">PROCESAR</a>
                      <!-- Submenú -->
                      <ul class="rd-menu rd-navbar-dropdown">
                      <li class="rd-dropdown-item"><a href="laboratorio.php">LABORATORIO</a>
                               <!-- <ul class="rd-menu rd-navbar-dropdown">
                                    <li class="rd-dropdown-item"><a href="laboratorio.php">RECIBO DE MATERIA PRIMA</a></li>
                                    <li class="rd-dropdown-item"><a href="sn_consultas.php">CONTROL DE BLANQUEO R3</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">INSPECCION DE LLENADO SOLIDO</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">CONTROL DE ALMACENAMIENTO DE ACEITES</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">CONTROL DE REFINACION FISICA R3</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">INSPECCION DE LLENADO DE LIQUIDO</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">DESPACHO DE PRODUCTO A GRANEL</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">CONTROL DE PROCESO FRACCIONAMIENTO</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">REGISTRO LECTURAS NMR</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">RECIBO DE CARBON MINERAL</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">ANALISIS DE DOBI</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">CONTROL AGUAS DE CALDERA</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">CONTROL DEL FLORENTINO</a></li>
                                </ul>-->
                          </li>
                          
                          <li class="rd-dropdown-item"><a href="asignaciones.php">NOMINACIONES</a></li>
                          <li class="rd-dropdown-item"><a href="#">CHEQUEOS</a>
                          <ul class="rd-menu rd-navbar-dropdown">
                          <li class="rd-dropdown-item"><a href="llegada.php">LLEGADA</a></li>
                                    <li class="rd-dropdown-item"><a href="porteria.php">PORTERIA</a></li>
                                    <li class="rd-dropdown-item"><a href="ssta.php">SALUD OCUPACIONAL</a></li>
                                    <li class="rd-dropdown-item"><a href="bascula.php">BASCULA</a></li>
                                    <li class="rd-dropdown-item"><a href="toma_muestras.php">TOMA DE MUESTRAS</a></li>
                                    <li class="rd-dropdown-item"><a href="tanque.php">UBICACION DE TANQUE</a></li>
                                    <li class="rd-dropdown-item"><a href="descargue.php">DESCARGUE</a></li>
                                    <li class="rd-dropdown-item"><a href="bascula_salida.php">BASCULA PARA SALIDA</a></li>
                                    
                                   
                                </ul>
                                </li>
                         <!--  <li class="rd-dropdown-item"><a href="service3.html">CONDUCTORES</a></li>
                          <li class="rd-dropdown-item"><a href="service3.html">MANTENIMIENTO</a></li>
                          <li class="rd-dropdown-item"><a href="service3.html">VEHICULOS</a></li>-->
                          <li class="rd-dropdown-item"><a href="logistica.php">PARAMETRIZACIÓN</a>
                               <!-- <ul class="rd-menu rd-navbar-dropdown">
                                    <li class="rd-dropdown-item"><a href="creacion_sn.php">Creacion Socio de Negocio</a></li>
                                    <li class="rd-dropdown-item"><a href="sn_consultas.php">Administración PROVEEDORES/CLIENTES</a></li>
                                    <li class="rd-dropdown-item"><a href="cupos_nominacion.php">Asignación PROVEEDORES/CLIENTES</a></li>
                                </ul>-->
                          </li>
                         



                      </ul>
                  </li>
                  
                  <li class="rd-nav-item rd-nav-item-with-submenu">
                    <a class="rd-nav-link" href="#">CONSULTA</a>
                    <!-- Submenú -->
                    <ul class="rd-menu rd-navbar-dropdown">
                        <li class="rd-dropdown-item"><a href="asignaciones_consultas.php">NOMINACIONES</a></li>
</a></li>
                        <li class="rd-dropdown-item"><a href="service2.html">CARGAS</a></li>
                        <li class="rd-dropdown-item"><a href="service3.html">CONDUCTORES</a></li>
                        <li class="rd-dropdown-item"><a href="service3.html">MANTENIMIENTO</a></li>
                        <li class="rd-dropdown-item"><a href="service3.html">VEHICULOS</a></li>
                    </ul>
                </li>






                

                <!--
                    <li class="rd-nav-item"><a class="rd-nav-link" href="about.html">About</a></li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="typography.html">Typography</a></li>
                    
                    <li class="rd-nav-item"><a class="rd-nav-link" href="contact-us.html">Contact Us</a></li>-->
               
                </ul>
                <?php
                }
                    ?>
               
                </div>
              </div>
            </div>
          </nav>
        </div>
       