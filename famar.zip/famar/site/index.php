<?php
include ("../main/login.php");
//∫echo "aqui";

//echo $_SESSION['login_user'];

if($_SESSION['login_user']<>""){
  //echo "if";
	include("../main/session.php");
  }

?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
  <?php
          include ("head.php");

          ?>
    <style>
        /* Estilo para el botón */
        .popup-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        /* Estilo para el popup */
        .popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
        }

        /* Estilo para el contenido del popup */
        .popup-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Estilo para el formulario */
        #login-form {
            text-align: center;
        }
    </style>
    </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Cargando...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      

      <!-- Swiper-->
      <section class="section swiper-container swiper-slider swiper-slider-corporate swiper-pagination-style-2" data-loop="false" data-autoplay="0" data-simulate-touch="false" data-nav="false" data-direction="vertical">
        <div class="swiper-wrapper text-left">
          <div class="swiper-slide context-dark" data-slide-bg="images/Fuente.jpeg" style="height: 480px;">
            <div class="swiper-slide-caption section-md">
              <div class="container">
                <div class="row">
                  <div class="col-md-10">

                  <div id="popup" class="popup">
                        <div class="popup-content" style="width: 350px;">
                            <!-- Formulario de inicio de sesión -->
                            <form id="login-form" action="index.php" method="POST">
                                <h2>Iniciar Sesión</h2>
                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                                <input type="text" name="user" placeholder="Nombre de usuario" required><br><br>
                                <input type="password" name="password" placeholder="Contraseña" required><br><br>
                                <button type="submit">Iniciar Sesión</button>
                                <button type="button" onclick="closePopup()">Cerrar</button>
                            </form>
                        </div>
                    </div>


                   <!--<h6 class="text-uppercase" data-caption-animate="fadeInRight" data-caption-delay="0">Enjoy the Best Destinations with Our Travel Agency</h6>
                    <h2 class="oh font-weight-light" data-caption-animate="slideInUp" data-caption-delay="100"><span>Explore</span><span class="font-weight-bold"> The World</span></h2><a class="button button-default-outline button-ujarak" href="#" data-caption-animate="fadeInLeft" data-caption-delay="0">Get in touch</a>-->
                  </div>
                </div>
              </div>
            </div>
          </div>
         
        </div>
        <!-- Swiper Pagination-->
        <div class="swiper-pagination"></div>
      </section>
      <!-- Section Box Categories-->
<?php
      if($_SESSION['login_user']<>"" and  $login_id_nivel<> 2 ){

        ?>
      <section class="section section-lg section-top-1 bg-gray-4" style="margin-top: -200px;">
        <div class="container offset-negative-1">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center">
                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s">
                  <ul class="list-marked-2 box-categories-list">
                    <li><a href="calendario.php"><img style=" border-radius: 30px;" src="images/calendario.jpg" alt="" width="368" height="420"/></a>
                     <!-- <h5 style="text-shadow: 0 0 0.2em #F87, 0 0 0.2em #F87;" class="box-categories-title">CALENDARIO</h5>-->
                    </li>
                  </ul>
                </div>
                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s">
                  <ul class="list-marked-2 box-categories-list">
                    <li><a href="logistica.php"><img style=" border-radius: 30px;" src="images/logistica.jpg" alt="" width="368" height="420"/></a>
                      <!--<h5 style="text-shadow: 0 0 0.2em #F87, 0 0 0.2em #F87;" class="box-categories-title">LOGISTICA</h5>-->
                    </li>
                  </ul>
                </div>
               
                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s">
                  <ul class="list-marked-2 box-categories-list">
                  <?php
              if($login_id_nivel== 2 ||  $login_id_nivel== 5 ){

                  ?>
                    <li><a href="laboratorio.php"><img style=" border-radius: 30px;" src="images/ico-laboratorio-gris.jpg" alt="" width="368" height="420"/></a>
                      <!--<h5 style="text-shadow: 0 0 0.2em #F87, 0 0 0.2em #F87;" class="box-categories-title">LABORATORIO</h5>-->
                    </li>
                    <?php      
              }else{
                ?>
                <li><a href="laboratorio.php"><img style=" border-radius: 30px;" src="images/ico-laboratorio.jpg" alt="" width="368" height="420"/></a>
                      <!--<h5 style="text-shadow: 0 0 0.2em #F87, 0 0 0.2em #F87;" class="box-categories-title">LABORATORIO</h5>-->
                    </li>
                
                <!--<h5 style="text-shadow: 0 0 0.2em #F87, 0 0 0.2em #F87;" class="box-categories-title">LABORATORIO</h5>-->
              </li>
<?php
              }
              ?>
                  </ul>
                </div>
              
              </div>
            </div>

            <?php
     }

        ?>

         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>
      <?php
          include ("footer.php");

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->

    

    <script>
        // Función para abrir el popup
        function openPopup() {
            document.getElementById("popup").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup() {
            document.getElementById("popup").style.display = "none";
        }
    </script>
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>

  </body>
</html>