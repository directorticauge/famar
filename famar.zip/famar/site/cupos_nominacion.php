<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


  session_start();
      if($_SESSION['login_user']<>""){
        
 
      include("../main/session.php");

      }else{

        ?>
        <script type="text/javascript">
        window.location="../main/logout.php";
        </script>
        <?php
          }


          
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {

                                        $socioNegocio = $_POST['socio_negocio'];
                                        $cupos = $_POST['cupos'];
                                        $cantidad = $_POST['cantidad'];
                                        $fechaIniCupo = $_POST['fecha_ini_cupo'];
                                        $fechaFinCupo = $_POST['fecha_fin_cupo'];



                                                    $sql = "SELECT * FROM socios_de_negocio WHERE id = " . $_POST["socio_negocio"];
                                                    $result = $db->query($sql);
                                                    
                                                    // Verifica si se encontraron resultados
                                                    if ($result->num_rows > 0) {
                                                        // Obtiene el resultado como un arreglo asociativo
                                                        $row = $result->fetch_assoc();
                                                        $nombre_sn = $row["nombre"] . "-" . $row["apellido"];
                                                    }

                                        // Consulta SQL para insertar datos en la base de datos



// Verificar que las fechas proporcionadas no estén dentro del rango de fechas de ningún otro registro del socio de negocio
$verificarSql = "SELECT COUNT(*) as count FROM cupos 
                WHERE CodigoSocioNegocio = ? 
                AND ((FechaInicio > ? AND FechaInicio < ?) 
                OR (FechaFin > ? AND FechaFin < ?))";

$verificarStmt = $db->prepare($verificarSql);

if ($verificarStmt === false) {
    die("Error en la preparación de la consulta de verificación: " . $db->error);
}

// Asociar los parámetros para la consulta de verificación
$verificarStmt->bind_param("issss", $socioNegocio, $fechaIniCupo, $fechaFinCupo, $fechaIniCupo, $fechaFinCupo);

// Ejecutar la consulta de verificación
$verificarStmt->execute();

// Obtener el resultado de la consulta
$verificarResult = $verificarStmt->get_result();
$verificarRow = $verificarResult->fetch_assoc();

// Verificar si ya existe un registro con las mismas fechas del socio de negocio
if ($verificarRow['count'] > 0) {


    echo '<script type="text/javascript">
    alert("Las fechas proporcionadas están dentro del rango de fechas de otro registro del socio de negocio.");
    window.location.href="cupos_nominacion.php";
  </script>';


   // echo "Las fechas proporcionadas están dentro del rango de fechas de otro registro del socio de negocio.";
} else {

                                        $sql = "INSERT INTO cupos (CodigoSocioNegocio, CantidadCupos, Cantidad, FechaInicio, FechaFin) VALUES (?, ?, ?, ?, ?)";
                                        $stmt = $db->prepare($sql);

                                        if ($stmt === false) {
                                            die("Error en la preparación de la consulta: " . $db->error);
                                        }

                                        // Asociar los parámetros
                                        $stmt->bind_param("iiiss", $socioNegocio, $cupos, $cantidad, $fechaIniCupo, $fechaFinCupo);

                                        // Ejecutar la consulta
                                       
                                      


                            
                         
                            if ($stmt->execute()) {
                            // Actualización exitosa, envía el correo electrónico
                            require 'PHPMailer-master/src/Exception.php';
                            require 'PHPMailer-master/src/PHPMailer.php';
                            require 'PHPMailer-master/src/SMTP.php';
                        
                            $mail = new PHPMailer();
                        
                            // Configura el servidor SMTP
                            $mail->isSMTP();
                            $mail->Host = 'smtp.hostinger.com'; // Reemplaza con la configuración de tu servidor SMTP
                            $mail->SMTPAuth = true;
                            $mail->Username = 'directortic@augesoluciones.com'; // Reemplaza con tu dirección de correo
                            $mail->Password = 'nefs1989NN**'; // Reemplaza con tu contraseña
                            $mail->SMTPSecure = 'tls'; // O 'ssl' si es necesario
                            $mail->Port = 587; // O el puerto SMTP correspondiente
                        
                            // Configura el remitente y el destinatario
                            $mail->setFrom('directortic@augesoluciones.com', 'NEXUS SOFTWARE');
                            $mail->addAddress('nforero18@gmail.com', 'Nexus C.I. Famar');
                        
                        
                            // Asunto y contenido del correo
                            $mail->isHTML(true);
                            $mail->Subject = 'HABILITACIÓN DE CUPOS DE DESCARGUE FAMAR.';
                        
                           // Agrega los detalles de la tabla en el mensaje
                                    $message .= '<table style="width: 50%; margin: 0 auto; border-collapse: collapse; text-align: left; border: 1px solid #ddd;">';

                                    // Agrega la fila del título de la tabla junto con los logotipos
                                    $message .= '<tr>';
                                    $message .= '<th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">';
                                    $message .= '<img src="https://famar.augesoluciones.com/site/images/nexus-logo.png" style="width: 50px;float: left; margin-right: 10px;">';
                                    $message .= 'Cupo de Nominacion Reservado';
                                    $message .= '<img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" style="width: 200px;float: right; margin-left: 10px;">';
                                    $message .= '</th>';
                                    $message .= '</tr>';

                                    // Agrega una fila con el contenido del mensaje     $cupos, $cantidad, $fechaIniCupo, $fechaFinCupo
                                    $message .= '<tr>';
                                    $message .= '<td style="border: 1px solid #ddd; padding: 8px;">Señor ' . $nombre_sn . ' se le ha aperturado '. $cupos.' cupos para el periodo correspondientes entre  ' . $fechaIniCupo . ' y '.$fechaFinCupo.'.</td>';
                                    
                                    
                                    $message .= '</tr>';
                                    $message .= '<tr>';
                                    $message .= '<td style="border: 1px solid #ddd; padding: 8px;">Para la nominación presione el siguiente boton:</td>';
                                    
                                    
                                    $message .= '</tr>';
                                    $message .= '</tr>';
                                    $message .= '<tr>';
                                    $message .= '<div style="text-align: center;"><a href="https://famar.augesoluciones.com/site/asignaciones.php"><button style="
                                    height: 50px;
                                " type="button">NOMINESE AQUÍ</button></a></DIV>';
                                  //  $message .= '<td style="border: 1px solid #ddd; padding: 8px;"><a href="https://famar.augesoluciones.com/site/asignaciones.php"></a>https://famar.augesoluciones.com/site/asignaciones.php</td>';
                                    
                                    
                                    $message .= '</tr>';

                                    // Cierra la tabla
                                    $message .= '</table>';

                            // Agrega los detalles del registro actualizado aquí...
                            
                            $mail->CharSet = 'UTF-8'; // Configura la codificación a UTF-8
                            $mail->Body = $message;
                        
                            // Envía el correo
                            if ($mail->send()) {
                                echo 'Correo enviado exitosamente.';
                            } else {
                                echo 'Error al enviar el correo: ' . $mail->ErrorInfo;
                            }
                        
                            echo '<script type="text/javascript">
                                    alert("Registro actualizado con éxito");
                                    window.location.href="cupos_nominacion.php";
                                  </script>';
                        } else {
                            echo "Error: " . $stmt->error;
                        }

        }
                        $verificarStmt->close();
                        $stmt->close();
                        $db->close();
                        }
                        




?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
<head>
<?php
          include ("head.php");

          ?>
          </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Loading...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      <!-- Swiper-->
      
      <!-- Section Box Categories-->
      <section style="min-height: 35px;" class="section section-lg section-top-1 bg-gray-4">
        <div class="container offset-negative-1" style="margin-top: 0px;">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center" style="display: block;">


                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s" style="max-width: 100%;">

                <?php include("../vistas_form/cupos_form.php"); ?>


                </div>
              </div>
            </div>
         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>

      <?php
          include ("footer.php");

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>