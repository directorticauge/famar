<?php
// obtener_informacion.php

// Conectar a la base de datos (asegúrate de configurar estos valores)
include("../main/session.php");

// Obtener el ID enviado por la solicitud AJAX
$id = $_GET['id'];

// Utilizar una sentencia preparada para evitar inyección SQL
$sql = "SELECT * FROM asignaciones WHERE id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Devolver la información como un objeto JSON
    $row = $result->fetch_assoc();
    $sn = $row['socio_negocio'];
    $sql1 = "SELECT * FROM socios_de_negocio WHERE id = ?";
    $stmt1 = $db->prepare($sql1);
    $stmt1->bind_param("i", $sn);
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    $row1 = $result1->fetch_assoc();

    $sn_nombre = $row1['nombre']." ".$row1['apellido'];

    // Devolver la información como un objeto JSON
    $response = [
        'placa' => $row['placa'],
        'sn_nombre' => $sn_nombre,
        
        'tipo_producto' => $row['tipo_producto'],
        'origen' => $row['origen'],
        'cantidad' => $row['cantidad'],
        'remision' => $row['remision'],
        'acidez1' => $row['acidez'],
        'humedad1' => $row['humedad'],
        'impurezas1' => $row['impurezas']
       
    ];

    echo json_encode($response);

} else {
    echo "No se encontró información para el ID proporcionado.";
}

// Cerrar la conexión a la base de datos
$stmt->close();
$stmt1->close();
$db->close();
?>
