<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


  session_start();
      if($_SESSION['login_user']<>""){
        
 
      include("../main/session.php");

      }else{

        ?>
        <script type="text/javascript">
        window.location="../main/logout.php";
        </script>
        <?php
          }

/*consulta de datatables*/
$sql = "SELECT * FROM asignaciones";
               
                $result = $db->query($sql);
                $arr_lideres = [];
                if ($result->num_rows > 0) {
                    $arr_lideres = $result->fetch_all(MYSQLI_ASSOC);
                }
/*consulta de datatables*/

          
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {

                          echo "entro al post";
                        
                            // Recopila los datos del formulario
                            $placa = $_POST["placa"];
                            $remolque = $_POST["remolque"];
                            $nombre_conductor = $_POST["nombre_conductor"];
                            $cedula_conductor = $_POST["cedula_conductor"];
                            $arl = $_POST["arl"];
                            $eps = $_POST["eps"];
                            $tipo_producto = $_POST["tipo_producto"];
                            $origen = $_POST["origen"];
                            $cantidad = $_POST["cantidad"];
                            $calidad = $_POST["calidad"];

                            // Procesa los sellos de seguridad del 0 al 11
                            $sellos_de_seguridad = array();
                            for ($i = 0; $i <= 11; $i++) {
                                $sello = $_POST["sello_seguridad_" . $i];
                                $sellos_de_seguridad[] = $sello;
                            }

                            

                            // Inserta los datos en la base de datos
                            $sql = "INSERT INTO asignaciones (placa, remolque, nombre_conductor, cedula_conductor, arl, eps, tipo_producto, origen, cantidad, calidad";
                            for ($i = 0; $i <= 11; $i++) {
                                $sql .= ", sello_seguridad_" . $i;
                            }
                            $sql .= ") VALUES ('$placa', '$remolque', '$nombre_conductor', '$cedula_conductor', '$arl', '$eps', '$tipo_producto', '$origen', $cantidad, '$calidad'";
                            foreach ($sellos_de_seguridad as $sello) {
                                $sql .= ", '$sello'";
                            }
                            $sql .= ")";

                        //    echo "registro";
// Tu código de procesamiento del formulario y la consulta SQL aquí

                          
                    
                        }
                        




?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <?php
          include ("head.php");

          ?>
</head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Cargando...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      <!-- Swiper-->
      
      <!-- Section Box Categories-->
      <section style="min-height: 35px;" class="section section-lg section-top-1 bg-gray-4">
        <div class="container offset-negative-1" style="margin-top: 0px;">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center" style="display: block;">


                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s" style="max-width: 100%;">

                <?php include("../controller/asignaciones_datatables.php"); ?>


                </div>
              </div>
            </div>
         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>

      <?php
          include ("footer.php");

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
    <script type="text/javascript" src="datatables/datatables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#theTable').DataTable( {
        "language": {
            "lengthMenu": "Mostrando _MENU_ registros por pagina",
            "zeroRecords": "Nothing found - sorry",
            "info": "Mostrando pagina _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)",
			"search": "Buscar"
			
        }
    } );
} );
    </script>
  </body>
</html>