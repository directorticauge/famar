<?php
// obtener_informacion_icono.php

// Conectar a la base de datos (ajusta la conexión según tu configuración)
// Conectar a la base de datos (asegúrate de configurar estos valores)

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u362358503_famar');
define('DB_PASSWORD', 'Famar2023**%#');
define('DB_DATABASE', 'u362358503_famar');

// Crear conexión con la base de datos.
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);


/* comprobar la conexión */
 if (mysqli_connect_errno()) {
 printf("Falló la conexión: %s\n", mysqli_connect_error());
 exit();
}

// Obtener el ID enviado por la solicitud AJAX
$iconId = $_GET['id'];

// Realizar una consulta a la base de datos para obtener la información
$sql = "SELECT ck_porteria_observaciones FROM eventos WHERE id_nominacion = $iconId";
$resultado = $db->query($sql);

if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo $fila['ck_porteria_observaciones'];
} else {
    echo "Información no encontrada";
}

// Cerrar la conexión a la base de datos
$db->close();
?>
