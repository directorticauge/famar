<?php
// obtener_informacion_porteria.php

// Conectar a la base de datos (asegúrate de configurar estos valores)
include("../main/session.php");

// Obtener el ID enviado por la solicitud AJAX
$id = $_GET['id'];

// Realizar una consulta a la base de datos para obtener la información
$sql = "SELECT * FROM asignaciones inner join eventos on asignaciones.id=eventos.id_nominacion WHERE eventos.id_nominacion = $id";
$result = $db->query($sql);


echo "<style>";
echo "table {";
echo "    margin: 0 auto; /* Margen izquierdo y derecho automático para centrar */";
echo "    width: 100%; /* Ajusta el ancho según tus necesidades */";
echo "    border-collapse: collapse; /* Colapso de bordes para un aspecto más limpio */";
echo "    font-family: Arial, sans-serif; /* Tipo de fuente */";
echo "}";
echo "th, td {";
echo "    padding: 12px; /* Ajusta el relleno según tus necesidades */";
echo "    text-align: left; /* Alineación del texto */";
//echo "    border: 1px solid #ddd; /* Borde para celdas */";
echo "}";
echo "th {";
echo "    background-color: #f2f2f2; /* Color de fondo para las celdas de encabezado */";
echo "    font-weight: bold; /* Resaltado de texto para los títulos */";
echo "}";
echo "</style>";

if ($result->num_rows > 0) {
    // Construir la tabla HTML
    $row = $result->fetch_assoc();
    $sn = $row['socio_negocio'];
    $sql1 = "SELECT * FROM socios_de_negocio WHERE id = $sn";
    $result1 = $db->query($sql1);
    $row1 = $result1->fetch_assoc();

    $sn_nombre = $row1['nombre']." ".$row1['apellido'];

    echo "<table border='1'>";
    echo "<tr><td style='background: antiquewhite;'>PLACA:</td><td>".$row['placa']."</td>";
    echo "<td style='background: antiquewhite;'>PROVEEDOR</td><td>".$sn_nombre."</td></tr>";
    echo "<tr><td style='background: antiquewhite;'>REMOLQUE:</td><td>".$row['remolque']."</td>";
   
    echo "<td style='background: antiquewhite;'>PRODUCTO:</td><td>".$row['tipo_producto']."</td></tr>";
    echo "<tr><td style='background: antiquewhite;'>CANTIDAD:</td><td>".$row['cantidad']."</td>";
    
    echo "<td style='background: antiquewhite;'>REMISION:</td><td>".$row['remision']."</td></tr>";
    echo "<tr><td style='background: antiquewhite;'>TANQUE 1:</td><td>".$row['tanque1']."</td>";
    echo "<td style='background: antiquewhite;'>TANQUE 2:</td><td>".$row['tanque2']."</td></tr>";
   
   
    echo "</table>";
    
} else {
    echo "No se encontró información para el ID proporcionado.";
}

// Cerrar la conexión a la base de datos
$db->close();
?>
