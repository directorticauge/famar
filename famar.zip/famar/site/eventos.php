<?php
include("../main/session.php");

$sql = "SELECT id, title, start, end,color FROM eventos";
$result = $db->query($sql);

// Crea un array para almacenar los eventos
$eventos = array();

while ($row = $result->fetch_assoc()) {

    $color = $row['color'];
    $eventos[] = array(
        'id' => $row['id'],
        'title' => $row['title'],
        'start' => $row['start'],
        'end' => $row['end'],
        'color' =>  $color,
    );
}

// Cierra la conexión a la base de datos
$db->close();

// Devuelve los eventos en formato JSON
header('Content-Type: application/json');
echo json_encode($eventos);

?>