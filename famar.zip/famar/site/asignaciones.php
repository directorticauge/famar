<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


  session_start();
      if($_SESSION['login_user']<>""){
        
 
      include("../main/session.php");

      }else{

        ?>
        <script type="text/javascript">
        window.location="../main/logout.php";
        </script>
        <?php
          }


          
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {

                         // echo "entro al post";
                        
                            // Recopila los datos del formulario
                            $socio_negocio = $_POST["socio_negocio"];
                            $cupo_nominacion = $_POST["cupo_nominacion"];
                            $placa = $_POST["placa"];
                            $remolque = $_POST["remolque"];
                            $nombre_conductor = $_POST["nombre_conductor"];
                            $cedula_conductor = $_POST["cedula_conductor"];
                            $arl = $_POST["arl"];
                            $eps = $_POST["eps"];
                            $tipo_producto = $_POST["tipo_producto"];
                            $origen = $_POST["origen"];
                            $cantidad = $_POST["cantidad"];
                            $acidez = $_POST["acidez"];
                            $humedad = $_POST["humedad"];
                            $impurezas = $_POST["impurezas"];
                            $remision = $_POST["remision"];


                            // Procesa los sellos de seguridad del 0 al 11
                            $sellos_de_seguridad = array();
                            for ($i = 1; $i <= 12; $i++) {
                                $sello = $_POST["sello_seguridad_" . $i];
                                $sellos_de_seguridad[] = $sello;
                            }

                            $sql1 = "SELECT * FROM socios_de_negocio WHERE id = " . $_POST["socio_negocio"];
                            $result1 = $db->query($sql1);
                          
                            // Verifica si se encontraron resultados
                            if ($result1->num_rows > 0) {
                                // Obtiene el resultado como un arreglo asociativo
                                $row1 = $result1->fetch_assoc();
                                $nombre_sn = $row1["nombre"] . "-" . $row1["apellido"];
                            }
                           // $db->close();


                            $sql = "UPDATE eventos SET title = ?,color='#df0014', sn_nominado = ? WHERE id = ?";

                            $stmt = $db->prepare($sql);
                            
                            if ($stmt === false) {
                                die("Error en la preparación de la consulta: " . $db->error);
                            }
                            $nombre_evento=$nombre_sn." - ".$tipo_producto;
                            // Asocia los parámetros
                            $stmt->bind_param("sii",strtoupper($nombre_evento), $socio_negocio, $cupo_nominacion);
                            
                            // Ejecuta la consulta
                            if ($stmt->execute()) {
                              echo '<script>alert("Agendamiento exitoso.");</script>';
                            } else {
                                echo "Error al actualizar: " . $stmt->error;
                            }
                       

                           

                            // Inserta los datos en la base de datos
                            $sql = "INSERT INTO asignaciones (socio_negocio,cupo_nominacion,placa, remolque, nombre_conductor, cedula_conductor, arl, eps, tipo_producto, origen, cantidad, acidez,humedad,impurezas,remision";
                            for ($i = 1; $i <= 12; $i++) {
                                $sql .= ", sello_seguridad_" . $i;
                            }
                            $sql .= ") VALUES ('$socio_negocio', '$cupo_nominacion','$placa', '$remolque', '$nombre_conductor', '$cedula_conductor', '$arl', '$eps', '$tipo_producto', '$origen', $cantidad, '$acidez', '$humedad', '$impurezas','$remision'";
                            foreach ($sellos_de_seguridad as $sello) {
                                $sql .= ", '$sello'";
                            }
                            $sql .= ")";

                        //    echo "registro";
// Tu código de procesamiento del formulario y la consulta SQL aquí

                          

                            
                            

if ($db->query($sql) === true) {


                              // Obtener el ID autoincremental recién insertado
                              $id_asignacion = mysqli_insert_id($db);
                              echo $id_asignacion;
                              // Insertar el ID en la tabla 'eventos'
                              //$sql_insertar_evento = "INSERT INTO eventos (nominacion_id) VALUES ('$id_asignacion')";
                              $sql_actualizar_evento = "UPDATE eventos SET id_nominacion = '$id_asignacion' WHERE id=".$_POST["cupo_nominacion"];
    
                              //$cupo_nominacion
                              
                              // Ejecutar la consulta de inserción en la tabla 'eventos'
                              if ($db->query($sql_actualizar_evento) === true) {
                                  echo "Registros insertados correctamente.";
                              } else {
                                  echo "Error al insertar en la tabla 'eventos': " . $db->error;
                              }
                            

                            // Cerrar la conexión a la base de datos
                           // mysqli_close($db);

 

  $sql2 = "SELECT * FROM eventos WHERE id = " . $_POST["cupo_nominacion"];
          $result2 = $db->query($sql2);
          
          // Verifica si se encontraron resultados
          if ($result2->num_rows > 0) {
              // Obtiene el resultado como un arreglo asociativo
              $row2 = $result2->fetch_assoc();
              $start = $row2["start"];
              $end= $row2["end"];
          }
    // Registro exitoso, muestra un mensaje de alerta
    
    //echo "entro al mailer";
                            require 'PHPMailer-master/src/Exception.php';
                            require 'PHPMailer-master/src/PHPMailer.php';
                            require 'PHPMailer-master/src/SMTP.php';

    $mail = new PHPMailer();

    // Configura el servidor SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.hostinger.com'; // Reemplaza con la configuración de tu servidor SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'directortic@augesoluciones.com'; // Reemplaza con tu dirección de correo
    $mail->Password = 'nefs1989NN**'; // Reemplaza con tu contraseña
    $mail->SMTPSecure = 'tls'; // O 'ssl' si es necesario
    $mail->Port = 587; // O el puerto SMTP correspondiente

    // Configura el remitente y el destinatario
    $mail->setFrom('directortic@augesoluciones.com', 'NEXUS SOFTWARE');
    $mail->addAddress('nforero18@gmail.com', 'Nexus C.I. Famar');

    // Asunto y contenido del correo
    $mail->isHTML(true);
    
    
    $mail->Subject = 'Nominación  '.$nombre_sn .' - ' . $tipo_producto . ' - ' . $start .'. ';
    
    // Construye el mensaje de correo en formato HTML
    $message = '<h2>NOMINACION EXITOSA</h2>';
    $message .= '<p>Los siguientes datos se han registrado exitosamente:</p>';
    
    $message .= '<table style="width: 50%; margin: 0 auto; border-collapse: collapse; text-align: left; border: 1px solid #ddd;">';

    // Agrega la fila del título de la tabla junto con los logotipos
    $message .= '<tr>';
    $message .= '<th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">';
    $message .= '<img src="https://famar.augesoluciones.com/site/images/nexus-logo.png" style="width: 50px;float: left; margin-right: 10px;">';
   
    $message .= 'Detalle de Nominacion Exitosa';
    $message .= '</th>';
    $message .= '<th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">';
    $message .= '<img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" style="width: 260px;float: right; margin-left: 10px;">';
    $message .= '</th>';
    $message .= '</tr>';

    $message .= '<tr><td><b>Socio de Negocio</b></td><td>' . $nombre_sn  . '</td></tr>';
    $message .= '<tr><td><b>Cupo de Nominacion</b></td><td> De ' . $start . ' a '.$end.'</td></tr>';
    $message .= '<tr><td><b>Placa</b></td><td>' . $placa . '</td></tr>';
    $message .= '<tr><td><b>Remolque</b></td><td>' . $remolque . '</td></tr>';
    $message .= '<tr><td><b>Nombre del Conductor</b></td><td>' . $nombre_conductor . '</td></tr>';
    $message .= '<tr><td><b>Cédula del Conductor</b></td><td>' . $cedula_conductor . '</td></tr>';
    $message .= '<tr><td><b>ARL</b></td><td>' . $arl . '</td></tr>';
    $message .= '<tr><td><b>EPS</b></td><td>' . $eps . '</td></tr>';
    $message .= '<tr><td><b>Tipo de Producto</b></td><td>' . $tipo_producto . '</td></tr>';
    $message .= '<tr><td><b>Origen</b></td><td>' . $origen . '</td></tr>';
    $message .= '<tr><td><b>Cantidad</b></td><td>' . $cantidad . '</td></tr>';
    $message .= '<tr><td><b>Acidez</b></td><td>' . $acidez . '</td></tr>';
    $message .= '<tr><td><b>Humedad</b></td><td>' . $humedad . '</td></tr>';
    $message .= '<tr><td><b>Impurezas</b></td><td>' . $impurezas . '</td></tr>';
    $message .= '<tr><td><b>Remision</b></td><td>' . $remision . '</td></tr>';
    for ($i = 1; $i <= 12; $i++) {
        $message .= '<tr><td><b>Sello de Seguridad ' . $i . '</b></td><td>' . $_POST["sello_seguridad_" . $i] . '</td></tr>';
    }
    $message .= '</table>';
    $mail->CharSet = 'UTF-8'; // Configura la codificación a UTF-8
    $mail->Body = $message;
  
    // Envía el correo

   
    if ($mail->send()) {
        echo 'Correo enviado exitosamente.';
    } else {
        echo 'Error al enviar el correo: ' . $mail->ErrorInfo;
    }


    echo '<script>alert("Notificación exitosa.");</script>';

   echo '<script type="text/javascript">
        window.location="asignaciones.php";
        </script>';

    
} else {
    // Si hay un error en la consulta SQL
    echo "Error al registrar los datos: " . $conexion->error;
}


                            // Cierra la conexión a la base de datos
                            $conexion->close();
                            $stmt->close();
                            $db->close();
                        }
                        




?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
<head>
<?php
          include ("head.php");

          ?>
          </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Loading...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      <!-- Swiper-->
      
      <!-- Section Box Categories-->
      <section style="min-height: 35px;" class="section section-lg section-top-1 bg-gray-4">
        <div class="container offset-negative-1" style="margin-top: 0px;">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center" style="display: block;">


                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s" style="max-width: 100%;">

                <?php include("../vistas_form/asignaciones_form.php"); ?>


                </div>
              </div>
            </div>
         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>

      <?php
          include ("footer.php");

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>