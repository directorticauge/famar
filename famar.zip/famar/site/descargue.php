<?php

//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\SMTP;
//use PHPMailer\PHPMailer\Exception;


  session_start();
      if($_SESSION['login_user']<>""){
        
 
      include("../main/session.php");

      }else{

        ?>
        <script type="text/javascript">
        window.location="../main/logout.php";
        </script>
        <?php
          }


          
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                          try {
                         // echo "entro al post";
                         
                         $id_nominacion= $_POST["cupo_nominacion"];
                         $usuario = $_POST["usuario"];
                         $fecha = $_POST["fecha"];
                         $validacion = $_POST["validacion"];
                         $observaciones = $_POST["observaciones"];
                         $tanque1inicial = $_POST["tanque1inicial"];
                         $tanque1final = $_POST["tanque1final"];
                         $tanque2inicial = $_POST["tanque2inicial"];
                         $tanque2final = $_POST["tanque2final"];
                       
                     
                         // Obtener el ID del evento que deseas actualizar (debes tener algún mecanismo para obtener este ID, puede ser a través de un parámetro en la URL o mediante un campo oculto en el formulario)
                         //$id_evento = $_POST["id_evento"];
                     
                         // Preparar la consulta de actualización
                         $sql = "UPDATE eventos SET 
                                          usr_ck_descargue=?,
                                          fecha_ck_descargue= ?, 
                                          ck_descargue = ?, 
                                          ck_observaciones_descargue = ? ,
                                          tanque1inicial=?,
                                          tanque1final=?,
                                          tanque2inicial=?,
                                          tanque2final=?
                                          WHERE id_nominacion = ?";

                                  // Preparar la sentencia
                                  $stmt = $db->prepare($sql);

                                  // Vincular parámetros
                                  $stmt->bind_param("ssssssssi", $usuario, $fecha, $validacion, $observaciones, $tanque1inicial , $tanque1final, $tanque2inicial , $tanque2final, $id_nominacion);

                                  // Ejecutar la consulta de actualización
                                  if ($stmt->execute()) {
                                      echo '<script>alert("VALIDACION DE PRODUCCION REGISTRADA CORRECTAMENTE");</script>';
                                      echo '<script type="text/javascript">
                                              window.location="descargue.php";
                                              </script>';
                                  } else {
                                      echo "Error al actualizar datos en la base de datos: " . $stmt->error;
                                  }

                                  // Cerrar la conexión a la base de datos
                                  $stmt->close();
                                  $db->close();

                                } catch (Exception $e) {
                                  echo "Error: " . $e->getMessage();
                              }
                              } 
                              
                              /*else {
                                  // Si no se ha enviado el formulario, redirigir o mostrar un mensaje de error
                                  echo "Error: El formulario no ha sido enviado correctamente.";
                              }*/
                         
                       

                         

                            
                            
/*
if ($db->query($sql) === true) {

 

  $sql2 = "SELECT * FROM eventos WHERE id = " . $_POST["cupo_nominacion"];
          $result2 = $db->query($sql2);
          
          // Verifica si se encontraron resultados
          if ($result2->num_rows > 0) {
              // Obtiene el resultado como un arreglo asociativo
              $row2 = $result2->fetch_assoc();
              $start = $row2["start"];
              $end= $row2["end"];
          }
    // Registro exitoso, muestra un mensaje de alerta
    
    //echo "entro al mailer";
                            require 'PHPMailer-master/src/Exception.php';
                            require 'PHPMailer-master/src/PHPMailer.php';
                            require 'PHPMailer-master/src/SMTP.php';

    $mail = new PHPMailer();

    // Configura el servidor SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.hostinger.com'; // Reemplaza con la configuración de tu servidor SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'directortic@augesoluciones.com'; // Reemplaza con tu dirección de correo
    $mail->Password = 'nefs1989NN**'; // Reemplaza con tu contraseña
    $mail->SMTPSecure = 'tls'; // O 'ssl' si es necesario
    $mail->Port = 587; // O el puerto SMTP correspondiente

    // Configura el remitente y el destinatario
    $mail->setFrom('directortic@augesoluciones.com', 'NEXUS SOFTWARE');
    $mail->addAddress('nforero18@gmail.com', 'Nexus C.I. Famar');

    // Asunto y contenido del correo
    $mail->isHTML(true);
    
    
    $mail->Subject = 'Nominación  '.$nombre_sn .' - ' . $tipo_producto . ' - ' . $start .'. ';
    
    // Construye el mensaje de correo en formato HTML
    $message = '<h2>NOMINACION EXITOSA</h2>';
    $message .= '<p>Los siguientes datos se han registrado exitosamente:</p>';
    
    $message .= '<table style="width: 50%; margin: 0 auto; border-collapse: collapse; text-align: left; border: 1px solid #ddd;">';

    // Agrega la fila del título de la tabla junto con los logotipos
    $message .= '<tr>';
    $message .= '<th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">';
    $message .= '<img src="https://famar.augesoluciones.com/site/images/nexus-logo.png" style="width: 50px;float: left; margin-right: 10px;">';
   
    $message .= 'Detalle de Nominacion Exitosa';
    $message .= '</th>';
    $message .= '<th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">';
    $message .= '<img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" style="width: 260px;float: right; margin-left: 10px;">';
    $message .= '</th>';
    $message .= '</tr>';

    $message .= '<tr><td><b>Socio de Negocio</b></td><td>' . $nombre_sn  . '</td></tr>';
    $message .= '<tr><td><b>Cupo de Nominacion</b></td><td> De ' . $start . ' a '.$end.'</td></tr>';
    $message .= '<tr><td><b>Placa</b></td><td>' . $placa . '</td></tr>';
    $message .= '<tr><td><b>Remolque</b></td><td>' . $remolque . '</td></tr>';
    $message .= '<tr><td><b>Nombre del Conductor</b></td><td>' . $nombre_conductor . '</td></tr>';
    $message .= '<tr><td><b>Cédula del Conductor</b></td><td>' . $cedula_conductor . '</td></tr>';
    $message .= '<tr><td><b>ARL</b></td><td>' . $arl . '</td></tr>';
    $message .= '<tr><td><b>EPS</b></td><td>' . $eps . '</td></tr>';
    $message .= '<tr><td><b>Tipo de Producto</b></td><td>' . $tipo_producto . '</td></tr>';
    $message .= '<tr><td><b>Origen</b></td><td>' . $origen . '</td></tr>';
    $message .= '<tr><td><b>Cantidad</b></td><td>' . $cantidad . '</td></tr>';
    $message .= '<tr><td><b>Acidez</b></td><td>' . $acidez . '</td></tr>';
    $message .= '<tr><td><b>Humedad</b></td><td>' . $humedad . '</td></tr>';
    $message .= '<tr><td><b>Impurezas</b></td><td>' . $impurezas . '</td></tr>';
    $message .= '<tr><td><b>Remision</b></td><td>' . $remision . '</td></tr>';
    for ($i = 1; $i <= 12; $i++) {
        $message .= '<tr><td><b>Sello de Seguridad ' . $i . '</b></td><td>' . $_POST["sello_seguridad_" . $i] . '</td></tr>';
    }
    $message .= '</table>';
    $mail->CharSet = 'UTF-8'; // Configura la codificación a UTF-8
    $mail->Body = $message;
  
    // Envía el correo

   
    if ($mail->send()) {
        echo 'Correo enviado exitosamente.';
    } else {
        echo 'Error al enviar el correo: ' . $mail->ErrorInfo;
    }


    echo '<script>alert("Notificación exitosa.");</script>';

   echo '<script type="text/javascript">
        window.location="asignaciones.php";
        </script>';

    
} else {
    // Si hay un error en la consulta SQL
    echo "Error al registrar los datos: " . $conexion->error;
}*/


                            // Cierra la conexión a la base de datos
                           // $conexion->close();
                            //$stmt->close();
                           // $db->close();
                      //  }
                        




?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
<head>
<?php
          include ("head.php");

          ?>
          </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Loading...</p>
      </div>
    </div>
    <div class="page">
        <header class="section page-header">
        <!-- RD Navbar-->
        <?php
          include ("nav.php");

          ?>
      </header>
      <!-- Swiper-->
      
      <!-- Section Box Categories-->
      <section style="min-height: 35px;" class="section section-lg section-top-1 bg-gray-4">
        <div class="container offset-negative-1" style="margin-top: 0px;">
          <div class="box-categories cta-box-wrap">
            <div class="box-categories-content">
              <div class="row justify-content-center" style="display: block;">


                <div class="col-md-4 wow fadeInDown col-9" data-wow-delay=".2s" style="max-width: 100%;">

                <?php include("../vistas_form/check/descargue_form.php"); ?>


                </div>
              </div>
            </div>
         <!-- </div><a class="link-classic wow fadeInUp" href="#">Other Tours<span></span></a>-->
          <!-- Owl Carousel-->
        </div>
      </section>

      <?php
          include ("footer.php");

          ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    
  </body>
</html>