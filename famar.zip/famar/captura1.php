<!DOCTYPE html>
<html>
  <head>
    <title>Comunicación con Puerto Serie</title>
  </head>
  <body>
    <button id="connectButton">Conectar al Puerto Serie</button>
    <button id="disconnectButton" disabled>Desconectar</button>
    <textarea id="dataDisplay" rows="10" cols="50" readonly></textarea>

    <script>
      const connectButton = document.getElementById("connectButton");
      const disconnectButton = document.getElementById("disconnectButton");
      const dataDisplay = document.getElementById("dataDisplay");
      let port;

      async function startReadingData() {
        while (port.readable) {
          const textDecoder = new TextDecoder();
          const reader = port.readable.getReader();

          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) {
                break;
              }
              const decodedData = textDecoder.decode(value);
              dataDisplay.value += decodedData;
              
              // Aquí puedes agregar tu lógica para detectar datos entrantes y actuar en consecuencia
              if (decodedData.includes("DatoImportante")) {
                alert("Se ha recibido un dato importante: " + decodedData);
              }
            }
          } finally {
            reader.releaseLock();
          }
        }
      }

      connectButton.addEventListener("click", async () => {
        try {
          port = await navigator.serial.requestPort();
          await port.open({ baudRate: 9600 });

          dataDisplay.textContent = "Conexión al puerto serie establecida";
          disconnectButton.removeAttribute("disabled");

          startReadingData();
        } catch (error) {
          console.error("Error al conectar al puerto serie:", error);
        }
      });

      disconnectButton.addEventListener("click", () => {
        if (port) {
          port.close();
          dataDisplay.textContent = "Conexión al puerto serie cerrada";
          disconnectButton.setAttribute("disabled", "disabled");
        }
      });
    </script>
  </body>
</html>
