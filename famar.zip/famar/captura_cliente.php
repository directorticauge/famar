<!DOCTYPE html>
<html>
  <head>
    <title>Comunicación con Puerto COM usando SerialPort</title>
  </head>
  <body>
    <button id="connectButton">Conectar al Puerto COM</button>
    <div id="dataDisplay"></div>

    <script>
      const connectButton = document.getElementById("connectButton");
      const dataDisplay = document.getElementById("dataDisplay");
      let comPort;

      connectButton.addEventListener("click", () => {
        if (!comPort) {
          comPort = new SerialPort("COM6", { baudRate: 9600 });

          comPort.on("open", () => {
            dataDisplay.textContent = "Conexión al puerto COM4 establecida";
          });

          comPort.on("data", (data) => {
            dataDisplay.textContent = "Datos del puerto COM: " + data.toString();
          });
        }
      });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/serialport@12.1.4/dist/index.js"></script>
  </body>
</html>
