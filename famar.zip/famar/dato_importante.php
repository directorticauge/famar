<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["importantData"])) {
        $importantData = $_POST["importantData"];
        
        // Aquí puedes hacer lo que necesites con el dato importante
        // Por ejemplo, almacenarlo en una base de datos, realizar alguna acción, etc.
        // En este ejemplo, simplemente lo mostraremos en la respuesta.

        echo "Dato importante recibido: " . $importantData;
    } else {
        echo "Error: No se recibió el dato importante.";
    }
} else {
    echo "Error: Método de solicitud no permitido.";
}
?>