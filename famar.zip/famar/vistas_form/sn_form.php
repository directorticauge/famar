

   
<link href="../css/style.css" rel="stylesheet">

<body>
<div class="container">
    <h2 style="font-size: 31px;">Formulario de Creación de Socio de Negocio</h2>
    <form action="creacion_sn.php" method="post">
        <table class="table">
            <tr>
                <td>
                    <label>Nombre:</label>
                    <input type="text" name="nombre" class="form-control" required>
                </td>
                <td>
                    <label>Apellido:</label>
                    <input type="text" name="apellido" class="form-control" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Correo Electrónico:</label>
                    <input type="email" name="email" class="form-control" required>
                </td>
                <td>
                    <label>Teléfono:</label>
                    <input type="tel" name="telefono" class="form-control">
                </td>
            </tr>
            <tr>
                <td>
                    <label>Dirección:</label>
                    <input type="address" name="direccion" class="form-control">
                </td>
                <td>
                    <label>Tipo de Socio:</label>
                    <select name="tipo" class="form-control">
                        <option value="cliente">Cliente</option>
                        <option value="proveedor">Proveedor</option>
                        <option value="maquilador">Maquilador</option>
                    </select>
                </td>
            </tr>
        </table>
        <input type="submit" value="Crear Socio de Negocio" class="btn btn-primary">
    </form>
</div>


    
</body>

