
<script>
        // Función para abrir el popup
        function openPopup_despacho_productos_granel() {
            document.getElementById("popup_despacho_productos_granel").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_despacho_productos_granel() {
            document.getElementById("popup_despacho_productos_granel").style.display = "none";
        }

        f
    </script>

<div id="popup_despacho_productos_granel" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">DESPACHO PRODUCTOS GRANEL</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_llenado_liquidos.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
                                               
                <td>     <label>CLIENTE:</label> <input class="form-control" type="text" name="cliente" id="cliente" required> </td>
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>PLACA:</label> 
                <input class="form-control"type="text" id="placa" name="placa"required> 
                </td>
                <td>   <label>CONDUCTOR:</label> <input class="form-control"type="text" id="conductor" name="conductor"required> </td>
                <td>  <label>TRANSPORTADOR:</label>
                <input class="form-control"type="text" id="transportador" name="transportador"required> 

               

                    </td>
                </tr>

                <tr>
                <td>   <label>PRODUCTO :</label> 
                    <select name="tanque" id="tanque" class="form-control" required>
                                                            <option value="OLEINA">OLEINA</option>
                                                            <option value="OLEINA CIPA">OLEINA CIPA</option>
                                                            <option value="ESTEARINA">ESTEARINA</option>
                                                            <option value="ACIDO GRASO">ACIDO GRASO</option>
                                                            <option value="PALMA BLANQUEADA">PALMA BLANQUEADA</option>
                                                            <option value="PALMISTE RBD">PALMISTE RBD</option>
                                                            <option value="SOYA RBD">SOYA RBD</option>
                                                            <option value="MEZCLA SOYA-OLEINA">MEZCLA SOYA-OLEINA</option>
                                                            <option value="100% RBD PALM OLEIN">100% RBD PALM OLEIN</option>
                                                            <option value="PALMA RBD">PALMA RBD</option>
                                                            <option value="PALMA CRUDA">PALMA CRUDA</option>
                                                            <option value="ORGANIC PALM OIL">ORGANIC PALM OIL</option>
                                                         
                                                            
                                                        </select></td>
                
                <td>   <label>KILOS DESPACHADOS:</label> <input class="form-control"type="text" id="kilos_desp" name="kilos_desp"required> </td>
               
                </tr>

                <tr>
                <td>  <label>ACIDEZ (%):</label>
                <input class="form-control"type="text" id="acidez" name="acidez"required> 

               

                    </td>
                <td>
                    <label>HUMEDAD (%)</label>
                    <input type="text" name="humedad" class="form-control" required>
                </td>
                <td>
                    <label>IMPURESAS (%</label>
                    <input type="text" name="impurezas" class="form-control" required>
                </td>
                

                
                
            </tr>
             
            <tr>
           
           <td>
               <label>VALOR PEROXIDO:</label>
               <input type="number" name="valor_peroxido" class="form-control" required>
           </td>
           
           <td>    <label>PF (ºC):</label> <input type="text" name="pf" class="form-control" required></td>
               
           
           <td>
               <label>TITER:</label>
               <input type="date" name="titer" class="form-control" required>
           </td>
           
       </tr>
            <tr>
                <td>
                    <label>COLOR AM. LOVIBOND 5 1/4</label>
                    <input type="text" name="amarillo" placeholder="AMARILLO" class="form-control" required>
                </td>
                <td>
                    <label>COLOR ROJO LOVIBOND 5 1/4</label>
                    <input type="text" name="rojo" placeholder="ROJO" class="form-control" required>
                </td>
                <td>
                    <label>COLOR AZUL LOVIBOND 5 1/4</label>
                    <input type="text" name="azul" placeholder="AZUL" class="form-control" required>
                </td>

                
                
            </tr>
           
            <tr>
           
                
                
                <td>    <label>YODO:</label> <input type="text" name="yodo" class="form-control" required></td>
                    
                <td>
                    <label>MUESTRA #:</label>
                    <input type="number" name="num_muestra" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    
                </td>
                
            </tr>
            
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                </td>
                
            </tr>
        </table>

       
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_despacho_productos_granel()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                