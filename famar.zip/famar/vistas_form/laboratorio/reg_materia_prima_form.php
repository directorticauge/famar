
<script>
        // Función para abrir el popup
        function openPopup() {
            document.getElementById("popup").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup() {
            document.getElementById("popup").style.display = "none";
        }

        f
    </script>

<div id="popup" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">RECIBO DE MATERIA PRIMA</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="laboratorio.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        <td style="width: 200px;">
                                        <label>Nominación:</label>
                                                <select name="cupo_nominacion" id="cupo_nominacion" onchange="cargarInformacion()" class="form-control" required>
    <option value="">- Selecciona  -</option>
    <?php
    // Consulta para obtener eventos que están dentro del rango de fecha del socio de negocio
    $sql = "SELECT id, start, sn_nominado, id_nominacion, fecha,ck_toma_muestras
    FROM eventos
    WHERE DATE(start) = CURDATE() AND sn_nominado <> '' and ck_toma_muestras<>'' and fecha is null;";

    $result = $db->query($sql);

    function obtenerNombreDia($fecha) {
        $diasEnIngles = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $diasEnEspanol = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];

        $nombreDiaEnIngles = date("l", strtotime($fecha));
        $nombreDia = str_replace($diasEnIngles, $diasEnEspanol, $nombreDiaEnIngles);

        return $nombreDia;
    }

    while ($row = $result->fetch_assoc()) {
        $fechaInicio = date("Y-m-d H:i:s", strtotime($row['start'])); // Formato "año-mes-día"
        $nombreDia = obtenerNombreDia($row['start']); // Nombre del día en español

        // Marcamos las opciones deshabilitadas según la condición
        $disabled = $row['fecha'] <> '' ? 'disabled' : '';

        echo '<option value="' . $row['id_nominacion'] . '" ' . $disabled . '>';
        echo $fechaInicio . " (" . $nombreDia . ")";
        if ($row['fecha'] <> '') {
            echo " RECIBO DE MATERIA PRIMA INGRESADA";
        }
        echo '</option>';
    }
    ?>
</select>

                </td>
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <select name="socio_negocio" id="socio_negocio" class="form-control" required readonly="readonly">
                                                            <!-- <option value="">- Selecciona un socio de negocio -</option>-->
                                                            <?php
                                                            // Consulta para obtener socios de negocio (ajusta los valores según tu configuración)
                                                        

                                                            $sql = "SELECT id, nombre,apellido FROM socios_de_negocio where id=".$login_sn;
                                                            $result = mysqli_query($db, $sql);

                                                            while ($row = mysqli_fetch_assoc($result)) {
                                                                echo '<option value="' . $row['id'] . '">' . strtoupper($row['nombre']) .'-'. strtoupper($row['apellido']) . '</option>';
                                                            }

                                                            // Cierra la conexión a la base de datos
                                                            //mysqli_close($db);
                                                            ?>
                                                        </select> </td>
                                               
                <td>     <label>REMISION:</label> <input class="form-control"type="text" id="remision" disabled> </td>
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>PLACA:</label> <input class="form-control"type="text" id="placa" disabled> </td>
                <td>   <label>PROVEEDOR:</label> <input class="form-control"type="text" id="sn_nombre" disabled> </td>
                <td>  <label>PRODUCTO:</label><input  class="form-control"type="text" id="tipo_producto" disabled> </td>
                </tr>
               
                <tr>
                <td>    <label>EXTRACTORA:</label> <input class="form-control"type="text" id="origen" disabled> </td>
                <td>    <label>KG(ANUNCIADO):</label> <input class="form-control"type="text" id="cantidad" disabled> </td>
                <td>     <label>KG(RECIBIDO):</label> <input class="form-control"type="text" id="cantidad_rec" disabled> </td>
              
                </tr>
               

           <!-- <script>

                        // Función para cargar información en el TextArea según la opción seleccionada
                        function cargarInformacion() {
                            var select = document.getElementById("cupo_nominacion");
                            var opcionSeleccionada = select.options[select.selectedIndex].value;

                            var textarea = document.getElementById("info");

                            // Realizar una solicitud AJAX para obtener información desde la base de datos
                            fetch('obtener_informacion.php?id=' + opcionSeleccionada)
                                .then(response => response.text())
                                .then(data => {
                                    textarea.value = data;
                                })
                                .catch(error => console.error('Error al obtener información:', error));
                        }

                        // Cargar las opciones al cargar la página
                        // cargarOpciones();
                    </script>-->

                    <script>
                                // Función para cargar información en varios campos según la opción seleccionada
                                function cargarInformacion() {
                                    var select = document.getElementById("cupo_nominacion");
                                    var opcionSeleccionada = select.options[select.selectedIndex].value;

                                    // Realizar una solicitud AJAX para obtener información desde la base de datos
                                    fetch('obtener_informacion.php?id=' + opcionSeleccionada)
                                        .then(response => response.json())  // Asumiendo que el servidor devuelve un objeto JSON
                                        .then(data => {
                                            // Asignar la información a varios campos de entrada
                                            document.getElementById("placa").value = data.placa;
                                            document.getElementById("sn_nombre").value = data.sn_nombre;
                                           
                                            document.getElementById("tipo_producto").value = data.tipo_producto;
                                            document.getElementById("origen").value = data.origen;
                                            document.getElementById("cantidad").value = data.cantidad;
                                            document.getElementById("remision").value = data.remision;
                                            document.getElementById("acidez1").value = data.acidez1;
                                            document.getElementById("humedad1").value = data.humedad1;
                                            document.getElementById("impurezas1").value = data.impurezas1;
                                           // document.getElementById("fecha_ck_toma_muestras").value = data.fecha_ck_toma_muestras;
                                            
                                            
                                        })
                                        .catch(error => console.error('Error al obtener información:', error));
                                }
                            </script>

            <tr>
                <td>
                
                <label>FECHA:</label>
                    <?php
                    $fecha_hora_bogota = date('Y-m-d H:i:s');?>
                <input type="datetime-local"  name="fecha" class="form-control" value="<?php echo $fecha_hora_bogota ?>" readonly="readonly"  required>
                </td>
                <td>
                    <label>FECHA ENTRADA:</label>
                    <input class="form-control"type="text" id="fecha_ck_toma_muestras" disabled>
                     </td>
                <td>
                    <label># CONTRAMUESTRA:</label>
                    <input type="text" name="contramuestra" class="form-control" disabled>
                </td>
               <!-- <td>
                    <label>FECHA DESCARGUE:</label>
                    <input type="date" name="fecha_descargue" oninput="convertirAMayusculas(this)" class="form-control" required>
                </td>-->
                
            </tr>
              <!--<tr>
          <td>
                    <label>TK DESTINO:</label>
                    <input type="NUMBER" name="tk_destino" oninput="convertirAMayusculas(this)" class="form-control" required>
                </td>
                
                <td>
                    <label>.</label>
                    
                </td>
                
            </tr>-->
          

            
            <!-- ... Campos anteriores ... -->
            <tr>
                <td>      <label>ANUNCIADO</label><input class="form-control"type="text" id="humedad1" disabled> </td>
                <td>     <label>.</label> <input class="form-control"type="text" id="impurezas1" disabled></td>
                <td>    <label>.</label><input class="form-control"type="text" id="acidez1" disabled> </td>
                
                        <!-- Puedes agregar más campos según sea necesario -->
            </tr>
            
            <tr>
                <td>
                    <label>RECIBIDO</label>
                    <input type="text" name="acidez" placeholder="% ACIDEZ" class="form-control" required step="0.01" max="5" oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="humedad" placeholder="% HUMEDAD" class="form-control" required step="0.01" max="0.53">
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="impurezas" placeholder="% IMPUREZAS" class="form-control" required step="0.01" max="0.1">
                </td>

                
                
            </tr>
            <tr>
                <td>
                    <label>IODO</label>
                    <input type="text" name="iodo" class="form-control" required step="0.01" max="5" ">
                </td>
                <td>
                    <label>PUNTO DE FUSION</label>
                    <input type="text" name="puntofusion" class="form-control" required step="0.01" max="0.53">
                </td>
                <td>
                    <label>ANISIDINA</label>
                    <input type="text" name="anisidina" class="form-control" required step="0.01" max="0.1">
                </td>

                
                
            </tr>
            <tr>
           
                <td>
                    <label>DOBI:</label>
                    <input type="text" name="dobi" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    
                </td>
                <td>
                    <label>.</label>
                   
                </td>
                
            </tr>
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                    <input type="hidden" name="materia_prima"  value="1" class="form-control" required>
                </td>
                
            </tr>
        </table>
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup()">Cerrar</button>
        <button type="button" onclick="openPopup1()">Consulta</button>

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                