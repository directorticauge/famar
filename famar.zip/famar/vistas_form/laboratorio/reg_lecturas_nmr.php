
<script>
        // Función para abrir el popup
        function openPopup_lecturas_nmr() {
            document.getElementById("popup_lecturas_nmr").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_lecturas_nmr() {
            document.getElementById("popup_lecturas_nmr").style.display = "none";
        }

        f
    </script>

<div id="popup_lecturas_nmr" class="popup">
                        <div class="popup-content" style="width: 800px;top: 120%;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">REGISTRO DE LECTURAS NMR CONTENIDO DE GRASA SOLIDA</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_lecturas_nmr.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
                                               
                <td>     <label>LOCALIZACIÓN:</label> <input class="form-control" type="localizacion" name="localizacion" id="hora" required> </td>
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>PRODUCTO:</label> 
              
                <select class="form-control"name="producto" required> 
                        <option value="NOMBRE">- Seleccione una opción -</option>
                        <option value="REPOSTERA 5*Kg NORMANDA">REPOSTERA 5*Kg NORMANDA</option>
                        <option value="HARD PASTRY">HARD PASTRY</option>
                        <option value="INTER 41">INTER 41</option>
                        <option value="INTER 43">INTER 43</option>
                        <option value="MESA Y COCINA BARRAS">MESA Y COCINA BARRAS</option>
                        <option value="MESA Y COCINA 450g">MESA Y COCINA 450g</option>
                        <option value="MESA Y COCINA 210g">MESA Y COCINA 210g</option>
                        <option value="GUSTAPAN 30*500g">GUSTAPAN 30*500g</option>
                        <option value="DAPAN REPOSTERA C">DAPAN REPOSTERA C</option>
                        <option value="REPOSTERIA LATIN STAR C">REPOSTERIA LATIN STAR C</option>
                        <option value="DAPAN REPOSTERA F">DAPAN REPOSTERA F</option>
                        <option value="PETUNIA REPOSTERIA F">PETUNIA REPOSTERIA F</option>
                        <option value="DAPAN SUAVE C">DAPAN SUAVE C</option>
                        <option value="DAPAN SUAVE F">DAPAN SUAVE F</option>
                        <option value="SUAVE LATIN STAR F">SUAVE LATIN STAR F</option>
                        <option value="PETUNIA SUAVE F">PETUNIA SUAVE F</option>
                        <option value="DARIPAN SUAVE C">DARIPAN SUAVE C</option>
                        <option value="BEIKER C">BEIKER C</option>
                        <option value="SURAPAN MEJORADOR C">SURAPAN MEJORADOR C</option>
                        <option value="DARIPAN SUPER C">DARIPAN SUPER C</option>
                        <option value="MAXPAN C">MAXPAN C</option>
                        <option value="BEIKER F">BEIKER F</option>
                        <option value="PETUNIA MEJORADOR F">PETUNIA MEJORADOR F</option>
                        <option value="DAPAN MULTIPROPOSITO C">DAPAN MULTIPROPOSITO C</option>
                        <option value="DARIPAN RICURA (MULTI C)">DARIPAN RICURA (MULTI C)</option>
                        <option value="DAPAN HOJALDRE ROJO 30*500">DAPAN HOJALDRE ROJO 30*500</option>
                        <option value="HOJALDRE LATIN STAR F 30*500">HOJALDRE LATIN STAR F 30*500</option>
                        <option value="HOJALDRE LATIN STAR CM 30*500">HOJALDRE LATIN STAR CM 30*500</option>
                        <option value="DARIPAN HOJALDRE  30*500g">DARIPAN HOJALDRE  30*500g</option>
                        <option value="PETUNIA HOJALDRE  30*500g">PETUNIA HOJALDRE  30*500g</option>
                        <option value="DAPAN HOJALDRE VERDE 30*500g">DAPAN HOJALDRE VERDE 30*500g</option>
                        <option value="HOJALDRE LATIN STAR 15KG">HOJALDRE LATIN STAR 15KG</option>
                        <option value="DAPAN MULTIPROPOSITO F">DAPAN MULTIPROPOSITO F</option>
                        <option value="PETUNIA MULTIPROPOSITO F">PETUNIA MULTIPROPOSITO F</option>
                        <option value="ENSAYO">ENSAYO</option>
                        <option value="INTER 47-SEBO">INTER 47-SEBO</option>
                        <option value="PALMA RBD">PALMA RBD</option>
                        <option value="LIFE BLEND ALL PURPOSE 22,7 KG (INVIERNO)">LIFE BLEND ALL PURPOSE 22,7 KG (INVIERNO)</option>
                        <option value="SHORTENING CRS 36 RELLENOS">SHORTENING CRS 36 RELLENOS</option>
                        <option value="ESTEARINA RBD">ESTEARINA RBD</option>
                        <option value="LIFE BLEND ALL PURPOSE SUPER 50 LBS">LIFE BLEND ALL PURPOSE SUPER 50 LBS</option>
                        <option value="HARD STOCK 2">HARD STOCK 2</option>
                        <option value="HARD STOCK 4">HARD STOCK 4</option>
                        <option value="MARGARINAS TIPO CM">MARGARINAS TIPO CM</option>
                        <option value="INTER 38 ANTES">INTER 38 ANTES</option>
                        <option value="INTER 38 DESPUES">INTER 38 DESPUES</option>
                        <option value="MARGARINAS CLIMA MEDIO">MARGARINAS CLIMA MEDIO</option>
                        <option value="MARGARINAS CLIMA CALIDO">MARGARINAS CLIMA CALIDO</option>
                        <option value="MARGARINAS CLIMA F">MARGARINAS CLIMA F</option>
                        <option value="BEIKER M">BEIKER M</option>
                        <option value="DAPAN MULTIPROPOSITO M">DAPAN MULTIPROPOSITO M</option>
                        <option value="DAPAN REPOSTERA M">DAPAN REPOSTERA M</option>
                        <option value="DAPAN SUAVE M">DAPAN SUAVE M</option>
                        <option value="GUSTAPAN M">GUSTAPAN M</option>
                        <option value="GUSTAPAN C">GUSTAPAN C</option>
                        <option value="GUSTAPAN F">GUSTAPAN F</option>
                        <option value="OLEOFREE 30*500">OLEOFREE 30*500</option>
                        <option value="DAPAN PREMIUM">DAPAN PREMIUM</option>
                        <option value="MEZCLA C">MEZCLA C</option>
                        <option value="GRASA MEJORADOR Y ALIÑADO">GRASA MEJORADOR Y ALIÑADO</option>
                        <option value="MESA Y COCINA NO REFRIGERADA">MESA Y COCINA NO REFRIGERADA</option>
                        <option value="PALMISTE">PALMISTE</option>
                        <option value="HARD STOCK 4">HARD STOCK 4</option>
                        <option value="MARGARINA MULTIPROPOSITO VENEZUELA">MARGARINA MULTIPROPOSITO VENEZUELA</option>
                        <option value="ALL PURPOSE VEGETAL SHORTENING">ALL PURPOSE VEGETAL SHORTENING</option>
                        <option value="SHORTENING VEGETAL LF 150">SHORTENING VEGETAL LF 150</option>
                        <option value="Manteca 10*Kg NORMANDA">Manteca 10*Kg NORMANDA</option>
                        <option value="PALMA RBD 3639">PALMA RBD 3639</option>
                    </select>

                </td>
                <td>   <label>CARGA:</label> <input class="form-control"type="text" id="carga" name="carga"required> </td>
                <td>  <label>PUNTO DE FUSION:</label>
                <input class="form-control"type="text" id="punto_fusion" name="punto_fusion"required> 

               

                    </td>
                </tr>
                <tr>
                <td>
                    <label>CONFORME <input type="checkbox" id="opcion1" name="conforme" value="conforme"> </label>
                    
    
                </td>
                <td>
                    <label>NO CONFORME <input type="checkbox" id="opcion1" name="noconforme" value="noconforme"> </label>
                   
    
                </td>
             

                
                
            </tr>
            
            <tr>
                <td>
                    <label>SFC A 10ºC</label>
                    <input type="text" name="spfa10porcentaje" placeholder="%" >
                    <input type="text" name="spfa10numero" placeholder="#">
                </td>
                <td>
                <label>SFC A 15ºC</label>
                    <input type="text" name="spfa15porcentaje" placeholder="%" >
                    <input type="text" name="spfa15numero" placeholder="#">
                </td>
                <td>
                <label>SFC A 20ºC</label>
                    <input type="text" name="spfa20porcentaje" placeholder="%" >
                    <input type="text" name="spfa20numero" placeholder="#">
                </td>

                
                
            </tr>
            <tr>
                <td>
                    <label>SFC A 25ºC</label>
                    <input type="text" name="spfa25porcentaje" placeholder="%" >
                    <input type="text" name="spfa25numero" placeholder="#">
                </td>
                <td>
                <label>SFC A 30ºC</label>
                    <input type="text" name="spfa30porcentaje" placeholder="%" >
                    <input type="text" name="spfa30numero" placeholder="#">
                </td>
                <td>
                <label>SFC A 35ºC</label>
                    <input type="text" name="spfa35porcentaje" placeholder="%" >
                    <input type="text" name="spfa35numero" placeholder="#">
                </td>

                
                
            </tr>

            <tr>
                <td>
                    <label>SFC A 40ºC</label>
                    <input type="text" name="spfa40porcentaje" placeholder="%" >
                    <input type="text" name="spfa40numero" placeholder="#">
                </td>
                <td>
                <label>ARCHIVO</label>
                    <input type="text" name="archivo">
                    
                </td>

                
                
            </tr>
            
            
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                </td>
                
            </tr>
        </table>

        <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>COMENTARIO ING.:</label>
                    <textarea name="comentario_ing" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                    
                </td>
                
            </tr>
        </table>
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_lecturas_nmr()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                