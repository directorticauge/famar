
<script>
        // Función para abrir el popup
        function openPopup_planta_fefinacion_r3() {
            document.getElementById("popup_planta_refinacion_r3").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_planta_refinacion_r3() {
            document.getElementById("popup_planta_refinacion_r3").style.display = "none";
        }

        f
    </script>

<div id="popup_planta_refinacion_r3" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">CONTROL DE PROCESOS PLANTA DE REFINACION R3</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_planta_refinacion_r3.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
            <td style="width: 200px;">
                                                <label>ID:</label>
                                <select name="ID" i class="form-control" required>
                                    <option value="">-  -</option>
                                    <?php
                                    // Consulta para obtener eventos que están dentro del rango de fecha del socio de negocio
                                    $sql1 = "SELECT id, start, sn_nominado, id_nominacion
                                        FROM eventos
                                        WHERE DATE(start) = CURDATE()  AND id_nominacion <> '' ;";

                                    $result1 = $db->query($sql1); 

                                    while ($row1 = $result1->fetch_assoc()) {

                            
                                
                                ?>
                                        <option value="<?php echo $row1['id']; ?>">ID: <?php echo $row1['id']; ?> - <?php echo $row1['start']; ?></option>
                                        <?PHP
                                    }

                                    // Cierra la conexión a la base de datos
                                   
                                    ?>
                                </select>

                </td>                          
                
              
                                                               
                
                
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <TR>
                <td>     <label>HORA:</label> <input class="form-control" type="time" name="hora" id="hora" required> </td>                
                <td>     <label>PRODUCTO:</label> <select name="producto" id="producto" class="form-control" required>
                                                            <option value="MESA Y COCINA">MESA Y COCINA</option>
                                                            <option value="PALMA">PALMA</option>
                                                            <option value="PALMA CIPA">PALMA CIPA</option>
                                                            <option value="ESTEARINA">ESTEARINA</option>
                                                            <option value="MULTIPROPOSITO CM">MULTIPROPOSITO CM</option>
                                                            <option value="BEIKER CM">BEIKER CM</option>
                                                            <option value="PALMA ORGANICA">PALMA ORGANICA</option>
                                                            <option value="PALMISTE">PALMISTE</option>
                                                            <option value="MARGARINA F">MARGARINA F</option>
                                                            <option value="HOJALDRE ROJO">HOJALDRE ROJO</option>
                                                            <option value="REPROCESO">REPROCESO</option>
                                                            <option value="HARD PASTRY">HARD PASTRY</option>
                                                            <option value="HARD STOCK">HARD STOCK</option>
                                                            <option value="ESTEARINA ORGANICA">ESTEARINA ORGANICA</option>
                                                            <option value="PALMISTE">PALMISTE</option>
                                                            
                                                            
                                                        </select></td>

                </TR>
                <tr>
                <td>   <label>ACIDEZ FFA(%):</label> 
                <input class="form-control"type="text" id="ffa" name="ffa"required> 
                </td>
                
                <td>  <label>VALOR PEROXIDO:</label>
                <input class="form-control"type="text" id="valor_peroxido" name="valor_peroxido"required> </td>
                <td>
                    <label>% DE HUMEDAD:</label>
                    <input type="number" name="humedad" class="form-control" required>
                </td>
               
                </tr>
             
            
           
            
            <tr>
                <td>
                    <label>LOVIBOND CELDA5 1/4</label>
                    <input type="text" name="amarillo" placeholder="AMARILLO" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="rojo" placeholder="ROJO" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="azul" placeholder="AZUL" class="form-control" required>
                </td>

                
                
            </tr>
            <tr>
                <td>
                    <label>.</label>
                    <input type="text" name="sabor" placeholder="SABOR" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="olor" placeholder="OLOR" class="form-control" required>
                </td>
                <td>     <label>TANQUE DESTINO:</label> <select name="tanque" id="tanque" class="form-control" required>
                                                            <option value="2D">2D</option>
                                                            <option value="3D">3D</option>
                                                            <option value="4D">4D</option>
                                                            <option value="1E">1E</option>
                                                            <option value="2E">2E</option>
                                                            <option value="3E">3E</option>
                                                            <option value="7E">7E</option>
                                                            <option value="8E">8E</option>
                                                            <option value="11E">11E</option>
                                                            <option value="12E">12E</option>
                                                            <option value="13E">13E</option>
                                                         
                                                            
                                                        </select></td>

                
                
            </tr>
            
            
            <TR>

            


            </TR>
            </table>

      <!--      <table class="table" style="MARGIN-TOP: 20PX;    BACKGROUND: antiquewhite;BORDER: 2PX SOLID BLACK;">
            <tr>
                <td>
                    <label>ANALISIS ADICIONALES</label>
                 
                </td>
               

                
                
            </tr>
            <tr>
                <td>
                    <label>PRODUCTO</label>
                 
                </td>
                <td>
                    <label>ORIGEN</label>
                  
                </td>
                <td>
                    <label>P.DE FUSION</label>
                   
                </td>
                <td>
                    <label>CONC. ACIDOS</label>
                    
                </td>
                <td>
                    <label>AN. ADIC.</label>
                   
                </td>

                
                
            </tr>
            <tr>
                <td>
                   
                    <input style="width: 150px;font-size: 10px;"type="text" name="producto_adc"  class="form-control" >
                </td>
                <td>
      
                    <input style="width: 120px;font-size: 10px;" type="text" name="origen" class="form-control" required>
                </td>
                <td>

                    <input style="width: 80px;font-size: 10px;"type="text" name="punto_fusion"  class="form-control" required>
                </td>
                <td>
                
                    <input type="text" style="width: 80px;font-size: 10px;"name="punto_fusion"  class="form-control" required>
                </td>
                <td>
                 
                    <input type="text"style="width: 80px;font-size: 10px;" name="analisis_adc"  class="form-control" required>
                </td>

                
                
            </tr>
        </table>
                                -->
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 325PX;"></textarea>
                </td>
                <td>
                    <label>COMENTARIO ING.:</label>
                    <textarea name="comentario_ing" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 325PX;"></textarea>
                    
                </td>
            </tr>
        </table>
       

       
                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_planta_refinacion_r3()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                