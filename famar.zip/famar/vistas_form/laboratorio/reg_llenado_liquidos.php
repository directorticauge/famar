
<script>
        // Función para abrir el popup
        function openPopup_llenado_liquidos() {
            document.getElementById("popup_llenado_liquidos").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_llenado_liquidos() {
            document.getElementById("popup_llenado_liquidos").style.display = "none";
        }

        f
    </script>

<div id="popup_llenado_liquidos" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">INSPECCION DE LLENADO DE LIQUIDO</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_llenado_liquidos.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA EMPAQUE:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
                                               
                <td>     <label>HORA MUESTREO:</label> <input class="form-control" type="time" name="hora" id="hora" required> </td>
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>PRODUCTO EMPACADO:</label> 
               
                <select class="form-control" id="producto_empacado" name="producto_empacado"required> 
                       <option value="">- -</option>
                       <option value="Aceite Vegetal Ricaceite CJ 48 * 250cc">Aceite Vegetal Ricaceite CJ 48 * 250cc</option>
                        <option value="Aceite Vegetal Ricaceite CJ 24 * 500cc">Aceite Vegetal Ricaceite CJ 24 * 500cc</option>
                        <option value="Aceite Vegetal Ricaceite CJ 12 * 900cc">Aceite Vegetal Ricaceite CJ 12 * 900cc</option>
                        <option value="Aceite Vegetal Ricaceite CJ 12 * 1000cc">Aceite Vegetal Ricaceite CJ 12 * 1000cc</option>
                        <option value="Aceite Vegetal Ricaceite CJ 9 * 2000cc">Aceite Vegetal Ricaceite CJ 9 * 2000cc</option>
                        <option value="Aceite Vegetal Ricaceite CJ 6 * 3000cc">Aceite Vegetal Ricaceite CJ 6 * 3000cc</option>
                        <option value="Life Blend * 250">Life Blend * 250</option>
                        <option value="Life Blend * 500">Life Blend * 500</option>
                        <option value="Life Blend * 900">Life Blend * 900</option>
                        <option value="Life Blend * 1000">Life Blend * 1000</option>
                        <option value="Life Blend * 2000">Life Blend * 2000</option>
                        <option value="Life Blend * 3000">Life Blend * 3000</option>
                        <option value="Life Blend * Bidon">Life Blend * Bidon</option>
                        <option value="Topacio 48*250 Pet Clima C">Topacio 48*250 Pet Clima C</option>
                        <option value="Topacio 48*250 Pet Clima M">Topacio 48*250 Pet Clima M</option>
                        <option value="Topacio 24*500 Pet Clima C">Topacio 24*500 Pet Clima C</option>
                        <option value="Topacio 24*500 Pet Clima M">Topacio 24*500 Pet Clima M</option>
                        <option value="Topacio 12*1000 Pet Clima C">Topacio 12*1000 Pet Clima C</option>
                        <option value="Topacio 12*1000 Pet Clima M">Topacio 12*1000 Pet Clima M</option>
                        <option value="Topacio 12* 900 CC Pet Clima M">Topacio 12* 900 CC Pet Clima M</option>
                        <option value="Topacio 12* 900 CC Pet Clima C">Topacio 12* 900 CC Pet Clima C</option>
                        <option value="Topacio 9*2000 Clima C">Topacio 9*2000 Clima C</option>
                        <option value="Topacio 9*2000 Clima M">Topacio 9*2000 Clima M</option>
                        <option value="Topacio 6*3000 Clima C">Topacio 6*3000 Clima C</option>
                        <option value="Topacio 6*3000 Clima M">Topacio 6*3000 Clima M</option>
                        <option value="Topacio Balde 7 Litros Clima C">Topacio Balde 7 Litros Clima C</option>
                        <option value="Topacio Balde 20 Lts Clima C">Topacio Balde 20 Lts Clima C</option>
                        <option value="Topacio Bidon 20 Litros Clima C">Topacio Bidon 20 Litros Clima C</option>
                        <option value="Topacio Bidon Caja 20 Litros Clima C">Topacio Bidon Caja 20 Litros Clima C</option>
                        <option value="Topacio Bidon 20 litros CLIMA M">Topacio Bidon 20 litros CLIMA M</option>
                        <option value="Topacio  Plus 48*250">Topacio  Plus 48*250</option>
                        <option value="Topacio  Plus 24*500">Topacio  Plus 24*500</option>
                        <option value="Topacio  Plus 12*900">Topacio  Plus 12*900</option>
                        <option value="Topacio  Plus 12*1000">Topacio  Plus 12*1000</option>
                        <option value="Topacio  Plus 9*2000">Topacio  Plus 9*2000</option>
                        <option value="Topacio  Plus 6*3000">Topacio  Plus 6*3000</option>
                        <option value="Topacio  Plus Bidon">Topacio  Plus Bidon</option>
                        
                        
                    </select>

                </td>
                <td>   <label>ACIDEZ:</label> <input class="form-control"type="text" id="acidez" name="acidez"required> </td>
                <td>  <label>INDICE DE PEROXIDO:</label>
                <input class="form-control"type="text" id="valor_peroxido" name="valor_peroxido"required> 

               

                    </td>
                </tr>
             
            
            <tr>
                <td>
                    <label>COLOR AM. LOVIBOND 5 1/4</label>
                    <input type="text" name="amarillo" placeholder="AMARILLO" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>COLOR ROJO LOVIBOND 5 1/4</label>
                    <input type="text" name="rojo" placeholder="ROJO" class="form-control" required>
                </td>
                <td>
                    <label>COLOR AZUL LOVIBOND 5 1/4</label>
                    <input type="text" name="azul" placeholder="AZUL" class="form-control" required>
                </td>

                
                
            </tr>
            <tr>
           
                <td>
                    <label>COLD TEST(MIN):</label>
                    <input type="number" name="cold_test" class="form-control" required>
                </td>
                <td>
                    <label>TEMP.LLENADO</label>
                    <input type="number" name="temperatura" class="form-control" required>
                </td>
                
                <td>    <label>LOTE #:</label> <input type="number" name="lote" class="form-control" required></td>
                    
                
                
                
            </tr>
            <tr>
            <td>
                    <label>FECHA VENC.</label>
                    <input type="date" name="fecha_venc"  value="<?php echo date('Y-m-d', strtotime('+12 months')); ?>" class="form-control" readonly>
                    
                </td>
           
                <td>
                    <label>MUESTRA #:</label>
                    <input type="number" name="num_muestra" class="form-control" required>
                </td>
                
                <td>    <label>TANQUE DE ALIMENT.:</label> <input type="text" name="tanque_alimt" class="form-control" required></td>
                    
              
                
            </tr>
            
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                </td>
                
            </tr>
        </table>

        <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>COMENTARIO ING.:</label>
                    <textarea name="comentario_ing" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                    
                </td>
                
            </tr>
        </table>
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_llenado_liquidos()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                