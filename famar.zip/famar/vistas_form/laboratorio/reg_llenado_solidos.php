
<script>
        // Función para abrir el popup
        function openPopup_llenado_solidos() {
            document.getElementById("popup_llenado_solidos").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_llenado_solidos() {
            document.getElementById("popup_llenado_solidos").style.display = "none";
        }

        f
    </script>

<div id="popup_llenado_solidos" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">INSPECCION DE LLENADO DE SOLIDO</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_llenado_solidos.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
                                               
                <td>     <label>HORA:</label> <input class="form-control" type="time" name="hora" id="hora" required> </td>
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>PRODUCTO EMPACADO:</label> 
                <input class="form-control"type="text" id="producto_empacado" name="producto_empacado"required> 
                </td>
                <td>   <label>ACIDEZ:</label> <input class="form-control"type="text" id="acidez" name="acidez"required> </td>
                <td>  <label>INDICE DE PEROXIDO:</label>
                <input class="form-control"type="text" id="valor_peroxido" name="valor_peroxido"required> 

               

                    </td>
                </tr>
             
            
            <tr>
                <td>
                    <label>COLOR AM. LOVIBOND 5 1/4</label>
                    <input type="text" name="amarillo" placeholder="AMARILLO" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>COLOR ROJO LOVIBOND 5 1/4</label>
                    <input type="text" name="rojo" placeholder="ROJO" class="form-control" required>
                </td>
                <td>
                    <label>COLOR AZUL LOVIBOND 5 1/4</label>
                    <input type="text" name="azul" placeholder="AZUL" class="form-control" required>
                </td>

                
                
            </tr>
            <tr>
           
                <td>
                    <label>% DE HUMEDAD:</label>
                    <input type="number" name="humedad" class="form-control" required>
                </td>
                
                <td>    <label>% DE SAL:</label> <input type="number" name="sal" class="form-control" required></td>
                    
                
                <td>
                    <label>PH T/ºC</label>
                    <input type="number" name="ph" class="form-control" required>
                </td>
                
            </tr>
            <tr>
           
                <td>
                    <label>PUNTO DE FUSION ºC:</label>
                    <input type="number" name="punto_fusion" class="form-control" required>
                </td>
                 
                <td>    <label>% NITROGENO:</label> <input type="number" name="nitrogeno" class="form-control" required></td>
                <td>    <label>YODO:</label> <input type="number" name="yodo" class="form-control" required></td>
                    
              
                
            </tr>
            <tr>
 
            <td>
                    <label>LOTE #</label>
                    <input type="number" name="lote" class="form-control" required>
                </td>
            <td>
                    <label>CARGA #</label>
                    <input type="number" name="carga" class="form-control" required>
                </td>
                <td>
                    <label>FECHA DE VENCIMIENTO:</label>
                    <input type="date" name="fecha_venc"  value="<?php echo date('Y-m-d', strtotime('+6 months')); ?>" class="form-control" readonly>
                </td>
               
                
            </tr>
            <tr>
 
            <td>    <label># DE MUESTRA:</label> <input type="number" name="n_muestra" class="form-control" required></td>
                    
    </tr>
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                </td>
                
            </tr>
        </table>

        <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>COMENTARIO ING.:</label>
                    <textarea name="comentario_ing" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                    <input type="hidden" name="control_blanqueo_r3"  value="1"placeholder="ROJO" class="form-control" required>
                </td>
                
            </tr>
        </table>
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_llenado_solidos()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                