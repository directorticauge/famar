
<script>
        // Función para abrir el popup
        function openPopup_almacenamiento_aceites() {
            document.getElementById("popup_almacenamiento_aceites").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_almacenamiento_aceites() {
            document.getElementById("popup_almacenamiento_aceites").style.display = "none";
        }

        f
    </script>

<div id="popup_almacenamiento_aceites" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">CONTROL DE ALMACENAMIENTO DE ACEITES LIQUIDOS</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_almacenamiento_aceites.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
                                               
                <td>   <label>PRODUCTO:</label> 
               <select class="form-control"  name="producto" id="producto"  required>
               <option value="">- -</option>
                        <option value="OLEINA">OLEINA</option>
                        <option value="SOYA">SOYA</option>
                        <option value="ESTEARINA">ESTEARINA</option>
                        <option value="SIERRA NEVADA VERDE">SIERRA NEVADA VERDE</option>
                        <option value="LIFE BLEND ALL PURPOSE">LIFE BLEND ALL PURPOSE</option>
                        <option value="BEIKER CM">BEIKER CM</option>
                        <option value="D-MAX GOURMET F">D-MAX GOURMET F</option>
                        <option value="PALMA RBD">PALMA RBD</option>
                        <option value="ACIDO GRASO">ACIDO GRASO</option>
                        <option value="ACEGRAN">ACEGRAN</option>
                        <option value="PALMISTE RBD">PALMISTE RBD</option>
                        <option value="MULTIPROPOSITO CM">MULTIPROPOSITO CM</option>
                        <option value="SIERRA NEVADA FRITOS">SIERRA NEVADA FRITOS</option>
                        <option value="TOPACIO PLUS">TOPACIO PLUS</option>
                        <option value="PALMA ORGANICA">PALMA ORGANICA</option>
                        <option value="CHEFF CHOISE">CHEFF CHOISE</option>
                        <option value="MESA Y COCINA BARRITAS">MESA Y COCINA BARRITAS</option>
                        <option value="HARD STOCK">HARD STOCK</option>
                        <option value="MEZCLA F">MEZCLA F</option>
                        <option value="GUSTAPAN CM">GUSTAPAN CM</option>
                        <option value="LIFE BLEND">LIFE BLEND</option>
                        <option value="OLEINA CIPA">OLEINA CIPA</option>
                    </select>
                    </td>
                </tr>
                <tr>

               <td>

               <label>TANQUE:</label> <select name="tanque" id="tanque" class="form-control" required>
                                                            <option value="2D">2D</option>
                                                            <option value="3D">3D</option>
                                                            <option value="4D">4D</option>
                                                            <option value="1E">1E</option>
                                                            <option value="2E">2E</option>
                                                            <option value="3E">3E</option>
                                                            <option value="7E">7E</option>
                                                            <option value="8E">8E</option>
                                                            <option value="11E">11E</option>
                                                            <option value="12E">12E</option>
                                                            <option value="13E">13E</option>
                                                         
                                                            
                                                        </select>
               </td> 
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>FFA(%):</label> 
                <input class="form-control"type="text" id="ffa" name="ffa"required> 
                </td>
                <td>   <label>COLD TEST (MIN):</label> <input class="form-control"type="text" id="cold_test" name="cold_test"required> </td>
                <td>  <label>VALOR PEROXIDO:</label>
                <input class="form-control"type="text" id="valor_peroxido" name="valor_peroxido"required> 

               

                    </td>
                </tr>
             
            
           
            <tr>
           
                
                <td>
                    <label>PUNTO DE FUSION ºC:</label>
                    <input type="number" name="humedad" class="form-control" required>
                </td>
                <td>
                    <label>% DE HUMEDAD:</label>
                    <input type="number" name="humedad" class="form-control" required>
                </td>
                 
                <td>    <label>YODO:</label> <input type="number" name="sal" class="form-control" required></td>
                
            </tr>
            <tr>
                <td>
                    <label>LOVIBOND CELDA5 1/4</label>
                    <input type="text" name="amarillo" placeholder="AMARILLO" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="rojo" placeholder="ROJO" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="azul" placeholder="AZUL" class="form-control" required>
                </td>

                
                
            </tr>
            
            
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 650PX;"></textarea>
                </td>
                
            </tr>
        </table>

       
                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_almacenamiento_aceites()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                