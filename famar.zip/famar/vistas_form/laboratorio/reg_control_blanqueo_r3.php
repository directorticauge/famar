
<script>
        // Función para abrir el popup
        function openPopup_control_blanqueo() {
            document.getElementById("popup_control_blanqueo").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_control_blanquedo() {
            document.getElementById("popup_control_blanqueo").style.display = "none";
        }

        f
    </script>

<div id="popup_control_blanqueo" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">CONTROL DE BLANQUEO PLANTA R3</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_control_blanqueo_r3.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                            </td>
                                                        <td>
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
            <td style="width: 200px;">
                                                <label>ID:</label>
                                <select name="ID" i class="form-control" required>
                                    <option value="">-  -</option>
                                    <?php
                                    // Consulta para obtener eventos que están dentro del rango de fecha del socio de negocio
                                    $sql1 = "SELECT id, start, sn_nominado, id_nominacion
                                        FROM eventos
                                        WHERE DATE(start) = CURDATE()  AND id_nominacion <> '' ;";

                                    $result1 = $db->query($sql1); 

                                    while ($row1 = $result1->fetch_assoc()) {

                            
                                
                                ?>
                                        <option value="<?php echo $row1['id']; ?>">ID: <?php echo $row1['id']; ?> - <?php echo $row1['start']; ?></option>
                                        <?PHP
                                    }

                                    // Cierra la conexión a la base de datos
                                   
                                    ?>
                                </select>

                </td>                          
                
                </tr>
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>PRODUCTO:</label> 
                
                                                    <select name="producto" id="producto" class="form-control" required>
                                                            <option value="PALMA">PALMA</option>
                                                            <option value="PALMA CIPA">PALMA CIPA</option>
                                                            <option value="INTER 47">INTER 47</option>
                                                            <option value="MARGARINA">MARGARINA</option>
                                                            <option value="BEAKER">BEAKER</option>
                                                            <option value="GUSTAPAM">GUSTAPAM</option>
                                                            <option value="MULTIPROPOSITO">MULTIPROPOSITO</option>
                                                            <option value="REPOSTRERIA">REPOSTRERIA</option>
                                                            <option value="MESA Y COCINA">MESA Y COCINA</option>
                                                            <option value="ESTEARINA">ESTEARINA</option>
                                                            <option value="HOLJALDRE ROJO">HOLJALDRE ROJO</option>
                                                            <option value="HOLJALDRE VERDE">HOLJALDRE VERDE</option>
                                                            <option value="TANQUE DE ALIMENTACION">TANQUE DE ALIMENTACION</option>

                                                        </select>
                </td>
                <td>     <label>HORA:</label> <input class="form-control" type="time" name="hora" id="hora" required> </td>
                <td>   <label>ACIDEZ(%FFA):</label> <input class="form-control"type="text" id="acidez" name="acidez"required> </td>
                
                </tr>
             
            
            <tr>
                <td>
                    <label>COLOR LOVIBOND 1</label>
                    <input type="text" name="amarillo" placeholder="AMARILLO" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="rojo" placeholder="ROJO" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="azul" placeholder="AZUL" class="form-control" required>
                </td>

                
                
            </tr>
            <tr>
           
                <td>
                    <label>% DE HUMEDAD:</label>
                    <input type="number" name="humedad" class="form-control" required>
                </td>
               
                <td>    <label>PRESENCIA DE TIERRA:</label> <select name="presencia_tierra" id="presencia_tierra" class="form-control" required>
                                                            <option value="-">(-)</option>
                                                            <option value="+">(+)</option>
                                                            </select></td>
                    
                
                <td>  <label>VALOR DE PEROXIDO:</label>
                <input class="form-control"type="text" id="valor_peroxido" name="valor_peroxido"required> 

               

                    </td>
                
            </tr>
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                <td>
                    <label>JABON RESIDUAL</label>
                    <input type="text" name="jabon_residual" style="width:130px;" placeholder="" class="form-control" required oninput="validatePercentage(this)">
                </td>
                <td>
                    <label>ACEITE MINERAL</label>
                    <input type="text" name="aceite_mineral" style="width:130px;" placeholder="" class="form-control" required>
                </td>
                <td>
                    <label>FOSFORO</label>
                    <input type="text" name="fosforo" style="width:130px;" placeholder="" class="form-control" required>
                </td>
                <td>
                    <label>ANICIDINA</label>
                    <input type="text" name="anicidina" style="width:130px;" placeholder="" class="form-control" required>
                </td>
                
                
            </tr>
                    
        
                
            </tr>
        </table>

            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 325PX;"></textarea>
                </td>
                <td>
                    <label>COMENTARIO ING.:</label>
                    <textarea name="comentario_ing" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 325PX;"></textarea>
                    <input type="hidden" name="control_blanqueo_r3"  value="1"placeholder="ROJO" class="form-control" required>
                </td>
                
            </tr>
        </table>

        
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_control_blanquedo()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                