
<script>
        // Función para abrir el popup
        function openPopup_control_proceso_fraccionamiento() {
            document.getElementById("popup_control_proceso_fraccionamiento").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup_control_proceso_fraccionamiento() {
            document.getElementById("popup_control_proceso_fraccionamiento").style.display = "none";
        }

        f
    </script>

<div id="popup_control_proceso_fraccionamiento" STYLE="WIDTH: 100%;"class="popup">
                        <div class="popup-content" style="width: 1280px;top: 140%;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">CONTROL DE PROCESO FRACCIONAMIENTO</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="../controller/procesar_despacho_productos_granel.php" method="post">
                                <table class="table" style="margin-bottom: -10PX;WIDTH: AUTO;">
                                        <tr>
                                        
                                        <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <input name="usuario_id" style="width: 200px;"id="usuario_id" value="<?php echo $login_session; ?>"class="form-control" required readonly="readonly">
                                                  </td>
                                                           
                                                 <td style="width: 200px;">
                
                <label>FECHA:</label>
                <input type="date" name="fecha" class="form-control" style="width: 200px;" oninput="convertirAMayusculas(this)" value="<?php echo date('Y-m-d'); ?>" readonly>

            </td>
                                               
                
                </tr>
    </TABLE>
    <div class="table-container" STYLE="text-align: center;BORDER: 1PX SOLID BLACK;">
        <h5>PALMA RBD ALIMENTACIÓN</h5>
                <table class="table" style="font-size: 10px;margin-bottom: 0PX;">
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                <td>   <label>HORA:</label><input style="width:80px;" class="form-control"type="time" id="placa" name="hora"required></td>
                <td>   <label>CRISTALIZADOR:</label> <input style="width:90px;"class="form-control"type="text" id="conductor" name="cristalizador"required> </td>
                <td>  <label>PUNTO DE FUSION(ºC):</label><input style="width:80px;"class="form-control"type="text" id="transportador" name="punto_fusion"required></td>
                <td>  <label>ACIDEZ(%PALMITICO):</label><input style="width:80px;" class="form-control"type="text" id="transportador" name="acidez"required></td>

                <td style="BACKGROUND: aliceblue;">  <label>.</label><input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="amarillo"required></td>
                <td style="BACKGROUND: aliceblue;"> <label>COLOR LOVIBOND 10mm:</label><input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="rojo"required></td>
                <td style="BACKGROUND: aliceblue;"> <label>.</label><input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="azul" required></td>

                <td>  <label>HUMEDAD:</label><input style="width:80px;" class="form-control"type="text" id="transportador" name="humedad"required></td>
                <td>  <label>YODO:</label><input style="width:80px;" class="form-control"type="text" id="transportador" name="yodo"required></td>
               
                </tr>

                
    </table>
    </DIV>
   
    <div class="table-container" STYLE="text-align: center;BORDER: 1PX SOLID BLACK;">
        <h5>OLEINA</h5>
                <table class="table" style="font-size: 10px;MARGIN-BOTTOM: 0PX;">
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                    <TD>CARGA Nº</TD>
                    <td>    <label>HORA:</label> </td>
                <td>   <label>ACIDEZ(%OLEICO):</label></td>
                <td>   <label>COLD TEST:</label> </td>
                
                <td style="BACKGROUND: aliceblue;">  <label>.</label></td>
                <td style="BACKGROUND: aliceblue;"> <label>COLOR LOVIBOND 10mm:</label></td>
                <td style="BACKGROUND: aliceblue;"> <label>.</label></td>
                
                <td>  <label>SABOR:</label></td>
                <td>  <label>OLOR:</label></td>

                <td>  <label>TANQUE DESTINO:</label></td>
               
                </tr>
                <tr>
                    <TD>1</TD>
                    <td>    <input style="width: 80px;font-size: 10px;"  class="form-control" type="time" name="hora1" id="hora" required> </td>     
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="oleina_acidez1"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="oleina_cold_test1"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="oleina_amarillo1"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="oleina_rojo1"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="oleina_azul1"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="oleina_sabor1"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_olor1"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_tanque1"required></td>
               
                </tr>
                <tr>
                <TD>2</TD>
                <td>  <input style="width: 80px;font-size: 10px;" class="form-control" type="time" name="hora2" id="hora" required> </td> 
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="oleina_acidez2"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="oleina_cold_test2"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="oleina_amarillo2"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="oleina_rojo2"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="oleina_azul2"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="oleina_sabor2"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_olor2"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_tanque2"required></td>
               
                </tr>
                <tr>
                <TD>3</TD>
                <td>   <input style="width: 80px;font-size: 10px;" class="form-control" type="time" name="hora3" id="hora" required> </td> 
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="oleina_acidez3"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="oleina_cold_test3"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="oleina_amarillo3"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="oleina_rojo3"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="oleina_azul3"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="oleina_sabor3"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_olor3"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_tanque3"required></td>
               
                </tr>
                <tr>
                <TD>4</TD>
                <td>   <input style="width: 80px;font-size: 10px;"  class="form-control" type="time" name="hora4" id="hora" required> </td> 
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="oleina_acidez4"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="oleina_cold_test4"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="oleina_amarillo4"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="oleina_rojo4"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="oleina_azul4"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="oleina_sabor4"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_olor4"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_tanque4"required></td>
               
                </tr>
                <tr>
                <TD>5</TD>
                <td>      <input style="width: 80px;font-size: 10px;" class="form-control" type="time" name="hora5" id="hora" required> </td> 
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="oleina_acidez5"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="oleina_cold_test5"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="oleina_amarillo5"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="oleina_rojo5"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="oleina_azul5"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="oleina_sabor5"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_olor5"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_tanque5"required></td>
               
                </tr>
                <tr>
                <TD>6</TD>
                <td>    <input style="width: 80px;font-size: 10px;"  class="form-control" type="time" name="hora6" id="hora" required> </td> 
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="oleina_acidez6"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="oleina_cold_test6"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="oleina_amarillo6"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="oleina_rojo6"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="oleina_azul6"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="oleina_sabor6"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_olor6"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="oleina_tanque6"required></td>
               
                </tr>
                <tr>
                <TD>ACUMULADO</TD>
                <td>    <input style="width: 80px;font-size: 10px;"  class="form-control" type="time" name="hora_a" id="hora" required> </td> 
                <td>  <input style="width:80px;" class="form-control"type="text" id="placa" name="acumulado_oleina_acidez6"required></td>
                <td>  <input style="width:110px;"class="form-control"type="text" id="conductor" name="acumulado_oleina_cold_test6"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="acumulado_oleina_amarillo6"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="acumulado_oleina_rojo6"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="acumulado_oleina_azul6"required></td>
                
                <td> <input style="width:80px;"class="form-control"type="text" id="transportador" name="acumulado_oleina_sabor6"required></td>
                <td>  <input style="width:80px;" class="form-control"type="text" id="transportador" name="acumulado_oleina_olor6"required></td>

                <td> <input style="width:80px;" class="form-control"type="text" id="transportador" name="acumulado_oleina_tanque6"required></td>
               
                </tr>

                
    </table>
    </DIV>
        <BR>

    

            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones_oleina" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 350PX;"></textarea>
                </td>
                <td>
                    <label>COMENTARIO ING:</label>
                    <textarea name="comentario_ing_oleina" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 350PX;"></textarea>
                </td>

                 <tr>
            
                    
                
                
            </tr>
                
            </tr>
        </table>
        <div class="table-container" STYLE="text-align: center;BORDER: 1PX SOLID BLACK;">
        <h5>ESTEARINA</h5>
                <table class="table" style="font-size: 10px;MARGIN-BOTTOM: 0PX;">
               <!-- <td>
                <label>Datos de la nominación</label>
                <textarea id="info" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 290PX;height: 105px;"readonly></textarea>
                </td>-->
               
                <!-- Campos de entrada donde se mostrará la información -->
                <tr>
                    <TD>CARGA Nº</TD>
                <td>   <label>ACIDEZ (%PALMITICO):</label></td>
                <td>   <label>PUNTO DE FUSION(ºC):</label> </td>
                
                <td style="BACKGROUND: aliceblue;">  <label>.</label></td>
                <td style="BACKGROUND: aliceblue;"> <label>COLOR LOVIBOND 5 1/4":</label></td>
                <td style="BACKGROUND: aliceblue;"> <label>.</label></td>
                
                <td>  <label>V.PEROXIDO:</label></td>
                <td>  <label>SABOR:</label></td>

                <td>  <label>OLOR:</label></td>
                <td>  <label>TK:</label></td>
                <td>  <label>VALOR DE YODO:</label></td>
                <td>  <label>HUMEDAD:</label></td>
               
                </tr>
                <tr>
                    <TD>1</TD>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="placa" name="estearina_acidez1"required></td>
                <td>  <input style="width:70PX;"class="form-control"type="text" id="conductor" name="estearina_punto_fusion1"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:70PX;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="estearina_amrillo1"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="estearina_rojo1"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="estearina_azul1"required></td>
                
                <td> <input style="width:70PX;"class="form-control"type="text" id="transportador" name="estearina_peroxido1"required></td>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_sabor1"required></td>

                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_olor1"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_tanque_dtn1"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_yodo1"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_humedad1"required></td>
               
                </tr>
                <tr>
                <TD>2</TD>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="placa" name="estearina_acidez2"required></td>
                <td>  <input style="width:70PX;"class="form-control"type="text" id="conductor" name="estearina_punto_fusion2"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:70PX;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="estearina_amrillo2"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="estearina_rojo2"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="estearina_azul2"required></td>
                
                <td> <input style="width:70PX;"class="form-control"type="text" id="transportador" name="estearina_peroxido2"required></td>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_sabor2"required></td>

                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_olor2"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_tanque_dtn2"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_yodo2"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_humedad2"required></td>
               
                </tr>
                <tr>
                <TD>3</TD>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="placa" name="estearina_acidez3"required></td>
                <td>  <input style="width:70PX;"class="form-control"type="text" id="conductor" name="estearina_punto_fusion3"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:70PX;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="estearina_amrillo3"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="estearina_rojo3"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="estearina_azul3"required></td>
                
                <td> <input style="width:70PX;"class="form-control"type="text" id="transportador" name="estearina_peroxido3"required></td>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_sabor3"required></td>

                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_olor3"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_tanque_dtn3"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_yodo3"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_humedad3"required></td>
               
                </tr>
                <tr>
                <TD>4</TD>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="placa" name="estearina_acidez4"required></td>
                <td>  <input style="width:70PX;"class="form-control"type="text" id="conductor" name="estearina_punto_fusion4"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:70PX;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="estearina_amrillo4"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="estearina_rojo4"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="estearina_azul4"required></td>
                
                <td> <input style="width:70PX;"class="form-control"type="text" id="transportador" name="estearina_peroxido4"required></td>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_sabor4"required></td>

                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_olor4"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_tanque_dtn4"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_yodo4"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_humedad4"required></td>
               
                </tr>
                <tr>
                <TD>5</TD>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="placa" name="estearina_acidez5"required></td>
                <td>  <input style="width:70PX;"class="form-control"type="text" id="conductor" name="estearina_punto_fusion5"required> </td>
                
                <td style="BACKGROUND: aliceblue;">  <input style="width:70PX;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="estearina_amrillo5"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="estearina_rojo5"required></td>
                <td style="BACKGROUND: aliceblue;"> <input style="width:70PX;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="estearina_azul5"required></td>
                
                <td> <input style="width:70PX;"class="form-control"type="text" id="transportador" name="estearina_peroxido5"required></td>
                <td>  <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_sabor5"required></td>

                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_olor5"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_tanque_dtn5"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_yodo5"required></td>
                <td> <input style="width:70PX;" class="form-control"type="text" id="transportador" name="estearina_humedad5"required></td>
               
                </tr>

                
    </table>
    </DIV>
    <table class="table" style="margin-bottom: -10PX;WIDTH: AUTO;margin-left: auto;
            margin-right: auto;">
           
           <tr>
          
               
               
           <td>  <label>.</label><input style="width:80px;" placeholder="AMARILLO" class="form-control"type="text" id="transportador" name="saponificacion_amarillo"required></td>
               <td> <label>COLOR DE SAPONIFICACIÓN:</label><input style="width:80px;    MARGIN-LEFT: 25%;" placeholder="ROJO" class="form-control"type="text" id="transportador" name="saponificacion_rojo"required></td>
               <td> <label>.</label><input style="width:80px;" class="form-control"type="text" placeholder="AZUL"  id="transportador" name="saponificacion_azul" required></td>

           </tr>
           
           </table>
    
    <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                <td>
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones_estearina" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 350PX;"></textarea>
                </td>
                     
                <td>
                    <label>COMENTARIO ING:</label>
                    <textarea name="comentario_ing_estearina" rows="4" cols="50" style="FONT-SIZE: 11PX;WIDTH: 350PX;"></textarea>
                </td>
                
            </tr>
        </table>
       
       
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup_control_proceso_fraccionamiento()">Cerrar</button>
        <!--<button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                