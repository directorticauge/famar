
<script>
        // Función para abrir el popup

        function openPopup1() {
            document.getElementById("popup1").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup1() {
            document.getElementById("popup1").style.display = "none";
        }
    </script>


<?php
/*consulta de datatables*/
$sql = "SELECT * FROM eventos where id_nominacion<>''";
               
                $result = $db->query($sql);
                $arr_lideres = [];
                if ($result->num_rows > 0) {
                    $arr_lideres = $result->fetch_all(MYSQLI_ASSOC);
                }


                ?>
<div id="popup1" class="popup">
                        <div class="popup-content" style="width: 1380px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">CONSULTA INGRESO DE MATERIA PRIMA</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                           
                                
                                                
                                        <?php include("../controller/reg_materia_prima_datatable.php"); ?>
               
                                   
          

            
      
       

                    </div>
        <!--<input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="button" onclick="closePopup1()">Cerrar</button>
        
    
                        </div>
    </div>
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
    
                <script type="text/javascript" src="datatables/datatables.min.js"></script>
                <script>
                    $(document).ready(function() {
                        console.log("jQuery version:", $.fn.jquery);
                        $('#theTable1').DataTable({
                            "language": {
                                "lengthMenu": "Mostrando _MENU_ registros por página",
                                "zeroRecords": "Nothing found - sorry",
                                "info": "Mostrando página _PAGE_ of _PAGES_",
                                "infoEmpty": "No records available",
                                "infoFiltered": "(filtered from _MAX_ total records)",
                                "search": "Buscar"
                            }
                        });
                    });
                </script>



    

              
