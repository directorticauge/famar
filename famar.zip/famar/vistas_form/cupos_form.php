

   
<link href="../css/style.css" rel="stylesheet">

<body>
<div class="container">
        <h2 style="font-size: 31px;">NOMINACIÓN POR PROVEEDOR/CLIENTE</h2>
        <form action="cupos_nominacion.php" method="post">
            <table class="table">
                <tr>
                    <td style="
    width: 345px;
">
                        <label for="socio_negocio">Selecciona un socio de negocio:</label>
                        <select name="socio_negocio" id="socio_negocio" class="form-control" required>
                            <option value="">- Selecciona un socio de negocio -</option>
                            <?php
                            // Consulta para obtener socios de negocio (ajusta los valores según tu configuración)
                          

                            $sql = "SELECT id, nombre FROM socios_de_negocio";
                            $result = mysqli_query($db, $sql);

                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="' . $row['id'] . '">' . $row['nombre'] . '</option>';
                            }

                            // Cierra la conexión a la base de datos
                            //mysqli_close($db);
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                <td>
                    <label>Nº VEHICULOS:</label>
                    <input type="number" name="cupos" class="form-control" oninput="convertirAMayusculas(this)" required>
                </td>
                <td>
                    <label>CANTIDAD(KG):</label>
                    <input type="NUMBER" name="cantidad" oninput="convertirAMayusculas(this)" class="form-control" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label>FECHA INICIAL CUPO</label>
                    <input type="DATE" oninput="convertirAMayusculas(this)" name="fecha_ini_cupo" class="form-control" required>
                </td>
                <td>
                    <label>FECHA FINAL CUPO</label>
                    <input type="DATE" oninput="convertirAMayusculas(this)" name="fecha_fin_cupo" class="form-control" required>
                </td>
            </tr>
              <!--  <tr>
                    <td>
                        <label for="cupo_nominacion">Selecciona un evento de cupo de nominación:</label>
                        <select name="cupo_nominacion" id="cupo_nominacion" class="form-control" required>
                            <option value="">- Selecciona un evento de cupo de nominación -</option>
                            <?php
                            // Consulta para obtener eventos cuyo campo sn_nominado sea igual a vacío (ajusta los valores según tu configuración)
                           
                            /*
                            $sql = "SELECT id, start FROM eventos where sn_nominado is NULL";
                            $result = mysqli_query($db, $sql);

                            function obtenerNombreDia($fecha) {
                                $diasEnIngles = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
                                $diasEnEspanol = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];
                            
                                $nombreDiaEnIngles = date("l", strtotime($fecha));
                                $nombreDia = str_replace($diasEnIngles, $diasEnEspanol, $nombreDiaEnIngles);
                            
                                return $nombreDia;
                            }
                            
                            while ($row = mysqli_fetch_assoc($result)) {
                                $fechaInicio = date("Y-m-d H:i:s", strtotime($row['start'])); // Formato "año-mes-día"
                                $nombreDia = obtenerNombreDia($row['start']); // Nombre del día en español
                            
                                echo '<option value="' . $row['id'] . '">' . $fechaInicio . " (" . $nombreDia . ")" . '</option>';
                            }
                            

                            // Cierra la conexión a la base de datos
                            //mysqli_close($db);*/
                            ?>
                        </select>
                    </td>
                </tr>-->
            </table>

            <input type="submit" value="Guardar Cupo" class="btn btn-primary">
        </form>
    </div>
    
</body>

