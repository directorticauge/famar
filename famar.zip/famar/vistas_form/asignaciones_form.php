

   
<link href="../css/style.css" rel="stylesheet">

<body>
<div class="container">
    <h2 style="font-size: 31px;">Formulario de Nominaciones</h2>
    <form action="asignaciones.php" method="post">
        <table class="table">
        <tr>
                <td>
                    <label>Socio de negocio:</label>
                    <select name="socio_negocio" id="socio_negocio" class="form-control" required readonly="readonly">
                            <!-- <option value="">- Selecciona un socio de negocio -</option>-->
                            <?php
                            // Consulta para obtener socios de negocio (ajusta los valores según tu configuración)
                          

                            $sql = "SELECT id, nombre,apellido FROM socios_de_negocio where id=".$login_sn;
                            $result = mysqli_query($db, $sql);

                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="' . $row['id'] . '">' . strtoupper($row['nombre']) .'-'. strtoupper($row['apellido']) . '</option>';
                            }

                            // Cierra la conexión a la base de datos
                            //mysqli_close($db);
                            ?>
                        </select> </td>
                <td>
                <label>Cupos de Nominacion:</label>
<select name="cupo_nominacion" id="cupo_nominacion" class="form-control" required>
    <option value="">- Selecciona un evento de cupo de nominación -</option>
    <?php
    // Consulta para obtener eventos que están dentro del rango de fecha del socio de negocio
    $sql = "SELECT id, start ,sn_nominado
    FROM eventos
    WHERE (DATE(start) >= (SELECT DATE(FechaInicio) FROM cupos WHERE CodigoSocioNegocio = ?) 
    AND DATE(start) <= (SELECT DATE(FechaFin)+1 FROM cupos WHERE CodigoSocioNegocio = ?));";

    $stmt = $db->prepare($sql);

    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $db->error);
    }

    // Asociar los parámetros
    $stmt->bind_param("ii", $login_sn, $login_sn);

    // Ejecutar la consulta
    $stmt->execute();

    $result = $stmt->get_result();

    function obtenerNombreDia($fecha) {
        $diasEnIngles = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $diasEnEspanol = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];
    
        $nombreDiaEnIngles = date("l", strtotime($fecha));
        $nombreDia = str_replace($diasEnIngles, $diasEnEspanol, $nombreDiaEnIngles);
    
        return $nombreDia;
    }

    while ($row = $result->fetch_assoc()) {

        $fechaInicio = date("Y-m-d H:i:s", strtotime($row['start'])); // Formato "año-mes-día"
        $nombreDia = obtenerNombreDia($row['start']); // Nombre del día en español

        //echo '<option value="' . $row['id'] . '">' . $fechaInicio . " (" . $nombreDia . ")" . '</option>';
   
?>
        <option value="<?php echo $row['id']; ?>" <?php if($row['sn_nominado']<>NULL){?>disabled<?PHP }?>><?php echo $fechaInicio; ?> <?php echo " (".$nombreDia.")"; if($row['sn_nominado']<>NULL){ echo " -> CUPO NO DISPONIBLE";} ?></option>
        <?PHP
    }

    // Cierra la conexión a la base de datos
    $stmt->close();
    ?>
</select>

                </td>
            </tr>
            <tr>
                <td>
                    <label>Placa:</label>
                    <input type="text" name="placa" class="form-control" oninput="convertirAMayusculas(this)" required>
                </td>
                <td>
                    <label>Remolque:</label>
                    <input type="text" name="remolque" oninput="convertirAMayusculas(this)" class="form-control" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Nombre del Conductor:</label>
                    <input type="text" oninput="convertirAMayusculas(this)" name="nombre_conductor" class="form-control" required>
                </td>
                <td>
                    <label>Cédula del Conductor:</label>
                    <input type="text" name="cedula_conductor" class="form-control" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label>ARL:</label>
                    <select name="arl" id="arl"  class="form-control" required>
                    <option value="">- Seleccione la ARL-</option>
                    <option value="SEGUROS DE VIDA ALFA SA">SEGUROS DE VIDA ALFA SA</option>
                            <option value="LIBERTY SEGUROS DE VIDA">LIBERTY SEGUROS DE VIDA</option>
                            <option value="POSITIVA COMPAÑIA DE SEGUROS">POSITIVA COMPAÑIA DE SEGUROS</option>
                            <option value="RIESGOS PROFESIONALES COLMENA SA COMPAÑIA DE SEGUROS DE VIDA">RIESGOS PROFESIONALES COLMENA SA COMPAÑIA DE SEGUROS DE VIDA</option>
                            <option value="ARP SURA">ARP SURA</option>
                            <option value="LA EQUIDAD SEGUROS DE VIDA ORGANISMO COOPERATIVO LA EQUIDAD VIDA">LA EQUIDAD SEGUROS DE VIDA ORGANISMO COOPERATIVO LA EQUIDAD VIDA</option>
                            <option value="MAPFRE COLOMBIA VIDA SEGUROS SA">MAPFRE COLOMBIA VIDA SEGUROS SA</option>
                            <option value="SEGUROS DE VIDA COLPATRIA SA">SEGUROS DE VIDA COLPATRIA SA</option>
                            <option value="CIA DE SEGUROS BOLIVAR SA">CIA DE SEGUROS BOLIVAR SA</option>
                            <option value="COMPAÑIA DE SEGUROS DE VIDA AURORA">COMPAÑIA DE SEGUROS DE VIDA AURORA</option>

                    </select>
                    
                </td>
                <td>
                    <label>EPS:</label>
                    <select name="eps" id="eps"  class="form-control" required>
                    <option value="">- Seleccione la EPS-</option>
                    <option value="COOSALUD EPS-S">COOSALUD EPS-S</option>
                        <option value="NUEVA EPS">NUEVA EPS</option>
                        <option value="MUTUAL SER">MUTUAL SER</option>
                        <option value="ALIANSALUD EPS">ALIANSALUD EPS</option>
                        <option value="SALUD TOTAL EPS S.A.">SALUD TOTAL EPS S.A.</option>
                        <option value="EPS SANITAS">EPS SANITAS</option>
                        <option value="EPS SURA">EPS SURA</option>
                        <option value="FAMISANAR">FAMISANAR</option>
                        <option value="SERVICIO OCCIDENTAL DE SALUD EPS SOS">SERVICIO OCCIDENTAL DE SALUD EPS SOS</option>
                        <option value="SALUD MIA">SALUD MIA</option>
                        <option value="COMFENALCO VALLE">COMFENALCO VALLE</option>
                        <option value="COMPENSAR EPS">COMPENSAR EPS</option>
                        <option value="EPM - EMPRESAS PUBLICAS DE MEDELLIN">EPM - EMPRESAS PUBLICAS DE MEDELLIN</option>
                        <option value="FONDO DE PASIVO SOCIAL DE FERROCARRILES NACIONALES DE COLOMBIA">FONDO DE PASIVO SOCIAL DE FERROCARRILES NACIONALES DE COLOMBIA</option>
                        <option value="CAJACOPI ATLANTICO">CAJACOPI ATLANTICO</option>
                        <option value="CAPRESOCA">CAPRESOCA</option>
                        <option value="COMFACHOCO">COMFACHOCO</option>
                        <option value="COMFAORIENTE">COMFAORIENTE</option>
                        <option value="EPS FAMILIAR DE COLOMBIA">EPS FAMILIAR DE COLOMBIA</option>
                        <option value="ASMET SALUD">ASMET SALUD</option>
                        <option value="EMSSANAR E.S.S.">EMSSANAR E.S.S.</option>
                        <option value="CAPITAL SALUD EPS-S">CAPITAL SALUD EPS-S</option>
                        <option value="SAVIA SALUD EPS">SAVIA SALUD EPS</option>
                        <option value="DUSAKAWI EPSI">DUSAKAWI EPSI</option>
                        <option value="ASOCIACION INDIGENA DEL CAUCA EPSI">ASOCIACION INDIGENA DEL CAUCA EPSI</option>
                        <option value="ANAS WAYUU EPSI">ANAS WAYUU EPSI</option>
                        <option value="MALLAMAS EPSI">MALLAMAS EPSI</option>
                        <option value="PIJAOS SALUD EPSI">PIJAOS SALUD EPSI</option>
                        <option value="SALUD BÓLIVAR EPS SAS">SALUD BÓLIVAR EPS SAS</option>

                    </select>
                    
                </td>
            </tr>
            <tr>
                <td>
                    <label>Tipo de Producto:</label>
                    <select placeholder="Seleccione producto" name="tipo_producto" class="form-control" required>
                    <option value="">- Seleccione producto -</option>
                            <option value="ACEITE DE PALMA CRUDA">ACEITE DE PALMA CRUDA</option>
                            <option value="ACEITE DE PALMA RBD">ACEITE DE PALMA RBD</option>
                            <option value="ACEITE DE PALMISTE CRUDO">ACEITE DE PALMISTE CRUDO</option>
                            <option value="ACEITE DE PALMISTE RBD">ACEITE DE PALMISTE RBD</option>
                            <option value="OLEINA DE PALMA"> OLEINA DE PALMA</option>
                            <option value="ESTEARINA DE PALMA"> ESTEARINA DE PALMA</option>
                            <option value="SOYA RBD"> SOYA RBD</option>
                        
                    </select>
                </td>
                <td>
                    <label>Origen / Extractora:</label>
                  
                   <!-- <select name="origen" class="form-control select2 select2-hidden-accessible" style="width: 100%;" tabindex="-1" aria-hidden="true">-->
				
                    <select name="origen" class="form-control" required>
                    <option value="">- Seleccione origen -</option>
                    <option value="EXTRACTORA PADELMA">EXTRACTORA PADELMA</option>
                        <option value="EXTRACTORA PALMACEITES">EXTRACTORA PALMACEITES</option>
                        <option value="EXTRACTORA PALMERAS DE LA COSTA">EXTRACTORA PALMERAS DE LA COSTA</option>
                        <option value="EXTRACTORA EL ROBLE">EXTRACTORA EL ROBLE</option>
                        <option value="EXTRACTORA LA GLORIA">EXTRACTORA LA GLORIA</option>
                        <option value="EXTRACTORA PALMERAS DE PUERTO WILCHES">EXTRACTORA PALMERAS DE PUERTO WILCHES</option>
                        <option value="EXTRACTORA OLEOINVERSIONES">EXTRACTORA OLEOINVERSIONES</option>
                        <option value="EXTRACTORA NEGOCIOS DEL LLANO">EXTRACTORA NEGOCIOS DEL LLANO</option>
                        <option value="EXTRACTORA EL ESTERO">EXTRACTORA EL ESTERO</option>
                        <option value="EXTRACTORA SAN FERNANDO">EXTRACTORA SAN FERNANDO</option>
                        <option value="EXTRACTORA ACEITES DEL MAGDALENA MEDIO">EXTRACTORA ACEITES DEL MAGDALENA MEDIO</option>

         
                    </select>
                </td>
            </tr>
            <tr>
                    <td>
                    <label># Remision:</label>
                    <input type="text" oninput="convertirAMayusculas(this)" name="remision" class="form-control" required>
                </td>
                <td>
                    <label>Cantidad (Kg):</label>
                    <input type="number" name="cantidad" class="form-control" required>
                </td>
               
            </tr>

            </table>
            
        <table class="table">
            <!-- ... Campos anteriores ... -->
            
            <tr>
                <td>
                    <label>Calidad</label>
                    <input type="text" name="acidez" placeholder="% ACIDEZ" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="humedad" placeholder="% HUMEDAD" class="form-control" required>
                </td>
                <td>
                    <label>.</label>
                    <input type="text" name="impurezas" placeholder="% IMPUREZAS" class="form-control" required>
                </td>
                
            </tr>
        </table>
        <div class="table-responsive">
        <table class="table">
            <!-- ... Campos anteriores ... -->
            <tr>
                
                <td>
                    <label>Sello de Seguridad 1:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_1" class="form-control" required>
                </td>
                <td>
                    <label>Sello de Seguridad 2:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_2" class="form-control" required>
                </td>
                <td>
                    <label>Sello de Seguridad 3:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_3" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 4:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_4" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 5:</label>
                    <input type="text"oninput="convertirAMayusculas(this)" name="sello_seguridad_5" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 6:</label>
                    <input type="text"oninput="convertirAMayusculas(this)"name="sello_seguridad_6" class="form-control">
                </td>
            </tr>
            <tr>
                
                <td>
                    <label>Sello de Seguridad 7:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_7" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 8:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_8" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 9:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_9" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 10:</label>
                    <input type="text" oninput="convertirAMayusculas(this)"name="sello_seguridad_10" class="form-control">
                </td>
                <td>
                    <label>Sello de Seguridad 11:</label>
                    <input type="text"oninput="convertirAMayusculas(this)" name="sello_seguridad_11" class="form-control">
                    <td>
                    <label>Sello de Seguridad 12:</label>
                    <input type="text"oninput="convertirAMayusculas(this)" name="sello_seguridad_12" class="form-control">
                </td>
                </td>
            </tr>
        </table>
</div>
        <input type="submit" value="Guardar Nominación" class="btn btn-primary">
    </form>
</div>

    
</body>

