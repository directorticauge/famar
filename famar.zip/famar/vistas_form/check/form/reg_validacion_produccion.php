
<script>
        // Función para abrir el popup
        function openPopup() {
            document.getElementById("popup").style.display = "block";
        }

        // Función para cerrar el popup
        function closePopup() {
            document.getElementById("popup").style.display = "none";
        }
        document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closePopup();
        }
    });
    </script>

<div id="popup" class="popup">
                        <div class="popup-content" style="width: 800px;">
                        <div class="table-responsive">  
                        <table class="table">
                                        <tr>
                                                <td style="width: 500px;">
                                                     <h3 style="font-size: 30px;">VALIDACION PRODUCCION</h3>
                                                </td>
                                                <td style="width: 300px;">
                                                <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="200px" alt="">
                                                </td>
    </tr>
    </table>
                              <!--  <img src="https://www.cifamar.com/wp-content/uploads/2023/07/logo-Famar-completo.png" width="300px" alt="">
                             Formulario de inicio de sesión -->
                            <form action="tanque.php" method="post">
                                <table class="table" STYLE="    margin-bottom: -17PX;">
                                        <tr>
                                        <td style="width: 200px;">
                                                <label>Nominación:</label>
                                                <select name="cupo_nominacion" id="cupo_nominacion" onchange="cargarInformacion()" class="form-control" required>
    <option value="">- Selecciona El ingreso Del Vehiculo -</option>
    <?php
    // Consulta para obtener eventos que están dentro del rango de fecha del socio de negocio
    $sql = "SELECT id, start, sn_nominado, id_nominacion, fecha,ck_produccion
            FROM eventos
            WHERE DATE(start) = CURDATE() AND sn_nominado <> '' and fecha <>'' and ck_produccion='';";

    $result = $db->query($sql);

    function obtenerNombreDia($fecha) {
        $diasEnIngles = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $diasEnEspanol = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];

        $nombreDiaEnIngles = date("l", strtotime($fecha));
        $nombreDia = str_replace($diasEnIngles, $diasEnEspanol, $nombreDiaEnIngles);

        return $nombreDia;
    }

    while ($row = $result->fetch_assoc()) {
        $fechaInicio = date("Y-m-d H:i:s", strtotime($row['start'])); // Formato "año-mes-día"
        $nombreDia = obtenerNombreDia($row['start']); // Nombre del día en español

        // Marcamos las opciones deshabilitadas según la condición
        //$disabled = $row['fecha'] <> '' ? 'disabled' : '';

        echo '<option value="' . $row['id_nominacion'] . '" ' . $disabled . '>';
        echo $fechaInicio . " (" . $nombreDia . ")";
        if ($row['fecha'] <> '') {
          //  echo " RECIBO DE MATERIA PRIMA INGRESADA";
        }
        echo '</option>';
    }
    ?>
</select>


                </td>
                                                <td style="width: 200px;">
                                                    <label>Usuario:</label>
                                                    <select name="usuario" id="socio_negocio" class="form-control" required readonly="readonly">
                                                            <!-- <option value="">- Selecciona un socio de negocio -</option>-->
                                                            <?php
                                                            // Consulta para obtener socios de negocio (ajusta los valores según tu configuración)
                                                        

                                                            $sql= "SELECT id, nombre,apellido FROM usuarios where id=".$login_id;
                                                            $result = mysqli_query($db, $sql);

                                                            while ($row = mysqli_fetch_assoc($result)) {
                                                                echo '<option value="' . $row['id'] . '">' . strtoupper($row['nombre']) .'-'. strtoupper($row['apellido']) . '</option>';
                                                            }

                                                            // Cierra la conexión a la base de datos
                                                            //mysqli_close($db);
                                                            ?>
                                                        </select> </td>
                                               
                                                        <td style="width: 200px;">
                
                <label>FECHA CHEQUEO:</label>
                <?php date_default_timezone_set('America/Bogota');
                    $fecha_hora_bogota = date('Y-m-d H:i:s');?>
                <input type="datetime-local" name="fecha" class="form-control" value="<?php echo $fecha_hora_bogota ?>" readonly="readonly" required>


            </td>
                </tr>


                </table>


                <table class="table" style="MARGIN-TOP: 20PX;">
               


               <td>
                <label>Datos de la nominación</label>
                <div id="tablaInfo"></div>
                <!--<textarea id="info" rows="4" cols="50" style="FONT-SIZE: 18PX;WIDTH: 100%;height: 240px;"readonly></textarea>-->
                </td>
               
                <!-- Campos de entrada donde se mostrará la información -->
               
               
                



<script>
    // Función para cargar información en el div de la tabla según la opción seleccionada
    function cargarInformacion() {
        var select = document.getElementById("cupo_nominacion");
        var opcionSeleccionada = select.options[select.selectedIndex].value;

        var tablaDiv = document.getElementById("tablaInfo");

        // Realizar una solicitud AJAX para obtener información desde la base de datos
        fetch('obtener_informacion_produccion.php?id=' + opcionSeleccionada)
            .then(response => response.text())
            .then(data => {
                // Cambiar el contenido del div por la tabla generada
                tablaDiv.innerHTML = data;
            })
            .catch(error => console.error('Error al obtener información:', error));
    }

    // Cargar las opciones al cargar la página
    // cargarOpciones();
</script>

                </table>

            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
            <td>
            <label for="miCheckbox">USTED VALIDA EL TANQUE DE DESTINO?</label>
             <input type="checkbox" id="miCheckbox" name="validacion" value="VALIDADO">
            </td>
            <td>
                    <label>TANQUE 1:</label>
                    <select placeholder="Seleccione producto" name="tanque1" class="form-control" required>
                    <option value="">- Seleccione producto -</option>
                               <!-- Opciones c1 hasta c6 -->
                              
                                    <!-- Opciones c1 hasta c6 -->
                                    <optgroup label="CRUDO">
                                    <option value="C1">C1</option>
        <option value="C2">C2</option>
        <option value="C3">C3</option>
        <option value="C4">C4</option>
        <option value="C5">C5</option>
        <option value="C6">C6</option>
                                    </optgroup>

                                    <!-- Opciones d1 hasta d4 -->
                                    <optgroup label="DESPACHO OLEINA">
                                    <option value="D1">D1</option>
        <option value="D2">D2</option>
        <option value="D3">D3</option>
        <option value="D4">D4</option>
                                    </optgroup>

                                    <!-- Opciones e1 hasta e13 -->
                                    <optgroup label="OLEINA">
                                    <option value="E1">E1</option>
        <option value="E2">E2</option>
        <option value="E3">E3</option>
        <option value="E7">E7</option>
        <option value="E8">E8</option>
        <option value="E13">E13</option>
                                    </optgroup>
                                    <optgroup label="ESTEARINA">
                                        <option value="8D">8D</option>
                                        <option value="9D">9D</option>
                                       
                                    </optgroup>
                                    <optgroup label="PALMA RBD">
                                        <option value="5D">5D</option>
                                        <option value="6D">6D</option>
                                        <option value="7D">7D</option>
                                       
                                    </optgroup>
                                    <optgroup label="ACIDO GRASO">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                       
                                    </optgroup>
                                    <optgroup label="DESOFORIZADOS IMPORTANTES">
                                    <option value="D1 DES. IMP">D1 DES. IMP</option>
                                    <option value="D2 DES. IMP">D2 DES. IMP</option>
                               
                                       
                                    </optgroup>
                                   
                               


                        
                    </select>
                </td>
                <td>
                    <label>TANQUE 2:</label>
                    <select placeholder="Seleccione producto" name="tanque2" class="form-control" required>
                    <option value="">- Seleccione producto -</option>
                    
                                    <!-- Opciones c1 hasta c6 -->
                                    <optgroup label="CRUDO">
                                    <option value="C1">C1</option>
        <option value="C2">C2</option>
        <option value="C3">C3</option>
        <option value="C4">C4</option>
        <option value="C5">C5</option>
        <option value="C6">C6</option>
                                    </optgroup>

                                    <!-- Opciones d1 hasta d4 -->
                                    <optgroup label="DESPACHO OLEINA">
                                    <option value="D1">D1</option>
        <option value="D2">D2</option>
        <option value="D3">D3</option>
        <option value="D4">D4</option>
                                    </optgroup>

                                    <!-- Opciones e1 hasta e13 -->
                                    <optgroup label="OLEINA">
                                    <option value="E1">E1</option>
        <option value="E2">E2</option>
        <option value="E3">E3</option>
        <option value="E7">E7</option>
        <option value="E8">E8</option>
        <option value="E13">E13</option>
                                    </optgroup>
                                    <optgroup label="ESTEARINA">
                                        <option value="8D">8D</option>
                                        <option value="9D">9D</option>
                                       
                                    </optgroup>
                                    <optgroup label="PALMA RBD">
                                        <option value="5D">5D</option>
                                        <option value="6D">6D</option>
                                        <option value="7D">7D</option>
                                       
                                    </optgroup>
                                    <optgroup label="ACIDO GRASO">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                       
                                    </optgroup>

                                    <optgroup label="DESOFORIZADOS IMPORTANTES">
                                            <option value="D1 DES. IMP">D1 DES. IMP</option>
                                            <option value="D2 DES. IMP">D2 DES. IMP</option>
                               
                                       
                                    </optgroup>
                                   
                                </select>
                </td>
            </tr>
            </table>
            <table class="table" style="MARGIN-TOP: 20PX;">
            <tr>
            
                    
                
                    <label>OBSERVACIONES:</label>
                    <textarea name="observaciones" rows="4" cols="50" style="FONT-SIZE: 12PX;WIDTH: 650PX;HEIGHT:250PX">
               
                </textarea>
            
                    
                
            </tr>
        </table>
       

                    </div>
       <!-- <input type="submit" value="Registrar" class="btn btn-primary">-->
        <button type="submit">Registrar</button>

        <button type="button" onclick="closePopup()">Cerrar</button>
        <!-- <button type="button" onclick="openPopup1()">Consulta</button>-->

    </form>
    <?php //include("../vistas_form/laboratorio/reg_materia_prima_consulta.php"); ?>
                        </div>
    </div>

    

                    <script>

                    function validatePercentage(input) {
                        const value = parseFloat(input.value);

                        if (isNaN(value) || value < 0 || value > 5) {
                            input.classList.add('invalid-input'); // Agregar la clase de estilo para el color
            
                            const confirmed = confirm("El valor ingresado no es válido. ¿Quieres continuar de todos modos?");

                            if (!confirmed) {
                                input.value = ''; // Limpiar el campo si el usuario no quiere continuar
                                return;
                            }
                        } else {
                                input.classList.remove('invalid-input'); // Quitar la clase de estilo si el valor es válido
                            }

                        // Si llegamos aquí, el valor es válido, ahora hacemos la solicitud AJAX
                     /*   const xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                alert(this.responseText); // Mostrar la respuesta del servidor (puede ser un mensaje de éxito o error)
                            }
                        };

                        const data = new FormData();
                        data.append('acidez', document.getElementsByName('acidez')[0].value);
                        data.append('humedad', document.getElementsByName('humedad')[0].value);
                        data.append('impurezas', document.getElementsByName('impurezas')[0].value);

                        xhttp.open("POST", "tu_archivo_php.php", true);
                        xhttp.send(data);*/
                    }
                </script>
                