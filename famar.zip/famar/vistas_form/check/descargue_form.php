

   
<link href="../css/style.css" rel="stylesheet">
<style>
         .invalid-input {
            COLOR: WHITE;
            background:RED;
            border: 2px solid red; /* Cambiar a tu color deseado */
        }

        .button-container {
            text-align: center;
            background-color: #fff; /* Cambia el color de fondo del contenedor según sea necesario */
            padding: 20px;
            border-radius: 8px; /* Añade bordes redondeados al contenedor */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Añade sombra al contenedor */
        }

        .button-container button {
            margin: 5px;
            padding: 10px;
            font-size: 16px;
            /* width: 100px; Ajusta el ancho según sea necesario */
            background-color: #002877; /* Cambia el color de fondo del botón según sea necesario */
            color: #fff; /* Cambia el color del texto del botón según sea necesario */
            border: none;
            border-radius: 4px; /* Añade bordes redondeados al botón */
            cursor: pointer;
        }

        .button-container button:hover {
            background-color: #f7b844; /* Cambia el color de fondo al pasar el ratón sobre el botón */
        }

        /* Organiza los botones en columnas de 3 */
        @media (min-width: 900px) {
            .button-container {
                /*display: grid;
                grid-template-columns: repeat(3, 1fr);*/
            }
        }
    </style>

<style>

@media (min-width: 1200px) {
	.container + .container {
		margin-top: 0px;
	}
	.row + .row {
		margin-top: 0px;
	}
}

        /* Estilo para el botón */
        .popup-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        /* Estilo para el popup */
        .popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            overflow: auto;
        }

        /* Estilo para el contenido del popup */
        .popup-content {
            position: absolute;
            top: 85%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            /*border: 1px solid #ccc;
            border-radius: 5px;*/
            border: 1px solid #002877;
        
           /* border: 2px solid #333; /* Añadir un borde sólido de 2px de color gris oscuro (#333) cursor: grab;*/
           BORDER-RADIUS: 26PX;
            
        }

        
        #login-form {
            text-align: center;
        }

        /* Estilo para el formulario */
        
    </style>


    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>

<body>



<div class="container">
    <h2 style="font-size: 31px;text-align: center;">VALIDACION DESCARGUE </h2>
    <br>
    <div class="button-container">
    
    <!--<button style="width: 200px;height: 100px;" onclick="openPopup()">RECIBO DE MATERIA PRIMA</button>-->
    

        <img src="images/porteria.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;width:30%;" onclick="openPopup()">
        
    <?php include("../vistas_form/check/form/reg_validacion_descargue.php"); ?>




    
   
    
</div>
</div>

    
</body>

