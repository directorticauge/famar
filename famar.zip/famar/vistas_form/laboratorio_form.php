

   
<link href="../css/style.css" rel="stylesheet">
<style>
         .invalid-input {
            COLOR: WHITE;
            background:RED;
            border: 2px solid red; /* Cambiar a tu color deseado */
        }

        .button-container {
            text-align: center;
            background-color: #fff; /* Cambia el color de fondo del contenedor según sea necesario */
            padding: 20px;
            border-radius: 8px; /* Añade bordes redondeados al contenedor */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Añade sombra al contenedor */
        }

        .button-container button {
            margin: 5px;
            padding: 10px;
            font-size: 16px;
            /* width: 100px; Ajusta el ancho según sea necesario */
            background-color: #002877; /* Cambia el color de fondo del botón según sea necesario */
            color: #fff; /* Cambia el color del texto del botón según sea necesario */
            border: none;
            border-radius: 4px; /* Añade bordes redondeados al botón */
            cursor: pointer;
        }

        .button-container button:hover {
            background-color: #f7b844; /* Cambia el color de fondo al pasar el ratón sobre el botón */
        }

        /* Organiza los botones en columnas de 3 */
        @media (min-width: 900px) {
            .button-container {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
            }
        }
    </style>

<style>

@media (min-width: 1200px) {
	.container + .container {
		margin-top: 0px;
	}
	.row + .row {
		margin-top: 0px;
	}
}

        /* Estilo para el botón */
        .popup-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        /* Estilo para el popup */
        .popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            overflow: auto;
        }

        /* Estilo para el contenido del popup */
        .popup-content {
            position: absolute;
            top: 85%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            /*border: 1px solid #ccc;
            border-radius: 5px;*/
            border: 1px solid #002877;
        
           /* border: 2px solid #333; /* Añadir un borde sólido de 2px de color gris oscuro (#333) cursor: grab;*/
           BORDER-RADIUS: 26PX;
            
        }

        
        #login-form {
            text-align: center;
        }

        /* Estilo para el formulario */
        
    </style>


    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>

<body>



<div class="container">
    <h2 style="font-size: 31px;text-align: center;">LABORATORIO </h2>
    <br>
    <div class="button-container">
    
    <!--<button style="width: 200px;height: 100px;" onclick="openPopup()">RECIBO DE MATERIA PRIMA</button>-->
    <img src="images/materia_prima.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
    <?php include("../vistas_form/laboratorio/reg_materia_prima_form.php"); ?>

    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_control_blanqueo()">CONTROL DE BLANQUEO R3</button>"-->
    <img src="images/control_blanqueo.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_control_blanqueo()">
    <?php include("../vistas_form/laboratorio/reg_control_blanqueo_r3.php"); ?>

    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_llenado_solidos()">INSPECCIÓN DE LLENADO DE SOLIDOS</button>-->
    <img src="images/llenado_solidos.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_llenado_solidos()">
    <?php include("../vistas_form/laboratorio/reg_llenado_solidos.php"); ?>

    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_almacenamiento_aceites()">CONTROL DE ALMACENAMIENTO DE ACEITES</button>-->
    <img src="images/almacenamiento_aceites.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_almacenamiento_aceites()">
    <?php include("../vistas_form/laboratorio/reg_almacenamiento_aceites.php"); ?>

    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_planta_fefinacion_r3()">CONTROL DE REFINACIÓN FISICA R3</button>-->
    <img src="images/control_refinacion.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_planta_fefinacion_r3()">
    <?php include("../vistas_form/laboratorio/reg_planta_refinacion_r3.php"); ?>
    
    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_llenado_liquidos()">INSPECCION DE LLENADO LIQUIDO</button>-->
    <img src="images/llenado_liquidos.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_llenado_liquidos()">
    <?php include("../vistas_form/laboratorio/reg_llenado_liquidos.php"); ?>


    <!--button style="width: 200px;height: 100px;" onclick="openPopup_despacho_productos_granel()">DESPACHO PRODUCTO A GRANEL</button>-->
    <img src="images/despacho_granel.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_despacho_productos_granel()">
    <?php include("../vistas_form/laboratorio/reg_despacho_productos_granel.php"); ?>


    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_control_proceso_fraccionamiento()">CONTROL DE PROCESO FRACCIONAMIENTO</button>-->
    <img src="images/control_fraccionamiento.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_control_proceso_fraccionamiento()">
    <?php include("../vistas_form/laboratorio/reg_control_proceso_fraccionamiento.php"); ?>

    
    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_lecturas_nmr()">REGISTRO LECTURAS NMR</button>-->
    <img src="images/lecturas_nmr.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_lecturas_nmr()">
    <?php include("../vistas_form/laboratorio/reg_lecturas_nmr.php"); ?>
    
    <!--<button onclick="window.location.href='enlace10.html'">RECIBO DE CARBON MINERAL</button>
    <button onclick="window.location.href='enlace11.html'">ANALISIS DE DOBI</button>-->
    <!--<button style="width: 200px;height: 100px;" onclick="openPopup_aguas_caldera()">CONTROL DE AGUAS DE CALDERA</button>-->
    <img src="images/control_calderas.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup_aguas_caldera()">
    <?php include("../vistas_form/laboratorio/reg_aguas_caldera.php"); ?> 

    <!--<button style="width: 200px;height: 100px;" onclick="window.location.href='enlace12.html'">CONTROL DEL FLORENTINO</button>-->
    <img src="images/control_florentino2.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
    <!--<button style="width: 200px;height: 100px;" onclick="window.location.href='enlace12.html'">PERFIL DE CROMATOGRAFIA</button>-->
    <img src="images/perfil_cromatografia.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
</div>
</div>

    
</body>

