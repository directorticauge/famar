<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Cargas</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Formulario de Cargas</h2>
        <form action="procesar_cargas.php" method="post">
            <label>Descripción:</label>
            <input type="text" name="descripcion" required>

            <label>Peso (kg):</label>
            <input type="number" name="peso" required>

            <label>Volumen (metros cúbicos):</label>
            <input type="number" name="volumen" required>

            <label>Origen:</label>
            <input type="text" name="origen" required>

            <label>Destino:</label>
            <input type="text" name="destino" required>

            <label>Fecha de Entrega:</label>
            <input type="date" name="fecha_entrega" required>

            <label>ID del Carro Asignado:</label>
            <input type="number" name="id_carro_asignado" required>

            <!-- Otros campos de Cargas -->

            <input type="submit" value="Guardar Carga">
        </form>
    </div>
</body>
</html>
