<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Conductores</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Formulario de Conductores</h2>
        <form action="procesar_conductores.php" method="post">
            <label>Nombre:</label>
            <input type="text" name="nombre" required>

            <label>Número de Licencia:</label>
            <input type="text" name="licencia" required>

            <!-- Otros campos de Conductores -->

            <input type="submit" value="Guardar Conductor">
        </form>
    </div>
</body>
</html>
