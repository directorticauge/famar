
<link href="../css/style.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<style>

.container {
    max-width: 90%;
    margin: 0 auto;
    padding: 20px;
}
         .invalid-input {
            COLOR: WHITE;
            background:RED;
            border: 2px solid red; /* Cambiar a tu color deseado */
        }

        .button-container {
            text-align: center;
            background-color: #fff; /* Cambia el color de fondo del contenedor según sea necesario */
            padding: 20px;
            border-radius: 8px; /* Añade bordes redondeados al contenedor */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Añade sombra al contenedor */
        }

        .button-container button {
            margin: 5px;
            padding: 10px;
            font-size: 16px;
            /* width: 100px; Ajusta el ancho según sea necesario */
            background-color: #002877; /* Cambia el color de fondo del botón según sea necesario */
            color: #fff; /* Cambia el color del texto del botón según sea necesario */
            border: none;
            border-radius: 4px; /* Añade bordes redondeados al botón */
            cursor: pointer;
        }

        .button-container button:hover {
            background-color: #f7b844; /* Cambia el color de fondo al pasar el ratón sobre el botón */
        }

        /* Organiza los botones en columnas de 3 */
        @media (min-width: 900px) {
            .button-container {
                display: grid;
                grid-template-columns: repeat(6, 1fr);
            }
        }

        td{
            border-top: 1px solid #dee2e6;

        }
    </style>

<style>
    table {
        border-collapse: collapse;
        /* Otros estilos para la tabla */
    }


    /* Elimina o sobrescribe el efecto hover */
    td:hover {
        background-color: inherit; /* Puedes usar 'transparent' en lugar de 'inherit' si quieres un fondo completamente transparente */
        /* Otros estilos hover si es necesario */
    }
</style>

<body>
<div class="container">
    <h3 style="font-size: 31px;">ESTADO DE NOMINACIONES HOY <?php setlocale(LC_TIME, 'es_ES'); // Establecer la configuración regional a español

$fechaCompleta = strftime('%A, %d de %B de %Y'); // Formato de fecha completa en español
echo $fechaCompleta;?></h3>
   
   
   <BR>
   <style>
    table {
        width: 1024px;
        margin: 0 auto; /* Centrar la tabla en el espacio disponible */
        border-collapse: collapse; /* Colapsar los bordes de la tabla */
    }

    td {
        padding: 5px; /* Añadir un espacio entre las celdas */
    }

    img {
        width: 100%; /* Las imágenes ocuparán el 100% del ancho de la celda */
        height: auto; /* La altura se ajusta automáticamente para mantener la proporción */
        display: block; /* Eliminar espacios debajo de las imágenes */
    }
</style>

   
    <div class="button-container">
    <?php
    // Consulta para obtener eventos que están dentro del rango de fecha del socio de negocio  --WHERE DATE(start) = CURDATE()

    try {
    $sql = "SELECT eventos.id, start, sn_nominado, id_nominacion, fecha,ck_porteria,ck_ssta,ck_bascula,ck_toma_muestras,placa,origen,nombre,
    apellido,ck_llegada,ck_produccion,ck_descargue
            FROM eventos
            inner join asignaciones on eventos.id=asignaciones.cupo_nominacion
            inner join socios_de_negocio on eventos.sn_nominado=socios_de_negocio.id
           where id_nominacion<> '' 
            ";

    $result = $db->query($sql);

    function obtenerNombreDia($fecha) {
        $diasEnIngles = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $diasEnEspanol = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];

        $nombreDiaEnIngles = date("l", strtotime($fecha));
        $nombreDia = str_replace($diasEnIngles, $diasEnEspanol, $nombreDiaEnIngles);

        return $nombreDia;
    }

   
    
    ?>
    
    <!--<button style="width: 200px;height: 100px;" onclick="openPopup()">RECIBO DE MATERIA PRIMA</button>-->
    <table>
<?php
    while ($row = $result->fetch_assoc()) {

        $fechaInicio = date("Y-m-d H:i:s", strtotime($row['start'])); // Formato "año-mes-día"
        $nombreDia = obtenerNombreDia($row['start']); // Nombre del día en español
        
        $hora = date("H:i:s", strtotime($row['start'])); 
       
        ?>
    <tr>
        <td>

        <label> <?php echo $hora."\n";?></label>
        <label> <?php echo $row['placa']."\n";?></label>
        <label> <?php echo $row['origen']."\n";?></label>
        <label> <?php echo $row['nombre']." ".$row['apellido'];?></label>

        <?php 
        
        if($row['ck_llegada']==''){
            ?>
            <div class="fc-daygrid-event-dot" style="border-color: rgb(223, 0, 20);"></div>
        <label style="color:RED;">AUSENTE</label>
        <?php 
        }else{
            ?>
            <label style="color:GREEN;">EN PLANTA</label>
            <?php 
        }
        
        ?>
        
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_porteria']<>''){?>
               <!-- Tu imagen con la clase info-icon para indicar que tiene información asociada -->
<img src="images/iconos/ico-enporteria.jpg" class="info-icon" data-id="<?php echo $row['id_nominacion'];?>" alt="Información no disponible">
<!-- Tu script JavaScript -->
<!-- Tu script JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var infoIcons = document.querySelectorAll('.info-icon');

    infoIcons.forEach(function(icon) {
        icon.addEventListener('click', function() {
            var iconId = icon.getAttribute('data-id');

            // Realiza una solicitud AJAX para obtener información de la base de datos
            $.ajax({
                url: 'info_iconos/obtener_informacion_icono.php',
                type: 'GET',
                data: { id: iconId },
                success: function(data) {
                    $('#infoModalBody').html(data);
                    $('#infoModal').modal('show');

                    // Cierra el modal después de mostrar la información
                    $('#infoModal').modal('hide');
                },
                error: function() {
                    console.error('Error al obtener información desde la base de datos.');
                }
            });
        });
    });
});

</script>



        <?php }else{?>
        <img src="images/iconos/ico-enporteria-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN PORTERIA</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_ssta']<>''){?>
        <img src="images/iconos/ico-ensst.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-ensst-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN SST</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_bascula']<>''){?>
        <img src="images/iconos/ico-enbascula.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-enbascula-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN BASCULA</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_toma_muestras']<>''){?>
        <img src="images/iconos/ico-entomademuestras.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-entomademuestras-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN TOMA DE MUESTRA</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['fecha']<>''){?>
        <img src="images/iconos/ico-enlaboratorio.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-enlaboratorio-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN LABORATORIO</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_produccion']<>''){?>
        <img src="images/iconos/ico-tanque.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-tanque-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN PRODUCCION</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_descargue']<>''){?>
        <img src="images/iconos/ico-endescargue.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-endescargue-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN DESCARGUE</label>
        </td>
        <td style="padding: 0px;">
        <?php if ($row['ck_bascula_salida']<>''){?>
        <img src="images/iconos/ico-enbascula-salida.jpg" alt="Recibo de Materia Prima" style="cursor: pointer;" onclick="openPopup()">
        <?php }else{?>
        <img src="images/iconos/ico-enbascula-salida-gris.jpg">
        <?php }?>
        <label style="color:#023277;WIDTH: 80PX;HEIGHT: 80PX;">EN BASCULA DE SALIDA</label>
        </td>
    </tr>
    <tr>
    

    </tr>
    <?php } 
      } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
    ?>
    
</table>

</div>
</div>


    
</body>

<!-- Modal para mostrar la información -->
<style>
.modal-backdrop {
    position: relative;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1040;
    background-color: #000;
}
</style>
<div class="modal fade" id="infoModal" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="infoModalLabel">Información detallada</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                
            </div>
            <div class="modal-body" id="infoModalBody">
                <!-- Aquí se mostrará la información dinámicamente -->
            </div>
            <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>-->
        </div>
    </div>
</div>
