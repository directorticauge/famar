<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Carros</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Formulario de Carros</h2>
        <form action="procesar_carros.php" method="post">
            <label>Marca:</label>
            <input type="text" name="marca" required>

            <label>Modelo:</label>
            <input type="text" name="modelo" required>

            <!-- Otros campos de Carros -->

            <input type="submit" value="Guardar Carro">
        </form>
    </div>
</body>
</html>
