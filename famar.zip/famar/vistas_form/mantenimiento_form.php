<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Registros de Mantenimiento</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Formulario de Registros de Mantenimiento</h2>
        <form action="procesar_mantenimiento.php" method="post">
            <label>ID del Carro:</label>
            <input type="number" name="id_carro" required>

            <label>Fecha de Mantenimiento:</label>
            <input type="date" name="fecha_mantenimiento" required>

            <label>Tipo de Mantenimiento:</label>
            <input type="text" name="tipo_mantenimiento" required>

            <!-- Otros campos de Registros de Mantenimiento -->

            <input type="submit" value="Guardar Registro de Mantenimiento">
        </form>
    </div>
</body>
</html>
