<?php
// Configura el puerto serie
$port = 'COM4';  // Reemplaza esto con el puerto correcto
$baud = 9600;    // Velocidad de transmisión
$serial = fopen($port, 'r+');
stream_set_timeout($serial, 5);  // Establece un tiempo de espera en segundos

if ($serial) {
    // Envía un comando a la balanza para obtener un valor (cambia el comando según tu balanza)
    fwrite($serial, "S\r\n");
    
    // Lee la respuesta de la balanza
    $response = fread($serial, 128);  // Ajusta el tamaño del búfer según tus necesidades
    
    // Cierra el puerto serie
    fclose($serial);
    
    // Procesa la respuesta de la balanza
    echo "Respuesta de la balanza: " . $response;
} else {
    echo "No se pudo abrir el puerto serie.";
}
?>

<?php

/*$device = '/dev/ttyUSB0'; // Ruta del dispositivo USB de la balanza
$baud = 9600; // Velocidad de comunicación (ajusta según la configuración de tu balanza)

try {
    $serial = fopen($device, 'r+');
    if (!$serial) {
        throw new Exception("No se pudo abrir el puerto USB.");
    }

    // Configura la velocidad de comunicación
    if (!stream_set_baudrate($serial, $baud)) {
        throw new Exception("No se pudo configurar la velocidad de comunicación.");
    }

    // Lee datos de la balanza
    $data = fread($serial, 1024);

    // Procesa los datos según el protocolo de comunicación de la balanza
    // Aquí deberás decodificar los datos según la documentación de la balanza.

    echo "Datos capturados: " . $data;

    fclose($serial);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}



$comPort = 'COM3'; // Reemplaza con el número de puerto COM de tu balanza

$baud = 9600; // Velocidad de comunicación (ajusta según la configuración de tu balanza)

try {
    $serial = fopen($comPort, 'r+');
    if (!$serial) {
        throw new Exception("No se pudo abrir el puerto COM.");
    }

    // Configura la velocidad de comunicación
    if (!stream_set_baudrate($serial, $baud)) {
        throw an Exception("No se pudo configurar la velocidad de comunicación.");
    }

    // Lee datos de la balanza
    $data = fread($serial, 1024);

    // Procesa los datos según el protocolo de comunicación de la balanza
    // Aquí deberás decodificar los datos según la documentación de la balanza.

    echo "Datos capturados: " . $data;

    fclose($serial);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}




<?php
$device = 'COM1'; // Reemplaza con el puerto serie correcto
$serial = new phpSerial;
$serial->deviceSet($device);
$serial->confBaudRate(9600);
$serial->confParity('none');
$serial->confCharacterLength(8);
$serial->confStopBits(1);
$serial->deviceOpen();

if ($serial) {
    $data = $serial->readPort(128); // Lee hasta 128 bytes de datos
    $serial->deviceClose();
    echo "Datos de la balanza: " . $data;
} else {
    echo "No se pudo abrir el puerto serie.";
}
?>


*/
?>
