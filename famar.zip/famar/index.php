<?php
header("Status: 301 Moved Permanently");
header("Location: site/index.php");
exit;
?>