<?php
session_start();
session_destroy();

?>
<script type="text/javascript">
window.location="../site/index.php";
</script>
