<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)

   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'u362358503_famar');
   define('DB_PASSWORD', 'Famar2023**%#');
   define('DB_DATABASE', 'u362358503_famar');
   
   // Crear conexión con la base de datos.
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
  
  
  /* comprobar la conexión */
	if (mysqli_connect_errno()) {
	printf("Falló la conexión: %s\n", mysqli_connect_error());
	exit();
}