<?php

  include("../main/config_db.php");
   $tiempoLimite = 1800; // 30 minutos
  session_set_cookie_params($tiempoLimite);
  session_start();
   
  
   $user_check = $_SESSION['login_user'];

   //echo "aqui";
   
   $ses_sql = mysqli_query($db,"select usuarios.id,usuarios.nombre,usuarios.apellido,usuarios.nivel,profiles.nombre_nivel,usuarios.sn
                                 from usuarios inner join profiles on usuarios.nivel=profiles.id 
													 
													   where user = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['nombre']." ".$row['apellido'];
   $login_nivel = $row['nivel']." ".$row['nombre_nivel'];
   $login_id_nivel= $row['nivel'];
   $login_id= $row['id'];
   $login_sn= $row['sn'];
  /* $login_id_campaña= $row['id_campaña'];
   $login_nombre_campaña= $row['nombre_campaña'];
   $login_logo_campaña= $row['logo_campaña'];
   $login_color_fondo1= $row['color_fondo1'];
   $login_color_fondo2= $row['color_fondo2'];
   $login_color_letra= $row['color_letra'];
   $login_fondo_login= $row['fondo_login'];
   $login_color_botones= $row['color_botones'];
   $login_color_caja= $row['color_caja'].";border-radius: 20px;";
  // $login_ubicacion=$ubicacion;*/
   
   if(!isset($_SESSION['login_user'])){
      header("location:index.php");
      die();
   }
?>