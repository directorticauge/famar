<?php
//echo "aqui";
  include("../main/config_db.php");
  session_start();
  

	if($_SERVER["REQUEST_METHOD"] == "POST") {
		  // username and password sent from form 
		 // echo "aqui11";
		 // echo $_POST['user'];
		  //echo $_POST['password'];
		  $myusername = mysqli_real_escape_string($db,$_POST['user']);
		  $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
		  
		 $myusernivel = 1; 
		 $myuseractivo = 1; 
		// echo "aqui2";
		  $sql = "SELECT * FROM usuarios WHERE user = '$myusername' and pass = '$mypassword'";
		  $result = mysqli_query($db,$sql);
		  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		  
		  
		  //$active = $row['active'];
		  
		  $count = mysqli_num_rows($result);
		  
		  // If result matched $myusername and $mypassword, table row must be 1 row
			
		  if($count == 1) {
			 //session_register("myusername");
			 $_SESSION['login_user'] = $myusername;
			 $_SESSION['nivel'] = $row["nivel"];
			 echo'<script type="text/javascript">
																alert("Usuario Logueado con exito");
																window.location.href="index.php";
																</script>';
			  $myusernivel=$row["nivel"];
			  $myuseractivo=$row["activo"];
					if ( $myuseractivo == 2) {
							 //header("location: principal.php");
							 if ($myusernivel == 1 || $myusernivel == 5) {
							header("location: index.php");
						
						} elseif ($myusernivel == 2 || $myusernivel ==7 ) {
							header("location: asignaciones.php");
						}
						/* elseif ($myusernivel == 3 || $myusernivel ==6 ) {
							header("location: principal.php?lvl=rgdld");
						} elseif ($myusernivel == 4) {
							header("location: principal_sp.php?lvl=rgdld");
						} elseif ($myusernivel == 5) {
							header("location: principal_sp.php?lvl=rgdld");
						}    */

					}else {echo'<script type="text/javascript">
																alert("SU USUARIO AUN NO ESTA ACATIVO CONSULTE CON EL COORDINADOR POLITICO.");
																window.location.href="logout.php";
																</script>';
						}
							  }else {
								  
								   echo'<script type="text/javascript">
																alert("Su usuario y/o contraseña son invalidos.");
																window.location.href="index.php";
																</script>';
								 echo $error = "Su usuario y/o contraseña son invalidos.";
								 //header("location: index.php");
								 
							  }
							  
							  
							  
							  
						   }

  


 
?>