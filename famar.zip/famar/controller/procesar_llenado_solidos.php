<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }


// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los valores del formulario
    $usuario_id = $_POST['usuario_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $producto_empacado = $_POST['producto_empacado'];
    $acidez = $_POST['acidez'];
    $valor_peroxido = $_POST['valor_peroxido'];
    $amarillo = $_POST['amarillo'];
    $rojo = $_POST['rojo'];
    $azul = $_POST['azul'];
    $humedad = $_POST['humedad'];
    $sal = $_POST['sal'];
    $ph = $_POST['ph'];
    $punto_fusion = $_POST['punto_fusion'];
    $yodo = $_POST['yodo'];
    $lote = $_POST['lote'];
    $fecha_vencimiento = $_POST['fecha_vencimiento'];
    $n_muestra = $_POST['n_muestra'];
    $observaciones = $_POST['observaciones'];
    $comentario_ing = $_POST['comentario_ing'];
    $carga = $_POST['carga'];
    $nitrogeno $_POST['notrogeno'];


    // Preparar la consulta SQL de inserción
    $sql = "INSERT INTO tbl_inspeccion_llenado_solido (usuario_id, fecha, hora, producto_empacado, acidez, valor_peroxido, amarillo, rojo, azul, humedad, sal, ph, punto_fusion, yodo, lote, fecha_vencimiento, n_muestra, observaciones, comentario_ing,carga,nitrogeno) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

    // Preparar la declaración
    $stmt = $db->prepare($sql);

    // Vincular los parámetros
    $stmt->bind_param("isssdddddffffffffiisssss", $usuario_id, $fecha, $hora, $producto_empacado, $acidez, $valor_peroxido, $amarillo, $rojo, $azul, $humedad, $sal, $ph, $punto_fusion, $yodo, $lote, $fecha_vencimiento, $n_muestra, $observaciones, $comentario_ing,$carga,$nitrogeno);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        echo "Los datos se han insertado correctamente.";
    } else {
        echo "Error al insertar los datos: " . $stmt->error;
    }

    // Cerrar la conexión y liberar los recursos
    $stmt->close();
    $db->close();
}
?>
