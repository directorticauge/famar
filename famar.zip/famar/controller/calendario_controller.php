<!DOCTYPE html>
<html lang='en'>
  <head>
    <meta charset='utf-8' />
    
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.9/index.global.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.9/index.global.min.js'></script>
    <script>

document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');
  //var today = new Date(); // Obtener la fecha actual
  var calendar = new FullCalendar.Calendar(calendarEl, {
    //initialDate: today,
    //initialView: 'timeGridWeek',resourceTimelineWeek dayGridMonth
    locale: 'es',
    initialView: 'dayGridMonth',
    events: 'eventos.php', // Ruta al archivo PHP que devuelve los eventos
    eventClick: function(info) {
      // Muestra información adicional al hacer clic en el evento
      var modal = document.createElement('div');
      modal.className = 'modal';
      modal.innerHTML = `
        <div class="modal-content">
          <span class="close" onclick="closeModal()">&times;</span>
          <h3>${info.event.title}</h3>
          <p>Fecha de inicio: ${info.event.start.toLocaleString()}</p>
          <p>Fecha de finalización: ${info.event.end ? info.event.end.toLocaleString() : 'N/A'}</p>
          <input type="text" name="prueba" value="${info.event.start.toLocaleString()}">
        </div>
      `;
      document.body.appendChild(modal);
    },
    eventRender: function(info) {
      // Define un color para el evento en función del campo "color" de tus datos
      if (info.event.extendedProps.color) {
        info.el.style.backgroundColor = info.event.extendedProps.color;
      }
    }
  });
  calendar.render();
});

function closeModal() {
  var modal = document.querySelector('.modal');
  if (modal) {
    modal.remove();
  }
}


    </script>

<style>
.modal {
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
  width: 50%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.close {
  position: absolute;
  top: 0;
  right: 0;
  padding: 10px;
  cursor: pointer;
}


</style>
  </head>
 <body>
    <div id='calendar'></div>
  </body>
</html>