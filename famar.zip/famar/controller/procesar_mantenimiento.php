<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)
include("../main/condig_db.php");

// Recibir datos del formulario
$id_carro = $_POST['id_carro'];
$fecha_mantenimiento = $_POST['fecha_mantenimiento'];
$tipo_mantenimiento = $_POST['tipo_mantenimiento'];

// Insertar datos en la tabla "Registros de Mantenimiento"
$sql = "INSERT INTO RegistrosMantenimiento (IDCarro, FechaMantenimiento, TipoMantenimiento) VALUES ('$id_carro', '$fecha_mantenimiento', '$tipo_mantenimiento')";

if ($conn->query($sql) === TRUE) {
    echo "Registro de mantenimiento registrado con éxito.";
} else {
    echo "Error al registrar el mantenimiento: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
