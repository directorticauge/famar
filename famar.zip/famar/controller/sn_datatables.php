<section class="book_section layout_padding">
    <div class="container" STYLE="/*width: 1334px;*/
			
			max-width: 100%;
		
	">
      <div class="row" style="background: <?php echo $login_color_caja;?>;">
        <div class="col">
          <form id="form1" name="form1" method="post" action="#" class="form-horizontal">
            <h4>
              CONSULTA <span style="color: <?php echo $login_color_botones;?>;">SOCIO DE NEGOCIOS</span>
			 
			   <!--<span style="color: <?php //echo $login_color_letra;?>;MARGIN-LEFT: 14EM;">Usted es <?php //echo $login_nivel; ?></span>-->
            </h4>
			
            <div class="form-row">
			
			  <table id="theTable" class="display" style="color: <?php echo $login_color_letra;?>;width: 100%; font-size: 12px;">
					<thead>
						<tr>
							
							
							<th><strong>ID</strong></th>
							<th><strong>NOMBRE</strong></th>
							<th><strong>APELLIDO</strong></th>
							<th><strong>EMAIL</strong></th>
							<th><strong>TELEFONO</strong></th>
							<th><strong>DIRECCION</strong></th>
							<th><strong>TIPO</strong></th>
							
							
							
						
							
					
					<th><strong>ACCIONES</strong></th>
						</tr>
					</thead>
					<tbody>
						<?php if(!empty($arr_lideres)) { ?>
							<?php foreach($arr_lideres as $user) { 
							?>
								<tr>
									
											<td><?php echo $user['id']; ?></td>
											<td><?php echo $user['nombre']; ?></td>
											<td><?php echo $user['apellido']; ?></td>
											<td><?php echo $user['email']; ?></td>
											<td><?php echo $user['telefono']; ?></td>
											<td><?php echo $user['direccion']; ?></td>
											<td><?php echo $user['tipo']; ?></td>
										
							
											
									
									
									
									
									
												
									<td>
											
										
										<a  href="?ID=<?php echo $user['id']; ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a> - 
										
										
										
										
										<a href="#" onclick="if (confirm('¿Estás seguro de eliminar?')) { window.location.href = '?lvl=rgdldcs&ID=<?php echo $user['id']; ?>&BRR=AFR&APRUSR=<?php echo $user['user']; ?>'; }"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
										
										
												
										<!--<button type='button' class='btn btn-primary none-shadow' onClick='eliminarPago(this)'><i class='fa fa-trash-o'></i></button>-->
										 </td>
								</tr>
							<?php } ?>
						<?php } ?>
					</tbody>
					<tfoot>
						<tr>
							<th></th>
							
							<!--<th>ID</th>
							<th>Ref.por</th>
							
							<th>Estado</th>
							<th>Cedula</th>
							<th>Nombre</th>
							<th>Celular</th>
							<th>Dirección</th>
							<th>Barrio</th>
							<th>Correo</th>
							<th>Departamento</th>
							<th>Municipio</th>
							<th>lugar de votacion</th>
							<th>Mesa</th>
							<th>Acciones</th>-->
							
						</tr>
					</tfoot>
				</table>
			
            </div>
			
	
          </form>
		  
	
		
		
		  </div>
      </div>
    </div>
	
	
	
	
  </section>
  
  
  
  
  
  