<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }




// Capturar variables del formulario
$usuario_id = $_POST['usuario_id'];
$fecha = $_POST['fecha'];
$localizacion = $_POST['localizacion'];
$producto = $_POST['producto'];
$carga = $_POST['carga'];
$punto_fusion = $_POST['punto_fusion'];
$conforme = isset($_POST['conforme']) ? $_POST['conforme'] : null;
$noconforme = isset($_POST['noconforme']) ? $_POST['noconforme'] : null;
$spfa10porcentaje = $_POST['spfa10porcentaje'];
$spfa10numero = $_POST['spfa10numero'];
$spfa15porcentaje = $_POST['spfa15porcentaje'];
$spfa15numero = $_POST['spfa15numero'];
$spfa20porcentaje = $_POST['spfa20porcentaje'];
$spfa20numero = $_POST['spfa20numero'];
$spfa25porcentaje = $_POST['spfa25porcentaje'];
$spfa25numero = $_POST['spfa25numero'];
$spfa30porcentaje = $_POST['spfa30porcentaje'];
$spfa30numero = $_POST['spfa30numero'];
$spfa35porcentaje = $_POST['spfa35porcentaje'];
$spfa35numero = $_POST['spfa35numero'];
$spfa40porcentaje = $_POST['spfa40porcentaje'];
$spfa40numero = $_POST['spfa40numero'];
$archivo = $_POST['archivo'];
$observaciones = $_POST['observaciones'];
$comentario_ing = $_POST['comentario_ing'];

// Consulta SQL para insertar datos en la tabla
$sql = "INSERT INTO tbl_lecturas_nmr (
    usuario_id, fecha, localizacion, producto, carga, punto_fusion, 
    conforme, noconforme, spfa10porcentaje, spfa10numero, spfa15porcentaje, spfa15numero,
    spfa20porcentaje, spfa20numero, spfa25porcentaje, spfa25numero, spfa30porcentaje, spfa30numero,
    spfa35porcentaje, spfa35numero, spfa40porcentaje, spfa40numero, archivo, observaciones, comentario_ing
) VALUES (
    '$usuario_id', '$fecha', '$localizacion', '$producto', '$carga', '$punto_fusion', 
    '$conforme', '$noconforme', '$spfa10porcentaje', '$spfa10numero', '$spfa15porcentaje', '$spfa15numero',
    '$spfa20porcentaje', '$spfa20numero', '$spfa25porcentaje', '$spfa25numero', '$spfa30porcentaje', '$spfa30numero',
    '$spfa35porcentaje', '$spfa35numero', '$spfa40porcentaje', '$spfa40numero', '$archivo', '$observaciones', '$comentario_ing'
)";

if ($db->query($sql) === TRUE) {
    echo "Registro insertado con éxito";
} else {
    echo "Error al insertar el registro: " . $conn->error;
}

// Cerrar la conexión a la base de datos
$db->close();
?>
