<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Recoger los datos del formulario
        $usuario_id = $_POST["usuario_id"];
        $fecha = $_POST["fecha"];
        $hora = $_POST["hora"];
        $producto = $_POST["producto"];
        $ffa = $_POST["ffa"];
        $valor_peroxido = $_POST["valor_peroxido"];
        $humedad = $_POST["humedad"];
        $amarillo = $_POST["amarillo"];
        $rojo = $_POST["rojo"];
        $azul = $_POST["azul"];
        $punto_fusion = $_POST["punto_fusion"];
        $conc_acidos = $_POST["conc_acidos"];
        $analisis_adc = $_POST["analisis_adc"];
        $observaciones = $_POST["observaciones"];
        $comentario_ing = $_POST["comentario_ing"];
        $ID = $_POST["ID"];
       
    
        // Consulta preparada SQL de inserción
        $sql = "INSERT INTO planta_refinacion_r3 (usuario_id, fecha, hora, producto, ffa, valor_peroxido, humedad, amarillo, rojo, azul, punto_fusion, conc_acidos, analisis_adc, observaciones, comentario_ing,ID_E) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $db->prepare($sql);
    
        // Vincular parámetros
        $stmt->bind_param("ssssssssssssss", $usuario_id, $fecha, $hora, $producto, $ffa, $valor_peroxido, $humedad, $amarillo, $rojo, $azul, $punto_fusion, $conc_acidos, $analisis_adc, $observaciones, $comentario_ing,$ID);
    
        // Ejecutar la consulta
        if ($stmt->execute() === TRUE) {
            echo "Registro insertado correctamente";
        } else {
            echo "Error al insertar el registro: " . $stmt->error;
        }
    
        // Cerrar el statement
        $stmt->close();
    }
    
    // Cerrar la conexión
    $db->close();
    ?>