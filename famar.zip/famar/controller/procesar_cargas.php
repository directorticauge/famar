<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)
include("../main/condig_db.php");
// Recibir datos del formulario
$descripcion = $_POST['descripcion'];
$peso = $_POST['peso'];
$volumen = $_POST['volumen'];
$origen = $_POST['origen'];
$destino = $_POST['destino'];
$fecha_entrega = $_POST['fecha_entrega'];
$id_carro_asignado = $_POST['id_carro_asignado'];

// Insertar datos en la tabla "Cargas"
$sql = "INSERT INTO Cargas (Descripcion, Peso, Volumen, Origen, Destino, FechaEntrega, IDCarroAsignado) VALUES ('$descripcion', '$peso', '$volumen', '$origen', '$destino', '$fecha_entrega', '$id_carro_asignado')";

if ($conn->query($sql) === TRUE) {
    echo "Carga registrada con éxito.";
} else {
    echo "Error al registrar la carga: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
