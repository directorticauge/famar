<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)
include("../main/condig_db.php");

// Recibir datos del formulario
$id_carro_asignado = $_POST['id_carro_asignado'];
$id_conductor_asignado = $_POST['id_conductor_asignado'];

// Insertar datos en la tabla "Asignaciones"
$sql = "INSERT INTO Asignaciones (IDCarroAsignado, IDConductorAsignado) VALUES ('$id_carro_asignado', '$id_conductor_asignado')";

if ($conn->query($sql) === TRUE) {
    echo "Asignación registrada con éxito.";
} else {
    echo "Error al registrar la asignación: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
