<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)
include("../main/condig_db.php");

// Recibir datos del formulario
$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$anio_fabricacion = $_POST['anio_fabricacion'];
$numero_placa = $_POST['numero_placa'];
$capacidad_carga = $_POST['capacidad_carga'];
$estado_mantenimiento = $_POST['estado_mantenimiento'];
$fecha_ultimo_mantenimiento = $_POST['fecha_ultimo_mantenimiento'];
$kilometraje = $_POST['kilometraje'];

// Insertar datos en la tabla "Carros"
$sql = "INSERT INTO Carros (Marca, Modelo, AnioFabricacion, NumeroPlaca, CapacidadCarga, EstadoMantenimiento, FechaUltimoMantenimiento, Kilometraje) VALUES ('$marca', '$modelo', '$anio_fabricacion', '$numero_placa', '$capacidad_carga', '$estado_mantenimiento', '$fecha_ultimo_mantenimiento', '$kilometraje')";

if ($conn->query($sql) === TRUE) {
    echo "Carro registrado con éxito.";
} else {
    echo "Error al registrar el carro: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
