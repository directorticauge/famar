<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }

 
// Obtén los datos del formulario
$usuario_id = $_POST['usuario_id'];
$fecha_empaque = $_POST['fecha_empaque'];
$hora_muestreo = $_POST['hora_muestreo'];
$producto_empacado = $_POST['producto_empacado'];
$acidez = $_POST['acidez'];
$valor_peroxido = $_POST['valor_peroxido'];
$amarillo = $_POST['amarillo'];
$rojo = $_POST['rojo'];
$azul = $_POST['azul'];
$cold_test = $_POST['cold_test'];
$lote = $_POST['lote'];
$fecha_venc = $_POST['fecha_venc'];
$num_muestra = $_POST['num_muestra'];
$tanque_alimt = $_POST['tanque_alimt'];
$observaciones = $_POST['observaciones'];
$comentario_ing = $_POST['comentario_ing'];
$temperatura = $_POST['temperatura'];


// Consulta preparada para la inserción segura de datos
$sql = "INSERT INTO llenado_liquidos (usuario_id, fecha_empaque, hora_muestreo, producto_empacado, acidez, valor_peroxido, amarillo, rojo, azul, cold_test, lote, fecha_venc, num_muestra, tanque_alimt, observaciones, comentario_ing,temperatura) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $db->prepare($sql);

// Vincular parámetros
$stmt->bind_param("ssssssssiiiisisss", $usuario_id, $fecha_empaque, $hora_muestreo, $producto_empacado, $acidez, $valor_peroxido, $amarillo, $rojo, $azul, $cold_test, $lote, $fecha_venc, $num_muestra, $tanque_alimt, $observaciones, $comentario_ing,$temperatura);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "Registro insertado correctamente";
} else {
    echo "Error al insertar el registro: " . $stmt->error;
}

// Cerrar conexión
$stmt->close();
$db->close();
?>
