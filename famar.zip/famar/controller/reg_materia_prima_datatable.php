

<style>
        /*table {
            width: 50%;
            border-collapse: collapse;
            margin: 20px auto;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }*/

        #theTable1 table{
            width: 50%;
            border-collapse: collapse;
            margin: 20px auto;
            }

            #theTable1 th, #theTable1 td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
            }

        th {
			background-color: #52bfbf;
    		color: white;
        }
                

        .dataTables_wrapper .dataTables_paginate .paginate_button {
    border-radius: 0; /* Elimina la propiedad de redondeo */
}
            


    </style>
<section class="book_section layout_padding">
    <div class="container" STYLE="/*width: 1334px;*/
			
			max-width: 100%;
		
	">
      <div class="row" style="background: <?php echo $login_color_caja;?>;">
        <div class="col" >
          <form id="form1" name="form1" method="post" action="#" class="form-horizontal">
			
            <div class="form-row">
			
			  <table id="theTable1" class="display" style="color: <?php echo $login_color_letra;?>;width: 1200px; font-size: 10px;">
					<thead>
						<tr>
							
							
							<th><strong>ID</strong></th>
                            <th><strong>title</strong></th>
                            <th><strong>S/N</strong></th>
                            <th><strong>ID_NOM</strong></th>
                            <th><strong>fecha</strong></th>
                            <th><strong>fentrada</strong></th>
                            <th><strong>escargue</strong></th>
                            <th><strong>tk_destino</strong></th>
                            <th><strong>CONTRSM.</strong></th>
                            <th><strong>OBSERV.</strong></th>
                            <th><strong>ACIDEZ</strong></th>
                            <th><strong>HUMEDAD</strong></th>
                            <th><strong>IMUREZAS</strong></th>
                            <th><strong>USER</strong></th>
							
							
						
							
					
					<th><strong>ACCIONES</strong></th>
						</tr>
					</thead>
					<tbody>
						<?php if(!empty($arr_lideres)) { ?>
							<?php foreach($arr_lideres as $user) { 
							?>
								<tr>
									

                                                                <td><?php echo $user['id']; ?></td>
                                                            <td><?php echo $user['title']; ?></td>
                                                            
                                                           <td><?php echo $user['sn_nominado']; ?></td>
                                                           <td><?php echo $user['id_nominacion']; ?></td>
                                                           <td><?php echo $user['fecha']; ?></td>
                                                           <td><?php echo $user['fecha_entrada']; ?></td>
                                                           <td><?php echo $user['fecha_descargue']; ?></td>
                                                           <td><?php echo $user['tk_destino']; ?></td>
                                                           <td><?php echo $user['contramuestra']; ?></td>
                                                           <td><?php echo $user['observaciones']; ?></td>
                                                           <td><?php echo $user['acidez']; ?></td>
                                                           <td><?php echo $user['humedad']; ?></td>
                                                           <td><?php echo $user['impurezas']; ?></td>
                                                           <td><?php echo $user['usersing']; ?></td>
											
							
											
									
									
									
									
									
												
									<td>
                                    <i class="fa fa-pencil-square" style="
    font-size: large;
" aria-hidden="true"></i> - <i class="fa fa-trash"  style="
    font-size: large;
" aria-hidden="true"></i>


										
											
											
									
												
									</td>
								</tr>
							<?php } ?>
						<?php } ?>
					</tbody>
					<tfoot>
						<tr>
							<!--<th></th>
							<a href="#" onclick="if (confirm('¿Estás seguro de aprobar?')) { window.location.href = '?lvl=rgdldcs&ID=<?php //echo $user['id']; ?>&APR=AFR'; }"><img width="20px" src="images/aprovar.png" alt=""></a>
										
							<th>ID</th>
							<th>Ref.por</th>
							
							<th>Estado</th>
							<th>Cedula</th>
							<th>Nombre</th>
							<th>Celular</th>
							<th>Dirección</th>
							<th>Barrio</th>
							<th>Correo</th>
							<th>Departamento</th>
							<th>Municipio</th>
							<th>lugar de votacion</th>
							<th>Mesa</th>
							<th>Acciones</th>-->
							
						</tr>
					</tfoot>
				</table>
			
            </div>
			
	
          </form>
		  
	
		
		
		  </div>
      </div>
    </div>
	
	
	
	
  </section>


  
  
  
  
  
  