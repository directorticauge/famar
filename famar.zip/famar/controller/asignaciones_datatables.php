<section class="book_section layout_padding">
    <div class="container" STYLE="/*width: 1334px;*/
			
			max-width: 100%;
		
	">
      <div class="row" style="background: <?php echo $login_color_caja;?>;">
        <div class="col">
          <form id="form1" name="form1" method="post" action="#" class="form-horizontal">
            <h4>
              CONSULTA <span style="color: <?php echo $login_color_botones;?>;">ASIGNACIONES</span>
			 
			   <!--<span style="color: <?php //echo $login_color_letra;?>;MARGIN-LEFT: 14EM;">Usted es <?php //echo $login_nivel; ?></span>-->
            </h4>
			
            <div class="form-row">
			
			  <table id="theTable" class="display" style="color: <?php echo $login_color_letra;?>;width: 100%; font-size: 12px;">
					<thead>
						<tr>
							
							
							<th><strong>ID</strong></th>
							<th><strong>PLACA</strong></th>
							<th><strong>REMOLQUE</strong></th>
							<th><strong>NOMBRE</strong></th>
							<th><strong>CEDULA</strong></th>
							<th><strong>ARL</strong></th>
							<th><strong>EPS</strong></th>
							<th><strong>TIPO PROD.</strong></th>
							<th><strong>ORIGEN</strong></th>
							<th><strong>CANTIDAD</strong></th>
							<th><strong>CALIDAD</th>
							<th><strong>REMISION</th>
							
							
							
						
							
					
					<th><strong>ACCIONES</strong></th>
						</tr>
					</thead>
					<tbody>
						<?php if(!empty($arr_lideres)) { ?>
							<?php foreach($arr_lideres as $user) { 
							?>
								<tr>
									
											<td><?php echo $user['id']; ?></td>
											<td><?php echo $user['placa']; ?></td>
											<td><?php echo $user['remolque']; ?></td>
											<td><?php echo $user['nombre_conductor']; ?></td>
											<td><?php echo $user['cedula_conductor']; ?></td>
											<td><?php echo $user['arl']; ?></td>
											<td><?php echo $user['eps']; ?></td>
											<td><?php echo $user['tipo_producto']; ?></td>
											<td><?php echo $user['origen']; ?></td>
											<td><?php echo $user['cantidad']; ?></td>
											<td><?php echo $user['calidad']; ?></td>
											<td><?php echo $user['remision']; ?></td>
							
											
									
									
									
									
									
												
									<td>
										<a href="#" onclick="if (confirm('¿Estás seguro de aprobar?')) { window.location.href = '?lvl=rgdldcs&ID=<?php echo $user['id']; ?>&APR=AFR&APRUSR=<?php echo $user['user']; ?>'; }"><img width="20px" src="images/aprovar.png" alt=""></a>
										
											
											
										
										<a  href="?lvl=rgdldcs&ID=<?php echo $user['id']; ?>&EDR=AFR"><img width="20px"src="images/edit.png" alt=""></a>
										
										
										
										
										<a href="#" onclick="if (confirm('¿Estás seguro de eliminar?')) { window.location.href = '?lvl=rgdldcs&ID=<?php echo $user['id']; ?>&BRR=AFR&APRUSR=<?php echo $user['user']; ?>'; }"><img width="20px"src="images/eliminar.png" alt=""></a>
										
										
												
										<!--<button type='button' class='btn btn-primary none-shadow' onClick='eliminarPago(this)'><i class='fa fa-trash-o'></i></button>-->
										 </td>
								</tr>
							<?php } ?>
						<?php } ?>
					</tbody>
					<tfoot>
						<tr>
							<th></th>
							
							<!--<th>ID</th>
							<th>Ref.por</th>
							
							<th>Estado</th>
							<th>Cedula</th>
							<th>Nombre</th>
							<th>Celular</th>
							<th>Dirección</th>
							<th>Barrio</th>
							<th>Correo</th>
							<th>Departamento</th>
							<th>Municipio</th>
							<th>lugar de votacion</th>
							<th>Mesa</th>
							<th>Acciones</th>-->
							
						</tr>
					</tfoot>
				</table>
			
            </div>
			
	
          </form>
		  
	
		
		
		  </div>
      </div>
    </div>
	
	
	
	
  </section>
  
  
  
  
  
  