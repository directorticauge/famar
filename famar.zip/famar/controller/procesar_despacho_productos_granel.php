<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }



// Recibir datos del formulario
$usuario_id = $_POST['usuario_id'];
$fecha = $_POST['fecha'];
$cliente = $_POST['cliente'];
$placa = $_POST['placa'];
$conductor = $_POST['conductor'];
$transportador = $_POST['transportador'];
$tanque = $_POST['tanque'];
$kilos_desp = $_POST['kilos_desp'];
$acidez = $_POST['acidez'];
$humedad = $_POST['humedad'];
$impurezas = $_POST['impurezas'];
$valor_peroxido = $_POST['valor_peroxido'];
$pf = $_POST['pf'];
$titer = $_POST['titer'];
$amarillo = $_POST['amarillo'];
$rojo = $_POST['rojo'];
$azul = $_POST['azul'];
$yodo = $_POST['yodo'];
$num_muestra = $_POST['num_muestra'];
$observaciones = $_POST['observaciones'];

// Consulta preparada para evitar inyección SQL
$sql = "INSERT INTO despacho_productos_granel (usuario_id, fecha, cliente, placa, conductor, transportador, tanque, kilos_desp, acidez, humedad, impurezas, valor_peroxido, pf, titer, amarillo, rojo, azul, yodo, num_muestra, observaciones) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $db->prepare($sql);
$stmt->bind_param("sssssssddddsssssssd", $usuario_id, $fecha, $cliente, $placa, $conductor, $transportador, $tanque, $kilos_desp, $acidez, $humedad, $impurezas, $valor_peroxido, $pf, $titer, $amarillo, $rojo, $azul, $yodo, $num_muestra, $observaciones);

if ($stmt->execute()) {
    echo "Registro exitoso";
} else {
    echo "Error al registrar: " . $stmt->error;
}

$stmt->close();
$db->close();
?>
