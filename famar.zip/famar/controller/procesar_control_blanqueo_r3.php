<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }

if ($_POST["control_blanqueo_r3"] ==1) {
                                // Recuperar los valores del formulario
                                $usuario_id = $_POST['usuario_id'];
                                $fecha = $_POST['fecha'];
                                $hora = $_POST['hora'];
                                $producto = $_POST['producto'];
                                $acidez = $_POST['acidez'];
                                $valor_peroxido = $_POST['valor_peroxido'];
                                $amarillo = $_POST['amarillo'];
                                $rojo = $_POST['rojo'];
                                $azul = $_POST['azul'];
                                $humedad = $_POST['humedad'];
                                $presencia_tierra = $_POST['presencia_tierra'];
                                $observaciones = $_POST['observaciones'];
                                $comentario_ing = $_POST['comentario_ing'];

                                $jabon_residual = $_POST['jabon_residual'];
                                $aceite_mineral = $_POST['aceite_mineral'];
                                $fosforo = $_POST['fosforo'];
                                $anicidina = $_POST['anicidina'];
                                $ID = $_POST['ID'];
                            
                            
                                // Preparar la consulta SQL de inserción
                                $sql = "INSERT INTO tbl_control_blanqueo (usuario_id, fecha, hora, producto, acidez, valor_peroxido, amarillo, rojo, azul, humedad, presencia_tierra, observaciones, comentario_ing,jabon_residual,aceite_mineral,fosforo,anicidina,ID_E) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
                            
                                // Preparar la declaración
                                $stmt = $db->prepare($sql);
                            
                                // Vincular los parámetros
                                $stmt->bind_param("isssdddddssssssssi", $usuario_id, $fecha, $hora, $producto, $acidez, $valor_peroxido, $amarillo, $rojo, $azul, $humedad, $presencia_tierra, $observaciones, $comentario_ing,$jabon_residual,$aceite_mineral,$fosforo,$anicidina,$ID);
                            
                                // Ejecutar la consulta
                                if ($stmt->execute()) {
                                    echo '<script>alert("Control de blanquedo Registrado exitosamente.");</script>';
                                    echo '<script type="text/javascript">
                                            window.location="../site/laboratorio.php";
                                            </script>';
                                } else {
                                    echo "Error al insertar los datos: " . $stmt->error;
                                }
                            
                                // Cerrar la conexión y liberar los recursos
                                $stmt->close();
                                $db->close();
                            }


                            ?>