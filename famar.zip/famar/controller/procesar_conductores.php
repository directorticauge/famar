<?php
// Conexión a la base de datos (ajusta los valores según tu configuración)
include("../main/condig_db.php");

// Recibir datos del formulario
$nombre = $_POST['nombre'];
$numero_licencia = $_POST['licencia'];

// Insertar datos en la tabla "Conductores"
$sql = "INSERT INTO Conductores (Nombre, NumeroLicencia) VALUES ('$nombre', '$numero_licencia')";

if ($conn->query($sql) === TRUE) {
    echo "Conductor registrado con éxito.";
} else {
    echo "Error al registrar el conductor: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
