<?php

 include("../main/session.php");

     

  // Consulta para obtener eventos
$sql = "SELECT id, title, start FROM eventos";
$result = $db->query($sql);

$eventos = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $eventos[] = $row;
    }
}

// Cerrar la conexión a la base de datos
$db->close();

// Devolver eventos en formato JSON
header('Content-Type: application/json');
echo json_encode($eventos);
?>