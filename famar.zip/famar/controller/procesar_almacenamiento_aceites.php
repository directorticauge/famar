<?php

session_start();
if($_SESSION['login_user']<>""){
  

include("../main/session.php");

}else{

  ?>
  <script type="text/javascript">
  window.location="../main/logout.php";
  </script>
  <?php
    }

   
// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los valores del formulario
    $usuario_id = $_POST['usuario_id'];
    $fecha = $_POST['fecha'];
    $tanque = $_POST['tanque'];
    $ffa = $_POST['ffa'];
    $cold_test = $_POST['cold_test'];
    $valor_peroxido = $_POST['valor_peroxido'];
    $punto_fusion = $_POST['punto_fusion'];
    $humedad = $_POST['humedad'];
    $yodo = $_POST['yodo'];
    $amarillo = $_POST['amarillo'];
    $rojo = $_POST['rojo'];
    $azul = $_POST['azul'];
    $observaciones = $_POST['observaciones'];
    $producto = $_POST['producto'];


    // Preparar la consulta SQL de inserción
    $sql = "INSERT INTO tbl_almacenamiento_aceites (usuario_id, fecha, tanque, ffa, cold_test, valor_peroxido, punto_fusion, humedad, yodo, amarillo, rojo, azul, observaciones,producto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

    // Preparar la declaración
    $stmt = $db->prepare($sql);

    // Vincular los parámetros
    $stmt->bind_param("isssssssssssss", $usuario_id, $fecha, $tanque, $ffa, $cold_test, $valor_peroxido, $punto_fusion, $humedad, $yodo, $amarillo, $rojo, $azul, $observaciones,$producto);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        echo "Los datos se han insertado correctamente.";
    } else {
        echo "Error al insertar los datos: " . $stmt->error;
    }

    // Cerrar la conexión y liberar los recursos
    $stmt->close();
    $db->close();
}
?>
