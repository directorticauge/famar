<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = file_get_contents('php://input');
    // Procesa los datos y realiza las operaciones necesarias
    echo 'Datos procesados con éxito';
}
?>