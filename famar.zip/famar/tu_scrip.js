// tu_script.js
document.addEventListener("DOMContentLoaded", () => {
    const connectButton = document.getElementById("connectButton");
    const dataDisplay = document.getElementById("dataDisplay");
    let comPort;

    connectButton.addEventListener("click", () => {
        if (!comPort) {
            navigator.usb.requestDevice({ filters: [...] })
            .then(device => {
                return device.open()
                    .then(() => device.selectConfiguration(1))
                    .then(() => device.claimInterface(0))
                    .then(() => device.transferIn(1, 64))
                    .then(result => {
                        // Procesa los datos leídos
                        dataDisplay.textContent = "Datos del dispositivo USB: " + new TextDecoder().decode(result.data);
                    });
            })
            .catch(error => {
                console.error('Error al acceder al dispositivo USB:', error);
            });
        }
    });
});
